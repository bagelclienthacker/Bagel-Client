# Bagel Client

A client-side Fabric hack client for Minecraft **26.2** (Java 25, Fabric Loader >= 0.19.3, Fabric API >= 0.161.0),
made for anarchy servers. Licensed under **GPL-3.0** (see `LICENSE`, `NOTICE.md`).

## Defaults
Everything is off except the HUD, no module has a key bind, every setting is at its default. The only key mappings are
**Open GUI** (Right Shift) and **Vanilla Mode** (unbound), changeable under Controls. Version 0.1.66 moves an old
`config/bagel/modules.properties` to `modules.properties.bak` once, so you start clean.

## Status
This tree is incomplete, see `MISSING_SOURCES.md`.

## Layout
- `src/main/java/gg/bagel/client/` - the client (modules in `extra/`, mixins in `extra/mixin/` and `mixin/`, UI, render).
- `src/main/resources/` - `fabric.mod.json`, mixin configs, assets.
- `bagel-combat.mixins.json` is optional: if it fails to apply, silent rotation falls back to normal aiming.

## Building
There is no verified Gradle setup yet. The release jars are built by compiling against the Minecraft 26.2 jar, Fabric
Loader / API and the Mixin jar with `javac --release 25`, then packing `src/main/resources` and the classes into a jar.
Contributions of a proper Fabric Loom build are welcome.

## Notes
- Builds so far were only class-verified (compiled and bytecode-checked), not play-tested by the tooling, so expect bugs and report them.
- Use on servers that allow it. You are responsible for what you do with it.
