# Notices

## Bagel Client
Copyright (C) 2026 The Bagel Client contributors. Licensed under the GNU General Public License, version 3
(`LICENSE`).

## AUTISM Client (Melonik) - GPL-3.0
Bagel Client's Kill Aura, Auto Totem, Storage ESP colours, tracer rendering and Freecam handling are modelled on, or
derived from, **AUTISM Client** by Melonik, which is released under the GNU General Public License v3. The files that
carry parts of it are marked in their headers: `KillAura`, `TotemMode`, `StorageColors`, `WorldEsp`, `CameraRig`,
`BagelRenderTypes`, `BagelSetup`. `CrystalAura` and `AnchorAura` reuse AUTISM's module layout and setting names, but
their logic is written for Bagel. Copyright of the original AUTISM Client code remains with its author.

## Minecraft
Bagel Client is a mod for Minecraft (Mojang Studios / Microsoft). It contains no Minecraft code or assets; it is built
against the game and Fabric. Minecraft is a trademark of Mojang. Bagel Client is not affiliated with Mojang or Microsoft.

## Fabric
Uses Fabric Loader, Fabric API and the Mixin framework (Apache-2.0 / LGPL-2.1 / MIT, see their projects).

## Logos
Bagel does **not** ship the Wikipedia or Windows Calculator artwork: those are trademarks / copyrighted works of the
Wikimedia Foundation and Microsoft. Homework Mode draws a built-in icon, or uses PNG files you place yourself in
`config/bagel/logos/` (`wikipedia.png`, `calculator.png`, `custom.png`).
