# INCOMPLETE SOURCE - read this first

The core of the mod (module registry, base module class, the click GUI, themes, the 'no render' mixins and
BagelClient itself) only exists as compiled classes so far. The Java source for these must be regenerated
(decompiled and cleaned up) before this repository is a complete GPL source release:

- gg/bagel/client/BagelClient.java
- gg/bagel/client/addon/BagelAddon.java
- gg/bagel/client/addon/BagelAddonLoader.java
- gg/bagel/client/mixin/AbstractButtonThemeMixin.java
- gg/bagel/client/mixin/AbstractClientPlayerMixin.java
- gg/bagel/client/mixin/ClientBrandMixin.java
- gg/bagel/client/mixin/CloudRendererMixin.java
- gg/bagel/client/mixin/FogRendererNoRenderMixin.java
- gg/bagel/client/mixin/GameRendererNoRenderMixin.java
- gg/bagel/client/mixin/MultiplayerBrandToggleMixin.java
- gg/bagel/client/mixin/NoRenderBannerMixin.java
- gg/bagel/client/mixin/NoRenderBeaconMixin.java
- gg/bagel/client/mixin/NoRenderEnchantBookMixin.java
- gg/bagel/client/mixin/NoRenderFallingBlockMixin.java
- gg/bagel/client/mixin/NoRenderGlintMixin.java
- gg/bagel/client/mixin/NoRenderMapMixin.java
- gg/bagel/client/mixin/NoRenderSignTextMixin.java
- gg/bagel/client/mixin/ParticleEngineMixin.java
- gg/bagel/client/mixin/ScreenEffectRendererMixin.java
- gg/bagel/client/mixin/ScreenThemeMixin.java
- gg/bagel/client/mixin/VanillaModeTitleMixin.java
- gg/bagel/client/mixin/WeatherEffectRendererMixin.java
- gg/bagel/client/mixin/WorldBorderRendererNoRenderMixin.java
- gg/bagel/client/module/Category.java
- gg/bagel/client/module/FeatureModule.java
- gg/bagel/client/module/Module.java
- gg/bagel/client/module/ModuleRegistry.java
- gg/bagel/client/render/BagelOverlay.java
- gg/bagel/client/theme/BagelMenuTheme.java
- gg/bagel/client/theme/BagelTheme.java
- gg/bagel/client/ui/BagelBrand.java
- gg/bagel/client/ui/BagelClickScreen.java
- gg/bagel/client/ui/BagelMainLayout.java
- gg/bagel/client/ui/BagelMainScreen.java
- gg/bagel/client/ui/RegistryPickerScreen.java
- gg/bagel/client/ui/RoundedUi.java
- gg/bagel/client/util/ClientBrand.java
- gg/bagel/client/util/NoRenderHooks.java
- gg/bagel/client/util/VanillaMode.java
