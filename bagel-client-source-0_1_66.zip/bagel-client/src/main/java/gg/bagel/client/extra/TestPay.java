/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * /testpay <player> <amount>: purely local. Shows a "You paid ..." action-bar popup and plays the
 * "successful hit" ding. Nothing is sent to the server and nothing goes into chat.
 */
public final class TestPay {
    private static final Pattern AMOUNT = Pattern.compile("(\\d+(?:\\.\\d+)?)([kKmMbBtT]?)");
    private static final int GRAY = 0xAAAAAA;
    private static final int NAME = 0xFFB347;
    private static final int GREEN = 0x00FF00;

    private TestPay() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) ->
                dispatcher.register(ClientCommands.literal("testpay")
                        .then(ClientCommands.argument("player", StringArgumentType.word())
                                .suggests(TestPay::suggestPlayers)
                                .then(ClientCommands.argument("amount", StringArgumentType.word())
                                        .executes(TestPay::run)))));
    }

    private static CompletableFuture<Suggestions> suggestPlayers(
            CommandContext<FabricClientCommandSource> context, SuggestionsBuilder builder) {
        String typed = builder.getRemainingLowerCase();
        Set<String> names = Names.online();
        for (String name : names) {
            if (name.toLowerCase(Locale.ROOT).startsWith(typed)) {
                builder.suggest(name);
            }
        }
        return builder.buildFuture();
    }

    private static int run(CommandContext<FabricClientCommandSource> context) {
        FabricClientCommandSource source = context.getSource();
        String player = StringArgumentType.getString(context, "player");
        String raw = StringArgumentType.getString(context, "amount");
        if (!show(source.getClient(), player, raw)) {
            source.sendError(Component.literal("Amount must look like 100, 1.5k or 2m."));
            return 0;
        }
        return 1;
    }

    /**
     * Called from the chat-send hook for every command typed. Anything starting with "testpay" is handled
     * here and never reaches the server, even if the server has its own /testpay.
     */
    public static boolean intercept(String command) {
        if (command == null) {
            return false;
        }
        String[] parts = command.trim().split("\\s+");
        if (parts.length == 0 || !parts[0].equalsIgnoreCase("testpay")) {
            return false;
        }
        Minecraft mc = Minecraft.getInstance();
        if (parts.length < 3 || !show(mc, parts[1], parts[2])) {
            mc.gui.hud.setOverlayMessage(Component.literal("Usage: /testpay <player> <amount>").withColor(GRAY), false);
        }
        return true;
    }

    private static boolean show(Minecraft mc, String player, String raw) {
        String amount = formatAmount(raw);
        if (amount == null) {
            return false;
        }
        Component message = Component.literal("You paid ").withColor(GRAY)
                .append(Component.literal(player).withColor(NAME))
                .append(Component.literal(" ").withColor(GRAY))
                .append(Component.literal("$" + amount + ".").withColor(GREEN));
        mc.gui.hud.setOverlayMessage(message, false);
        // same sound and pitch as the "Successful hit" ding (arrow hit player, pitch 1.0)
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ARROW_HIT_PLAYER, 1.0F, 0.6F));
        return true;
    }

    static String formatAmount(String raw) {
        String s = raw.trim();
        if (s.startsWith("$")) {
            s = s.substring(1);
        }
        s = s.replace(",", "");
        Matcher m = AMOUNT.matcher(s);
        if (!m.matches()) {
            return null;
        }
        String number = m.group(1);
        String suffix = m.group(2).toUpperCase(Locale.ROOT);
        if (suffix.isEmpty() && !number.contains(".") && number.length() > 3) {
            StringBuilder sb = new StringBuilder(number);
            for (int i = sb.length() - 3; i > 0; i -= 3) {
                sb.insert(i, ',');
            }
            return sb.toString();
        }
        return number + suffix;
    }
}
