/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import gg.bagel.client.render.BagelOverlay.BlockTarget;
import gg.bagel.client.util.VanillaMode;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.BagelRenderTypes;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;

/**
 * World-space ESP boxes (wireframe + translucent fill) drawn without depth testing, so they show
 * through walls. Called from WorldEspMixin every frame.
 */
public final class WorldEsp {
    private static final String[] BLOCK_MODULES = {"Storage ESP", "Block ESP", "Spawner ESP", "Block Highlights"};
    private static volatile long lastSubmit;
    private static volatile boolean failed;
    private static boolean warned;

    private WorldEsp() {}

    /** True while the world-space path is alive (the 2D box fallback stays off). */
    public static boolean working() {
        return !failed && System.currentTimeMillis() - lastSubmit < 1000L;
    }

    private record Tracer(Vec3 to, int color, float width) {}

    private record Box(AABB aabb, int color, boolean fill, boolean outline, int alpha) {}

    private static boolean on(String name) {
        Module m = BagelClient.MODULES.byName(name);
        return m != null && m.enabled();
    }

    private static boolean cleaned;

    public static void submit(LevelRenderState state, SubmitNodeCollector collector) {
        lastSubmit = System.currentTimeMillis();
        if (!cleaned) {
            cleaned = true;
            // the old tracer_color setting is gone: tracers always use the ESP's own color
            for (String name : new String[] {"Storage ESP", "Block ESP", "Spawner ESP", "Block Highlights", "Entity ESP", "Item ESP"}) {
                Module m = BagelClient.MODULES.byName(name);
                if (m != null) {
                    m.settings().remove("tracer_color");
                }
            }
        }
        if (failed) {
            return;
        }
        try {
            run(state, collector);
        } catch (Throwable t) {
            failed = true;
            if (!warned) {
                warned = true;
                BagelClient.LOGGER.warn("Bagel world ESP failed, falling back to 2D boxes", t);
            }
        }
    }

    private static void run(LevelRenderState state, SubmitNodeCollector collector) {
        Minecraft mc = Minecraft.getInstance();
        if (VanillaMode.active() || mc.player == null || mc.level == null || state.cameraRenderState == null || state.cameraRenderState.pos == null) {
            return;
        }
        Vec3 cam = state.cameraRenderState.pos;
        float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        List<Box> boxes = new ArrayList<>();
        List<Tracer> tracers = new ArrayList<>();
        int width = 2;

        boolean[] blockOn = new boolean[4];
        boolean anyBlock = false;
        for (int i = 0; i < 4; i++) {
            blockOn[i] = on(BLOCK_MODULES[i]);
            anyBlock |= blockOn[i];
        }
        if (anyBlock) {
            List<BlockTarget> targets = BagelOverlay.blockTargets;
            for (int i = 0; i < targets.size(); i++) {
                BlockTarget target = targets.get(i);
                int kind = Math.max(0, Math.min(3, BagelScan.kind(i)));
                boxes.add(new Box(new AABB(target.pos()).inflate(0.003D), target.color(), fillFor(BLOCK_MODULES[kind]), true, alphaFor(BLOCK_MODULES[kind])));
                if (blockOn[kind] && BagelEsp.tracers(BLOCK_MODULES[kind], false)) {
                    Module bm = BagelClient.MODULES.byName(BLOCK_MODULES[kind]);
                    // tracers use the same color as the box
                    tracers.add(new Tracer(new Vec3(target.pos().getX() + 0.5D, target.pos().getY() + 0.5D, target.pos().getZ() + 0.5D),
                            0xFF000000 | (target.color() & 0xFFFFFF), tracerWidth(bm)));
                }
                width = Math.max(width, lineWidth(BLOCK_MODULES[kind]));
            }
        }
        Module ent = BagelClient.MODULES.byName("Entity ESP");
        Module itm = BagelClient.MODULES.byName("Item ESP");
        boolean highlight = ent == null || !"box".equalsIgnoreCase(ent.stringSetting("style", "highlight").trim());
        String target = ent == null ? "feet" : ent.stringSetting("tracer_target", "feet").trim().toLowerCase();
        BagelEsp.worldEntities(mc, partial, (aabb, color, item, box, tracer) -> {
            if (box) {
                if (!item && highlight) {
                    // highlight style is the glow outline (EntityGlowMixin), no box here
                } else {
                    String name = item ? "Item ESP" : "Entity ESP";
                    boxes.add(new Box(aabb, color, fillFor(name), true, alphaFor(name)));
                }
            }
            if (tracer) {
                Module m = item ? itm : ent;
                int tcolor = color;
                double cx = (aabb.minX + aabb.maxX) / 2.0D;
                double cz = (aabb.minZ + aabb.maxZ) / 2.0D;
                double ty = item || target.equals("feet") ? aabb.minY : target.equals("head") ? aabb.maxY : (aabb.minY + aabb.maxY) / 2.0D;
                tracers.add(new Tracer(new Vec3(cx, ty, cz), 0xFF000000 | (tcolor & 0xFFFFFF), tracerWidth(m)));
            }
        });
        width = Math.max(width, Math.max(ent != null && ent.enabled() ? lineWidth("Entity ESP") : 0, itm != null && itm.enabled() ? lineWidth("Item ESP") : 0));
        if (boxes.isEmpty() && tracers.isEmpty()) {
            return;
        }

        PoseStack lineStack = new PoseStack();
        lineStack.translate(-cam.x, -cam.y, -cam.z);
        float lineWidth = Math.max(1.0F, Math.min(6.0F, width)) * 0.9F + 0.2F;
        for (Box box : boxes) {
            if (!box.outline()) {
                continue;
            }
            collector.submitShapeOutline(lineStack, Shapes.create(box.aabb()), BagelRenderTypes.linesSeeThrough(), box.color(), lineWidth, true);
        }

        if (!tracers.isEmpty()) {
            // like AUTISM: world-space lines from the camera (crosshair) to the target, no depth test
            // start a little in front of the camera (the crosshair): a segment that starts exactly at the camera
            // collapses to a dot when the GPU projects it
            double yaw = Math.toRadians(state.cameraRenderState.yRot);
            double pitch = Math.toRadians(state.cameraRenderState.xRot);
            Vec3 start = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)).scale(0.7D);
            collector.submitCustomGeometry(new PoseStack(), BagelRenderTypes.linesSeeThrough(), (pose, vc) -> {
                for (Tracer t : tracers) {
                    emitTracer(vc, start, new Vec3(t.to().x - cam.x, t.to().y - cam.y, t.to().z - cam.z), t.color(), t.width());
                }
            });
        }

        List<Box> filled = new ArrayList<>();
        for (Box box : boxes) {
            if (box.fill()) {
                filled.add(box);
            }
        }
        if (!filled.isEmpty()) {
            collector.submitCustomGeometry(new PoseStack(), BagelRenderTypes.fillSeeThrough(), (pose, vc) -> {
                for (Box box : filled) {
                    int rgb = box.color() & 0xFFFFFF;
                    emitBox(vc, box.aabb(), cam, (box.alpha() << 24) | rgb);
                }
            });
        }
    }

    private static boolean fillFor(String module) {
        Module m = BagelClient.MODULES.byName(module);
        return m == null || m.booleanSetting("fill", true);
    }

    private static int lineWidth(String module) {
        Module m = BagelClient.MODULES.byName(module);
        return m == null ? 2 : Math.max(1, Math.min(6, m.intSetting("line_width", 2)));
    }

    private static float tracerWidth(Module m) {
        int w = m == null ? 1 : Math.max(1, Math.min(6, m.intSetting("tracer_width", 1)));
        return 0.8F + w * 0.7F;
    }

    private static void emitTracer(VertexConsumer vc, Vec3 from, Vec3 to, int argb, float width) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-4D) {
            return;
        }
        float nx = (float) (dx / len);
        float ny = (float) (dy / len);
        float nz = (float) (dz / len);
        vc.addVertex((float) from.x, (float) from.y, (float) from.z).setColor(argb).setNormal(nx, ny, nz).setLineWidth(width);
        vc.addVertex((float) to.x, (float) to.y, (float) to.z).setColor(argb).setNormal(nx, ny, nz).setLineWidth(width);
    }

    private static int pct(int percent) {
        return Math.round(Math.max(0, Math.min(100, percent)) / 100.0F * 255.0F);
    }

    private static int alphaFor(String module) {
        Module m = BagelClient.MODULES.byName(module);
        return pct(m == null ? 22 : m.intSetting("fill_opacity", 22));
    }

    private static void emitBox(VertexConsumer vc, AABB b, Vec3 cam, int argb) {
        float x1 = (float) (b.minX - cam.x);
        float y1 = (float) (b.minY - cam.y);
        float z1 = (float) (b.minZ - cam.z);
        float x2 = (float) (b.maxX - cam.x);
        float y2 = (float) (b.maxY - cam.y);
        float z2 = (float) (b.maxZ - cam.z);
        quad(vc, argb, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2); // bottom
        quad(vc, argb, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1); // top
        quad(vc, argb, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1); // north
        quad(vc, argb, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2); // south
        quad(vc, argb, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1); // west
        quad(vc, argb, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2); // east
    }

    private static void quad(VertexConsumer vc, int argb,
            float ax, float ay, float az, float bx, float by, float bz,
            float cx, float cy, float cz, float dx, float dy, float dz) {
        vc.addVertex(ax, ay, az).setColor(argb);
        vc.addVertex(bx, by, bz).setColor(argb);
        vc.addVertex(cx, cy, cz).setColor(argb);
        vc.addVertex(dx, dy, dz).setColor(argb);
    }
}
