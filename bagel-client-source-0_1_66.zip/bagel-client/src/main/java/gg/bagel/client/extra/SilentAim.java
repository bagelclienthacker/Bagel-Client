/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Silent aim for every combat module except Kill Aura (which keeps its own state): the yaw and pitch that go into the
 * normal movement packet are swapped for a few ticks. No extra packet is ever sent and the camera never moves.
 *
 * <p>The packet for a tick is built before the modules run, so a request made now is sent next tick. Modules therefore
 * ask with {@link #aim}, wait until {@link #ready} says the server already knows the rotation, and only then act.
 */
public final class SilentAim {
    private static boolean on;
    private static float wantYaw;
    private static float wantPitch;
    private static int liveUntil = Integer.MIN_VALUE;

    private static float sentYaw;
    private static float sentPitch;
    private static boolean sentKnown;
    private static int hookWait;

    private SilentAim() {}

    // ------------------------------------------------------------------ mixin hooks

    public static float outgoingYaw(LocalPlayer player, float real) {
        float out = KillAura.outgoingYaw(player, real);
        if (!KillAura.aiming(player) && live(player)) {
            out = wantYaw;
        }
        sentYaw = out;
        sentKnown = true;
        return out;
    }

    public static float outgoingPitch(LocalPlayer player, float real) {
        float out = KillAura.outgoingPitch(player, real);
        if (!KillAura.aiming(player) && live(player)) {
            out = wantPitch;
        }
        sentPitch = out;
        return out;
    }

    private static boolean live(LocalPlayer player) {
        return on && player != null && player.tickCount <= liveUntil;
    }

    // ------------------------------------------------------------------ module API

    /** Whether Kill Aura currently owns the rotation (other modules should not fight it). */
    public static boolean blocked(LocalPlayer player) {
        return KillAura.aiming(player);
    }

    public static void aim(Minecraft mc, LocalPlayer player, Vec3 point) {
        float[] angles = KillAura.anglesTo(player.getEyePosition(), point);
        aim(mc, player, angles[0], angles[1]);
    }

    public static void aim(Minecraft mc, LocalPlayer player, float yaw, float pitch) {
        float step = step(mc);
        float baseYaw = sentKnown ? sentYaw : player.getYRot();
        float basePitch = sentKnown ? sentPitch : player.getXRot();
        wantYaw = snap(baseYaw, baseYaw + Mth.wrapDegrees(yaw - baseYaw), step);
        wantPitch = Mth.clamp(snap(basePitch, pitch, step), -90.0F, 90.0F);
        on = true;
        liveUntil = player.tickCount + 2;
    }

    /** Where we want to look right now (after {@link #aim}); used so callers can compare against the target. */
    public static float wantedYaw() {
        return wantYaw;
    }

    public static float wantedPitch() {
        return wantPitch;
    }

    /**
     * True once the rotation the server last received points at (yaw, pitch) within {@code tolerance} degrees. If the
     * mixin never ran (no packet seen for 2 seconds) this falls back to true so the module still works.
     */
    public static boolean ready(LocalPlayer player, float yaw, float pitch, float tolerance) {
        if (!sentKnown) {
            hookWait++;
            return hookWait > 40;
        }
        float dy = Mth.wrapDegrees(sentYaw - yaw);
        float dp = sentPitch - pitch;
        return Math.sqrt(dy * dy + dp * dp) <= tolerance;
    }

    public static void release() {
        on = false;
    }

    // ------------------------------------------------------------------ helpers

    /** One mouse count in degrees at the current sensitivity (vanilla: f^3 * 8 * 0.15). */
    public static float step(Minecraft mc) {
        double s = mc.options.sensitivity().get();
        double f = s * 0.6D + 0.2D;
        return (float) Math.max(0.0005D, f * f * f * 1.2D);
    }

    public static float snap(float base, float value, float step) {
        return base + Math.round((value - base) / step) * step;
    }
}
