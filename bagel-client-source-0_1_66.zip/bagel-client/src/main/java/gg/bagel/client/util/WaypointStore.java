/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Saved waypoints (config/bagel/waypoints.properties). Same file format as before, now with edit support. */
public final class WaypointStore {
    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
    private static boolean loaded;

    private WaypointStore() {}

    public record Waypoint(String name, String dimension, double x, double y, double z) {}

    public static List<Waypoint> all() {
        load();
        return List.copyOf(WAYPOINTS);
    }

    public static void save(LocalPlayer player) {
        load();
        Minecraft mc = Minecraft.getInstance();
        String dimension = mc.level.dimension().identifier().toString();
        WAYPOINTS.add(new Waypoint("Waypoint " + (WAYPOINTS.size() + 1), dimension, player.getX(), player.getY(), player.getZ()));
        persist();
    }

    /** Adds a waypoint at the player's position with a custom name (blank keeps the default name). */
    public static void saveNamed(LocalPlayer player, String name) {
        load();
        Minecraft mc = Minecraft.getInstance();
        String dimension = mc.level.dimension().identifier().toString();
        String clean = name == null ? "" : name.trim();
        if (clean.isEmpty()) {
            clean = "Waypoint " + (WAYPOINTS.size() + 1);
        }
        WAYPOINTS.add(new Waypoint(clean, dimension, player.getX(), player.getY(), player.getZ()));
        persist();
    }

    public static void remove(int index) {
        load();
        if (index >= 0 && index < WAYPOINTS.size()) {
            WAYPOINTS.remove(index);
            persist();
        }
    }

    public static void rename(int index, String name) {
        load();
        String clean = name == null ? "" : name.trim();
        if (index >= 0 && index < WAYPOINTS.size() && !clean.isEmpty()) {
            Waypoint w = WAYPOINTS.get(index);
            WAYPOINTS.set(index, new Waypoint(clean, w.dimension(), w.x(), w.y(), w.z()));
            persist();
        }
    }

    private static void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        Properties props = new Properties();
        try (Reader reader = Files.newBufferedReader(path())) {
            props.load(reader);
            int count = Integer.parseInt(props.getProperty("count", "0"));
            for (int i = 0; i < count; i++) {
                String p = "waypoint." + i + ".";
                WAYPOINTS.add(new Waypoint(
                        props.getProperty(p + "name", "Waypoint " + (i + 1)),
                        props.getProperty(p + "dimension", "minecraft:overworld"),
                        Double.parseDouble(props.getProperty(p + "x", "0")),
                        Double.parseDouble(props.getProperty(p + "y", "0")),
                        Double.parseDouble(props.getProperty(p + "z", "0"))));
            }
        } catch (IOException | RuntimeException e) {
            // no file yet, or unreadable: keep whatever loaded so far (nothing for a missing file)
            if (!(e instanceof java.nio.file.NoSuchFileException)) {
                WAYPOINTS.clear();
            }
        }
    }

    private static void persist() {
        Properties props = new Properties();
        props.setProperty("count", Integer.toString(WAYPOINTS.size()));
        for (int i = 0; i < WAYPOINTS.size(); i++) {
            Waypoint w = WAYPOINTS.get(i);
            String p = "waypoint." + i + ".";
            props.setProperty(p + "name", w.name());
            props.setProperty(p + "dimension", w.dimension());
            props.setProperty(p + "x", Double.toString(w.x()));
            props.setProperty(p + "y", Double.toString(w.y()));
            props.setProperty(p + "z", Double.toString(w.z()));
        }
        try {
            Files.createDirectories(path().getParent());
            try (Writer writer = Files.newBufferedWriter(path())) {
                props.store(writer, "Bagel waypoints");
            }
        } catch (IOException ignored) {
            // best effort
        }
    }

    private static Path path() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config/bagel/waypoints.properties");
    }
}
