/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.NativeImage;
import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * A working Standard calculator laid out like the Windows 11 Calculator and drawn with real fonts (Segoe UI when it is
 * installed, otherwise the system sans-serif). The whole window is rendered with Java2D into a texture, so text is
 * smooth and keys can be true circles ("key_shape" Circle) or the app's rounded squares ("Rounded"). Theme: Dark or
 * Light. Escape closes it.
 */
public final class CalculatorScreen extends Screen {
    private static final String[] IDS = {
        "%", "CE", "C", "BK",
        "INV", "SQ", "ROOT", "/",
        "7", "8", "9", "x",
        "4", "5", "6", "-",
        "1", "2", "3", "+",
        "NEG", "0", ".", "=",
    };
    private static final String[] MEMORY = {"MC", "MR", "M+", "M-", "MS", "Mv"};
    private static final MathContext MC = new MathContext(16, RoundingMode.HALF_UP);

    // calculator state
    private String display = "0";
    private String line = "";
    private BigDecimal acc;
    private char op;
    private boolean fresh = true;
    private BigDecimal memory;
    private String error;

    // rendering state
    private DynamicTexture texture;
    private Identifier textureId;
    private int texW;
    private int texH;
    private boolean dirty = true;
    private int hoverKey = -1;
    private int hoverMemory = -1;
    private String fontFamily;
    private String boldFamily;

    // layout in image pixels (set while drawing, used for hit testing)
    private double scale = 1.0D;

    public CalculatorScreen() {
        super(Component.literal("Calculator"));
    }

    // ------------------------------------------------------------------ settings

    private static Module module() {
        try {
            return BagelClient.MODULES.byName(HomeworkMode.NAME);
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean dark() {
        Module m = module();
        return m == null || !m.stringSetting("theme", "Dark").equalsIgnoreCase("Light");
    }

    private static boolean circles() {
        Module m = module();
        return m == null || !m.stringSetting("key_shape", "Circle").equalsIgnoreCase("Rounded");
    }

    // ------------------------------------------------------------------ geometry

    private double topBar(int ph) {
        return Math.max(44.0D, ph * 0.075D);
    }

    private double displayHeight(int ph) {
        return ph * 0.21D;
    }

    private double memoryHeight(int ph) {
        return Math.max(30.0D, ph * 0.06D);
    }

    private double padding(int pw) {
        return Math.max(4.0D, pw * 0.006D);
    }

    /** Key rectangle (x, y, w, h) in image pixels. */
    private double[] keyRect(int index, int pw, int ph) {
        double y0 = topBar(ph) + displayHeight(ph) + memoryHeight(ph);
        double pad = padding(pw);
        double w = (pw - pad * 2) / 4.0D;
        double h = (ph - y0 - pad) / 6.0D;
        int row = index / 4;
        int col = index % 4;
        return new double[] {pad + col * w, y0 + row * h, w, h};
    }

    private double[] memoryRect(int index, int pw, int ph) {
        double y0 = topBar(ph) + displayHeight(ph);
        double w = pw / 6.0D;
        return new double[] {index * w, y0, w, memoryHeight(ph)};
    }

    // ------------------------------------------------------------------ screen life cycle

    @Override
    protected void init() {
        dirty = true;
    }

    @Override
    public void removed() {
        if (textureId != null && minecraft != null) {
            minecraft.getTextureManager().release(textureId);
        }
        texture = null;
        textureId = null;
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, dark() ? 0xFF202020 : 0xFFF3F3F3);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        extractBackground(g, mouseX, mouseY, delta);
        double guiScale = minecraft.getWindow().getGuiScale();
        int pw = Math.max(64, (int) Math.round(width * guiScale));
        int ph = Math.max(64, (int) Math.round(height * guiScale));
        if (texture == null || pw != texW || ph != texH) {
            if (textureId != null) {
                minecraft.getTextureManager().release(textureId);
            }
            textureId = Identifier.fromNamespaceAndPath("bagel", "homework/calculator_" + System.nanoTime());
            texture = new DynamicTexture(() -> "Bagel calculator", pw, ph, false);
            minecraft.getTextureManager().register(textureId, texture);
            texW = pw;
            texH = ph;
            dirty = true;
        }
        int px = (int) Math.round(mouseX * guiScale);
        int py = (int) Math.round(mouseY * guiScale);
        int hk = hitKey(px, py, pw, ph);
        int hm = hitMemory(px, py, pw, ph);
        if (hk != hoverKey || hm != hoverMemory) {
            hoverKey = hk;
            hoverMemory = hm;
            dirty = true;
        }
        if (dirty) {
            dirty = false;
            try {
                render(pw, ph);
            } catch (Throwable error) {
                BagelClient.LOGGER.warn("Calculator could not draw", error);
            }
        }
        g.blit(RenderPipelines.GUI_TEXTURED, textureId, 0, 0, 0.0F, 0.0F, width, height, pw, ph, pw, ph);
    }

    private int hitKey(int px, int py, int pw, int ph) {
        for (int i = 0; i < IDS.length; i++) {
            double[] r = keyRect(i, pw, ph);
            if (px >= r[0] && px < r[0] + r[2] && py >= r[1] && py < r[1] + r[3]) {
                return i;
            }
        }
        return -1;
    }

    private int hitMemory(int px, int py, int pw, int ph) {
        for (int i = 0; i < MEMORY.length; i++) {
            double[] r = memoryRect(i, pw, ph);
            if (px >= r[0] && px < r[0] + r[2] && py >= r[1] && py < r[1] + r[3]) {
                return i;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------ drawing

    private void render(int pw, int ph) {
        BufferedImage image = draw(pw, ph);
        int[] data = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
        NativeImage pixels = texture.getPixels();
        for (int y = 0; y < ph; y++) {
            int row = y * pw;
            for (int x = 0; x < pw; x++) {
                int argb = data[row + x];
                pixels.setPixelABGR(x, y, (argb & 0xFF00FF00) | ((argb >> 16) & 0xFF) | ((argb & 0xFF) << 16));
            }
        }
        texture.upload();
    }

    /** Draws the whole calculator into an image (no game objects needed). */
    BufferedImage draw(int pw, int ph) {
        boolean dark = dark();
        boolean circle = circles();
        BufferedImage image = new BufferedImage(pw, ph, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        pickFonts();

        Color bg = dark ? new Color(0x202020) : new Color(0xF3F3F3);
        Color text = dark ? Color.WHITE : new Color(0x1B1B1B);
        Color soft = dark ? new Color(0x9D9D9D) : new Color(0x5F5F5F);
        g.setColor(bg);
        g.fillRect(0, 0, pw, ph);

        // title bar: hamburger and the mode name
        double tb = topBar(ph);
        g.setColor(text);
        double hx = tb * 0.5D;
        double hw = tb * 0.34D;
        for (int i = -1; i <= 1; i++) {
            g.fill(new RoundRectangle2D.Double(hx - hw / 2, tb / 2 + i * tb * 0.1D - 0.9D, hw, 1.8D, 1.8D, 1.8D));
        }
        Font title = new Font(boldFamily, Font.BOLD, 1).deriveFont((float) (tb * 0.40D));
        g.setFont(title);
        g.drawString("Standard", (float) (tb * 1.05D), (float) (tb / 2 + tb * 0.14D));

        // expression and result
        double dh = displayHeight(ph);
        double dy = tb;
        double right = pw - Math.max(16.0D, pw * 0.035D);
        Font small = new Font(fontFamily, Font.PLAIN, 1).deriveFont((float) Math.max(14.0D, dh * 0.15D));
        g.setFont(small);
        g.setColor(soft);
        String expr = line;
        FontMetrics sm = g.getFontMetrics();
        g.drawString(expr, (float) (right - sm.stringWidth(expr)), (float) (dy + dh * 0.28D));

        String shown = error != null ? error : group(display);
        float size = (float) Math.max(20.0D, dh * 0.52D);
        Font big = new Font(boldFamily, Font.BOLD, 1).deriveFont(size);
        FontMetrics bm = g.getFontMetrics(big);
        while (bm.stringWidth(shown) > right - pw * 0.03D && size > 14.0F) {
            size *= 0.92F;
            big = big.deriveFont(size);
            bm = g.getFontMetrics(big);
        }
        g.setFont(big);
        g.setColor(text);
        g.drawString(shown, (float) (right - bm.stringWidth(shown)), (float) (dy + dh * 0.86D));

        // memory row
        Font memFont = new Font(fontFamily, Font.PLAIN, 1).deriveFont((float) Math.max(13.0D, memoryHeight(ph) * 0.42D));
        g.setFont(memFont);
        FontMetrics mm = g.getFontMetrics();
        for (int i = 0; i < MEMORY.length; i++) {
            double[] r = memoryRect(i, pw, ph);
            boolean usable = i >= 2 || memory != null;
            if (i == hoverMemory && usable) {
                g.setColor(dark ? new Color(255, 255, 255, 22) : new Color(0, 0, 0, 14));
                g.fill(new RoundRectangle2D.Double(r[0] + 3, r[1] + 3, r[2] - 6, r[3] - 6, 8, 8));
            }
            g.setColor(usable ? text : soft);
            String label = i == 3 ? "M−" : (i == 5 ? "M" : MEMORY[i]);
            double cx = r[0] + r[2] / 2;
            double base = r[1] + r[3] / 2 + mm.getAscent() * 0.34D;
            if (i == 5) {
                int w = mm.stringWidth("M");
                g.drawString("M", (float) (cx - w / 2 - 4), (float) base);
                double tx = cx + w / 2 - 1;
                double ty = r[1] + r[3] / 2 + 1;
                Path2D tri = new Path2D.Double();
                tri.moveTo(tx, ty - 3);
                tri.lineTo(tx + 7, ty - 3);
                tri.lineTo(tx + 3.5, ty + 2.5);
                tri.closePath();
                g.fill(tri);
            } else {
                g.drawString(label, (float) (cx - mm.stringWidth(label) / 2.0D), (float) base);
            }
        }

        // keys
        Color digit = dark ? new Color(0x3B3B3B) : new Color(0xFFFFFF);
        Color digitHover = dark ? new Color(0x323232) : new Color(0xF9F9F9);
        Color other = dark ? new Color(0x323232) : new Color(0xF9F9F9);
        Color otherHover = dark ? new Color(0x3B3B3B) : new Color(0xFFFFFF);
        Color accent = dark ? new Color(0x4CC2FF) : new Color(0x0067C0);
        Color accentHover = dark ? new Color(0x47B1E8) : new Color(0x1975C5);
        Color accentText = dark ? Color.BLACK : Color.WHITE;
        Color outline = dark ? new Color(255, 255, 255, 14) : new Color(0, 0, 0, 22);
        Font keyFont = new Font(fontFamily, Font.PLAIN, 1).deriveFont((float) Math.max(16.0D, keyRect(0, pw, ph)[3] * 0.36D));
        Font numFont = new Font(boldFamily, Font.PLAIN, 1).deriveFont((float) Math.max(18.0D, keyRect(0, pw, ph)[3] * 0.42D));
        for (int i = 0; i < IDS.length; i++) {
            String id = IDS[i];
            double[] r = keyRect(i, pw, ph);
            boolean hover = i == hoverKey;
            boolean isDigit = Character.isDigit(id.charAt(0)) || id.equals(".") || id.equals("NEG");
            boolean isEquals = id.equals("=");
            Color fill = isEquals ? (hover ? accentHover : accent) : isDigit ? (hover ? digitHover : digit) : (hover ? otherHover : other);
            double gap = Math.max(2.0D, Math.min(r[2], r[3]) * 0.05D);
            double cx = r[0] + r[2] / 2;
            double cy = r[1] + r[3] / 2;
            java.awt.Shape shape;
            if (circle) {
                double d = Math.min(r[2], r[3]) - gap * 2;
                shape = new Ellipse2D.Double(cx - d / 2, cy - d / 2, d, d);
            } else {
                shape = new RoundRectangle2D.Double(r[0] + gap, r[1] + gap, r[2] - gap * 2, r[3] - gap * 2, 10, 10);
            }
            g.setColor(fill);
            g.fill(shape);
            if (!isEquals) {
                g.setColor(outline);
                g.setStroke(new java.awt.BasicStroke(1.0F));
                g.draw(shape);
            }
            g.setColor(isEquals ? accentText : text);
            drawKeyLabel(g, id, cx, cy, isDigit ? numFont : keyFont, r);
        }
        g.dispose();
        return image;
    }

    private void drawKeyLabel(Graphics2D g, String id, double cx, double cy, Font font, double[] r) {
        g.setFont(font);
        FontMetrics fm = g.getFontMetrics();
        double base = cy + fm.getAscent() * 0.36D;
        switch (id) {
            case "BK": {
                // backspace symbol drawn as a shape so it never depends on a font
                double w = Math.min(r[2], r[3]) * 0.34D;
                double h = w * 0.62D;
                Path2D p = new Path2D.Double();
                p.moveTo(cx - w / 2, cy);
                p.lineTo(cx - w / 5, cy - h / 2);
                p.lineTo(cx + w / 2, cy - h / 2);
                p.lineTo(cx + w / 2, cy + h / 2);
                p.lineTo(cx - w / 5, cy + h / 2);
                p.closePath();
                g.setStroke(new java.awt.BasicStroke((float) Math.max(1.3D, w * 0.07D)));
                g.draw(p);
                double k = h * 0.22D;
                double mx = cx + w * 0.12D;
                g.draw(new java.awt.geom.Line2D.Double(mx - k, cy - k, mx + k, cy + k));
                g.draw(new java.awt.geom.Line2D.Double(mx - k, cy + k, mx + k, cy - k));
                return;
            }
            case "SQ": {
                int wx = fm.stringWidth("x");
                Font sup = font.deriveFont(font.getSize2D() * 0.58F);
                g.drawString("x", (float) (cx - (wx + g.getFontMetrics(sup).stringWidth("2")) / 2.0D), (float) base);
                g.setFont(sup);
                g.drawString("2", (float) (cx - (wx + g.getFontMetrics(sup).stringWidth("2")) / 2.0D + wx), (float) (base - fm.getAscent() * 0.38D));
                return;
            }
            case "ROOT": {
                int w = fm.stringWidth("√x");
                g.drawString("√x", (float) (cx - w / 2.0D), (float) base);
                return;
            }
            case "INV": {
                Font sm = font.deriveFont(font.getSize2D() * 0.62F);
                String one = "1";
                String over = "x";
                double total = fm.stringWidth("1") * 0.6D + fm.stringWidth("/") + fm.stringWidth("x") * 0.6D;
                double x = cx - total / 2.0D;
                g.setFont(sm);
                g.drawString(one, (float) x, (float) (base - fm.getAscent() * 0.18D));
                g.setFont(font);
                g.drawString("/", (float) (x + g.getFontMetrics(sm).stringWidth(one) * 0.9D), (float) base);
                g.setFont(sm);
                g.drawString(over, (float) (x + g.getFontMetrics(sm).stringWidth(one) * 0.9D + fm.stringWidth("/") * 0.95D), (float) (base + fm.getAscent() * 0.1D));
                return;
            }
            default:
                break;
        }
        String label = switch (id) {
            case "/" -> "÷";
            case "x" -> "×";
            case "-" -> "−";
            case "NEG" -> "+/−";
            default -> id;
        };
        g.drawString(label, (float) (cx - fm.stringWidth(label) / 2.0D), (float) base);
    }

    /** Segoe UI where installed (Windows), else a sans-serif the system has. */
    private void pickFonts() {
        if (fontFamily != null) {
            return;
        }
        fontFamily = hasFont("Segoe UI") ? "Segoe UI" : Font.SANS_SERIF;
        boldFamily = hasFont("Segoe UI Semibold") ? "Segoe UI Semibold" : fontFamily;
    }

    private static boolean hasFont(String name) {
        return new Font(name, Font.PLAIN, 12).getFamily(Locale.ENGLISH).equalsIgnoreCase(name);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            double guiScale = minecraft.getWindow().getGuiScale();
            int pw = texW > 0 ? texW : (int) Math.round(width * guiScale);
            int ph = texH > 0 ? texH : (int) Math.round(height * guiScale);
            int px = (int) Math.round(event.x() * guiScale);
            int py = (int) Math.round(event.y() * guiScale);
            int key = hitKey(px, py, pw, ph);
            if (key >= 0) {
                press(IDS[key]);
                return true;
            }
            int mem = hitMemory(px, py, pw, ph);
            if (mem >= 0) {
                memoryPress(MEMORY[mem]);
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int cp = event.codepoint();
        if ((cp >= '0' && cp <= '9') || cp == '.' || cp == '+' || cp == '-' || cp == '/' || cp == '%') {
            press(String.valueOf((char) cp));
            return true;
        }
        if (cp == '*' || cp == 'x' || cp == 'X') {
            press("x");
            return true;
        }
        if (cp == '=') {
            press("=");
            return true;
        }
        if (cp == 'r' || cp == 'R') {
            press("INV");
            return true;
        }
        if (cp == '@') {
            press("ROOT");
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == 257 || key == 335) {
            press("=");
            return true;
        }
        if (key == 259) {
            press("BK");
            return true;
        }
        if (key == 261) {
            press("CE");
            return true;
        }
        return super.keyPressed(event);
    }

    // ------------------------------------------------------------------ calculator logic

    private void clearAll() {
        display = "0";
        line = "";
        acc = null;
        op = 0;
        fresh = true;
        error = null;
    }

    private BigDecimal current() {
        try {
            return new BigDecimal(display.endsWith(".") ? display + "0" : display);
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }

    private void memoryPress(String key) {
        if (error != null) {
            return;
        }
        switch (key) {
            case "MC":
                memory = null;
                break;
            case "MR":
                if (memory != null) {
                    display = format(memory);
                    fresh = true;
                }
                break;
            case "M+":
                memory = (memory == null ? BigDecimal.ZERO : memory).add(current(), MC);
                fresh = true;
                break;
            case "M-":
                memory = (memory == null ? BigDecimal.ZERO : memory).subtract(current(), MC);
                fresh = true;
                break;
            case "MS":
                memory = current();
                fresh = true;
                break;
            default:
                break;
        }
        dirty = true;
    }

    private void press(String key) {
        dirty = true;
        if (error != null && !key.equals("C") && !key.equals("CE")) {
            clearAll();
        }
        switch (key) {
            case "C":
                clearAll();
                return;
            case "CE":
                display = "0";
                fresh = true;
                error = null;
                return;
            case "BK":
                if (!fresh && display.length() > 1) {
                    display = display.substring(0, display.length() - 1);
                    if (display.equals("-")) {
                        display = "0";
                    }
                } else if (fresh) {
                    line = "";
                } else {
                    display = "0";
                }
                return;
            case "NEG":
                if (!display.equals("0")) {
                    display = display.startsWith("-") ? display.substring(1) : "-" + display;
                }
                return;
            case "%": {
                BigDecimal value = current();
                BigDecimal percent = (op != 0 && acc != null) ? acc.multiply(value, MC).divide(BigDecimal.valueOf(100), MC) : BigDecimal.ZERO;
                display = format(percent);
                fresh = true;
                return;
            }
            case "INV": {
                BigDecimal value = current();
                if (value.signum() == 0) {
                    error = "Cannot divide by zero";
                    return;
                }
                line = "1/(" + group(format(value)) + ")";
                display = format(BigDecimal.ONE.divide(value, MC));
                fresh = true;
                return;
            }
            case "SQ": {
                BigDecimal value = current();
                line = "sqr(" + group(format(value)) + ")";
                display = format(value.multiply(value, MC));
                fresh = true;
                return;
            }
            case "ROOT": {
                BigDecimal value = current();
                if (value.signum() < 0) {
                    error = "Invalid input";
                    return;
                }
                line = "√(" + format(value) + ")";
                display = format(value.sqrt(MC));
                fresh = true;
                return;
            }
            case ".":
                if (fresh) {
                    display = "0.";
                    fresh = false;
                } else if (!display.contains(".")) {
                    display += ".";
                }
                return;
            case "+":
            case "-":
            case "x":
            case "/":
                commit();
                if (error != null) {
                    return;
                }
                op = key.charAt(0);
                line = group(format(acc)) + " " + symbol(op);
                fresh = true;
                return;
            case "=": {
                if (op != 0 && acc != null) {
                    BigDecimal right = current();
                    String left = group(format(acc));
                    char used = op;
                    commit();
                    if (error == null) {
                        line = left + " " + symbol(used) + " " + group(format(right)) + " =";
                    }
                } else {
                    line = group(format(current())) + " =";
                }
                op = 0;
                fresh = true;
                return;
            }
            default:
                if (fresh || display.equals("0")) {
                    display = key;
                    fresh = false;
                } else if (display.replace("-", "").replace(".", "").length() < 16) {
                    display += key;
                }
        }
    }

    private void commit() {
        BigDecimal value = current();
        if (op == 0 || acc == null) {
            acc = value;
        } else {
            BigDecimal result = apply(acc, op, value);
            if (result == null) {
                error = "Cannot divide by zero";
                acc = null;
                op = 0;
                line = "";
                fresh = true;
                return;
            }
            acc = result;
        }
        display = format(acc);
    }

    private static String symbol(char operator) {
        return switch (operator) {
            case '/' -> "÷";
            case 'x' -> "×";
            case '-' -> "−";
            default -> String.valueOf(operator);
        };
    }

    private static BigDecimal apply(BigDecimal a, char operator, BigDecimal b) {
        switch (operator) {
            case '+':
                return a.add(b, MC);
            case '-':
                return a.subtract(b, MC);
            case 'x':
                return a.multiply(b, MC);
            case '/':
                return b.signum() == 0 ? null : a.divide(b, MC);
            default:
                return b;
        }
    }

    private static String format(BigDecimal value) {
        BigDecimal rounded = value.round(MC);
        if (rounded.signum() == 0) {
            return "0";
        }
        return rounded.stripTrailingZeros().toPlainString();
    }

    /** 1234567.5 -> 1,234,567.5 like the real app (a typed trailing dot is kept). */
    private static String group(String raw) {
        String sign = raw.startsWith("-") ? "-" : "";
        String body = sign.isEmpty() ? raw : raw.substring(1);
        int dot = body.indexOf('.');
        String whole = dot < 0 ? body : body.substring(0, dot);
        String rest = dot < 0 ? "" : body.substring(dot);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < whole.length(); i++) {
            if (i > 0 && (whole.length() - i) % 3 == 0) {
                out.append(',');
            }
            out.append(whole.charAt(i));
        }
        return sign + out + rest;
    }
}
