/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.extra.NameSwap;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Local Username everywhere: every Component is turned into drawable text through getVisualOrderText, so swapping
 * here covers item lore (auction house "Seller: ..."), container titles, signs, name tags, toasts and so on.
 * The swapped text is not cached on the component, so turning the module off or renaming takes effect at once.
 */
@Mixin(MutableComponent.class)
public abstract class ComponentNameMixin {
    @Inject(method = "getVisualOrderText", at = @At("HEAD"), cancellable = true, require = 0)
    private void bagel$localName(CallbackInfoReturnable<FormattedCharSequence> cir) {
        Component self = (Component) (Object) this;
        Component swapped = NameSwap.swap(self);
        if (swapped != null && swapped != self) {
            cir.setReturnValue(Language.getInstance().getVisualOrder(swapped));
        }
    }
}
