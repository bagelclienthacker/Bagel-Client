/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.ui;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Flat single-colour look for buttons. RoundedUi.surface delegates here: anything 32px tall or
 * less is drawn as ONE rounded rectangle (no outline colour), bigger panels keep their outline.
 */
public final class ButtonStyle {
    private static final int NORMAL = 0xFF2A2420;
    private static final int HOVER = 0xFF4A3827;
    private static final int DISABLED = 0xFF1B1816;
    private static final int OLD_NORMAL = -804253675;
    private static final int OLD_HOVER = -14213094;
    private static final int OLD_DISABLED = -1458565099;
    private static final int HOVER_BORDER = -25049;

    private ButtonStyle() {}

    public static void surface(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int fill, int border) {
        if (h > 32) {
            RoundedUi.fill(g, x, y, w, h, r, border);
            RoundedUi.fill(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
            return;
        }
        RoundedUi.fill(g, x, y, w, h, r, flat(fill, border));
    }

    static int flat(int fill, int border) {
        if (fill == OLD_NORMAL) {
            return NORMAL;
        }
        if (fill == OLD_HOVER) {
            return HOVER;
        }
        if (fill == OLD_DISABLED) {
            return DISABLED;
        }
        int color = fill;
        if (border == HOVER_BORDER) {
            color = mix(color, 0xFFFF9E27, 0.22f);
        }
        int alpha = Math.max(color >>> 24, 0xE6);
        return (alpha << 24) | (color & 0xFFFFFF);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }
}
