/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side estimate of what an explosion would do to an entity: distance falloff, line-of-sight exposure through
 * blocks, difficulty scaling for players, armor, toughness, Resistance, Protection and Blast Protection.
 * Absorption hearts are counted by {@link #health}.
 */
final class Explosions {
    static final float CRYSTAL = 6.0F;
    static final float ANCHOR = 5.0F;
    static final float BED = 5.0F;

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private Explosions() {}

    static float health(LivingEntity entity) {
        return entity.getHealth() + entity.getAbsorptionAmount();
    }

    /** Fast upper bound: full exposure, no terrain. Used to skip hopeless positions before any ray is cast. */
    static float upperBound(Vec3 center, float power, LivingEntity entity) {
        double radius = power * 2.0D;
        double distance = Math.sqrt(entity.distanceToSqr(center)) / radius;
        if (distance > 1.0D) {
            return 0.0F;
        }
        return reduce(entity, raw(1.0D - distance, radius));
    }

    /**
     * @param terrain whether blocks between the blast and the entity shield it (the vanilla rule); false assumes open air,
     *                which is the worst case for the entity
     * @param skip    a block cell that is treated as air because the explosion removes it first (the anchor itself)
     */
    static float damage(ClientLevel level, Vec3 center, float power, LivingEntity entity, boolean terrain, BlockPos skip) {
        return damage(level, center, power, entity, terrain, skip, null);
    }

    /** Same, with a second cell that is removed by the blast (the other half of a bed). */
    static float damage(ClientLevel level, Vec3 center, float power, LivingEntity entity, boolean terrain, BlockPos skip, BlockPos skip2) {
        double radius = power * 2.0D;
        double distance = Math.sqrt(entity.distanceToSqr(center)) / radius;
        if (distance > 1.0D) {
            return 0.0F;
        }
        double seen = terrain ? exposure(level, center, entity, skip, skip2) : 1.0D;
        double impact = (1.0D - distance) * seen;
        if (impact <= 0.0D) {
            return 0.0F;
        }
        return reduce(entity, raw(impact, radius));
    }

    private static float raw(double impact, double radius) {
        return (float) (int) ((impact * impact + impact) / 2.0D * 7.0D * radius + 1.0D);
    }

    private static float reduce(LivingEntity entity, float damage) {
        if (entity instanceof Player) {
            Difficulty difficulty = Minecraft.getInstance().level == null ? Difficulty.NORMAL : Minecraft.getInstance().level.getDifficulty();
            if (difficulty == Difficulty.PEACEFUL) {
                return 0.0F;
            }
            if (difficulty == Difficulty.EASY) {
                damage = Math.min(damage / 2.0F + 1.0F, damage);
            } else if (difficulty == Difficulty.HARD) {
                damage = damage * 3.0F / 2.0F;
            }
        }
        float armor = entity.getArmorValue();
        float toughness = (float) entity.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
        float reduction = Mth.clamp(armor - damage / (2.0F + toughness / 4.0F), armor * 0.2F, 20.0F);
        damage *= 1.0F - reduction / 25.0F;

        MobEffectInstance resistance = entity.getEffect(MobEffects.RESISTANCE);
        if (resistance != null) {
            damage = Math.max(damage * (25 - (resistance.getAmplifier() + 1) * 5) / 25.0F, 0.0F);
        }
        int protection = 0;
        for (EquipmentSlot slot : ARMOR) {
            ItemStack stack = entity.getItemBySlot(slot);
            if (!stack.isEmpty()) {
                protection += level(stack, Enchantments.PROTECTION) + level(stack, Enchantments.BLAST_PROTECTION) * 2;
            }
        }
        protection = Math.min(protection, 20);
        return Math.max(damage * (1.0F - protection / 25.0F), 0.0F);
    }

    private static int level(ItemStack stack, ResourceKey<Enchantment> key) {
        try {
            Holder<Enchantment> holder = Minecraft.getInstance().level.registryAccess()
                    .lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(key);
            return EnchantmentHelper.getItemEnchantmentLevel(holder, stack);
        } catch (RuntimeException e) {
            return 0;
        }
    }

    /** Share of sample points on the entity's box that can see the blast center (vanilla getSeenPercent). */
    static double exposure(ClientLevel level, Vec3 center, Entity entity, BlockPos skip, BlockPos skip2) {
        AABB box = entity.getBoundingBox();
        double sx = 1.0D / ((box.maxX - box.minX) * 2.0D + 1.0D);
        double sy = 1.0D / ((box.maxY - box.minY) * 2.0D + 1.0D);
        double sz = 1.0D / ((box.maxZ - box.minZ) * 2.0D + 1.0D);
        if (sx < 0.0D || sy < 0.0D || sz < 0.0D) {
            return 0.0D;
        }
        double ox = (1.0D - Math.floor(1.0D / sx) * sx) / 2.0D;
        double oz = (1.0D - Math.floor(1.0D / sz) * sz) / 2.0D;
        int clear = 0;
        int total = 0;
        for (double x = 0.0D; x <= 1.0D; x += sx) {
            for (double y = 0.0D; y <= 1.0D; y += sy) {
                for (double z = 0.0D; z <= 1.0D; z += sz) {
                    Vec3 from = new Vec3(
                            Mth.lerp(x, box.minX, box.maxX) + ox,
                            Mth.lerp(y, box.minY, box.maxY),
                            Mth.lerp(z, box.minZ, box.maxZ) + oz);
                    BlockHitResult hit = level.clip(new ClipContext(from, center, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity));
                    if (hit.getType() == HitResult.Type.MISS || (skip != null && hit.getBlockPos().equals(skip)) || (skip2 != null && hit.getBlockPos().equals(skip2))) {
                        clear++;
                    }
                    total++;
                }
            }
        }
        return total == 0 ? 0.0D : (double) clear / total;
    }
}
