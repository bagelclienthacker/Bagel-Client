/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.util.CameraRig;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Vanilla hides your own player model whenever the camera belongs to another entity (like in spectator).
 * While Freecam is active this makes that check think the camera is you, so your player stays visible.
 */
@Mixin(LevelExtractor.class)
public abstract class FreecamRenderMixin {
    @Redirect(method = "extractVisibleEntities",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;entity()Lnet/minecraft/world/entity/Entity;", ordinal = 3),
            require = 0)
    private Entity bagel$showOwnPlayer(Camera camera) {
        if (CameraRig.mode() == CameraRig.Mode.FREECAM) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                return mc.player;
            }
        }
        return camera.entity();
    }
}
