/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.render;

import gg.bagel.client.BagelClient;
import gg.bagel.client.extra.EntityGlow;
import gg.bagel.client.extra.StorageColors;
import gg.bagel.client.module.Module;
import gg.bagel.client.render.BagelOverlay.BlockTarget;
import gg.bagel.client.util.VanillaMode;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

/**
 * Screen-space drawing for the entity and block ESPs with per-module tracers.
 * Replaces BagelOverlay.renderEntities / renderBlocks (see Patch0111).
 */
public final class BagelEsp {
    private static final int ITEM_COLOR = -11894;
    private static final int PLAYER_COLOR = -39311;
    private static final int MOB_COLOR = -10166142;
    private static boolean warned;

    private BagelEsp() {}

    private static boolean on(String name) {
        Module m = BagelClient.MODULES.byName(name);
        return m != null && m.enabled();
    }

    /** Tracers for one ESP: its own toggle, or the global Tracers module. */
    static boolean tracers(String module, boolean global) {
        if (global) {
            return true;
        }
        Module m = BagelClient.MODULES.byName(module);
        return m != null && m.enabled() && m.booleanSetting("tracers", false);
    }

    public static void entities(GuiGraphicsExtractor g, Minecraft mc, int w, int h) {
        try {
            drawEntities(g, mc, w, h);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                BagelClient.LOGGER.warn("Bagel entity ESP failed", t);
            }
        }
    }

    public static void blocks(GuiGraphicsExtractor g, Minecraft mc, int w, int h) {
        try {
            drawBlocks(g, mc, w, h);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                BagelClient.LOGGER.warn("Bagel block ESP failed", t);
            }
        }
    }

    /** Entity ESP filter (players / mobs / names) for other classes. */
    public static boolean entityPasses(Entity entity) {
        return BagelOverlay.matchesEntityFilter(entity);
    }

    /** Receives every entity / item the ESP wants a box and/or a tracer for (interpolated bounding box). */
    public interface EntitySink {
        void entity(AABB aabb, int color, boolean item, boolean box, boolean tracer);
    }

    /** Same filters as the 2D path, used by the world-space (through-wall) renderer. */
    public static void worldEntities(Minecraft mc, float partial, EntitySink sink) {
        if (VanillaMode.active() || mc.level == null || mc.player == null) {
            return;
        }
        boolean entityEsp = on("Entity ESP");
        boolean itemEsp = on("Item ESP");
        // the Tracers module only draws tracers to entities, never to items or blocks
        boolean entityTracers = tracers("Entity ESP", on("Tracers"));
        boolean itemTracers = tracers("Item ESP", false);
        if (!entityEsp && !itemEsp && !entityTracers && !itemTracers) {
            return;
        }
        int count = 0;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player) {
                continue;
            }
            boolean item = entity instanceof ItemEntity;
            if (!item && !(entity instanceof LivingEntity)) {
                continue;
            }
            boolean box = item ? itemEsp : entityEsp;
            boolean tracer = item ? itemTracers : entityTracers;
            if (!box && !tracer) {
                continue;
            }
            int range = item
                    ? BagelScan.moduleInt("Item ESP", "range", 48)
                    : BagelScan.moduleInt("Entity ESP", "range", 48);
            if (entity.distanceToSqr(mc.player) > (double) range * range) {
                continue;
            }
            if (count++ >= 1000) {
                break;
            }
            if (item ? !BagelOverlay.matchesItemFilter((ItemEntity) entity) : !BagelOverlay.matchesEntityFilter(entity)) {
                continue;
            }
            int color = item ? ITEM_COLOR : entity instanceof Player ? PLAYER_COLOR : MOB_COLOR;
            double dx = (entity.xo - entity.getX()) * (1.0D - partial);
            double dy = (entity.yo - entity.getY()) * (1.0D - partial);
            double dz = (entity.zo - entity.getZ()) * (1.0D - partial);
            sink.entity(entity.getBoundingBox().move(dx, dy, dz).inflate(0.02D), color, item, box, tracer);
        }
    }

    private static void drawEntities(GuiGraphicsExtractor g, Minecraft mc, int w, int h) {
        if (VanillaMode.active() || mc.level == null || mc.player == null) {
            return;
        }
        boolean entityEsp = on("Entity ESP");
        boolean itemEsp = on("Item ESP");
        boolean globalTracers = on("Tracers");
        boolean entityTracers = tracers("Entity ESP", globalTracers);
        boolean itemTracers = tracers("Item ESP", false);
        if (!entityEsp && !itemEsp && !entityTracers && !itemTracers) {
            return;
        }
        Module entityModule = BagelClient.MODULES.byName("Entity ESP");
        Module itemModule = BagelClient.MODULES.byName("Item ESP");
        int count = 0;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player) {
                continue;
            }
            boolean item = entity instanceof ItemEntity;
            if (item && !itemEsp && !itemTracers) {
                continue;
            }
            if (!item && !(entity instanceof LivingEntity)) {
                continue;
            }
            if (!item && !entityEsp && !entityTracers) {
                continue;
            }
            int range = item
                    ? BagelScan.moduleInt("Item ESP", "range", 48)
                    : BagelScan.moduleInt("Entity ESP", "range", 48);
            if (entity.distanceToSqr(mc.player) > (double) range * range) {
                continue;
            }
            if (count++ >= 1000) {
                break;
            }
            if (item ? !BagelOverlay.matchesItemFilter((ItemEntity) entity) : !BagelOverlay.matchesEntityFilter(entity)) {
                continue;
            }
            int color = item ? ITEM_COLOR : entity instanceof Player ? PLAYER_COLOR : MOB_COLOR;
            AABB aabb = entity.getBoundingBox().inflate(0.04D);
            BagelOverlay.ScreenBox box = BagelOverlay.projectBox(mc, aabb, w, h);
            if (box == null) {
                continue;
            }
            boolean boxOn = item ? itemEsp : entityEsp;
            if (boxOn && !WorldEsp.working() && (item || !EntityGlow.highlightStyle())) {
                BagelOverlay.drawBox(g, box, color);
            }
            boolean tracerOn = item ? itemTracers : entityTracers;
            if (tracerOn && !WorldEsp.working()) {
                Module m = item ? itemModule : entityModule;
                drawTracer(g, m, box, w, h, color);
            }
        }
    }

    private static void drawTracer(GuiGraphicsExtractor g, Module m, BagelOverlay.ScreenBox box, int w, int h, int fallback) {
        int color = fallback;
        int width = 1;
        String origin = "bottom";
        String target = "feet";
        if (m != null) {
            width = Math.max(1, Math.min(6, m.intSetting("tracer_width", 1)));
            origin = m.stringSetting("tracer_origin", "bottom").trim().toLowerCase();
            target = m.stringSetting("tracer_target", "feet").trim().toLowerCase();
        }
        int ox = w / 2;
        int oy = origin.equals("top") ? 0 : origin.equals("center") ? h / 2 : h - 1;
        int tx = box.centerX();
        int ty = target.equals("head") ? box.top() : target.equals("body") ? (box.top() + box.bottom()) / 2 : box.bottom();
        thickLine(g, ox, oy, tx, ty, color, width);
    }

    static void thickLine(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color, int width) {
        boolean flat = Math.abs(x2 - x1) >= Math.abs(y2 - y1);
        for (int i = 0; i < width; i++) {
            int offset = i - (width - 1) / 2;
            if (flat) {
                BagelOverlay.drawLine(g, x1, y1 + offset, x2, y2 + offset, color);
            } else {
                BagelOverlay.drawLine(g, x1 + offset, y1, x2 + offset, y2, color);
            }
        }
    }

    private static void drawBlocks(GuiGraphicsExtractor g, Minecraft mc, int w, int h) {
        if (VanillaMode.active() || mc.player == null) {
            return;
        }
        boolean storage = on("Storage ESP");
        boolean blockEsp = on("Block ESP");
        boolean spawner = on("Spawner ESP");
        boolean highlights = on("Block Highlights");
        if (!storage && !blockEsp && !spawner && !highlights) {
            return;
        }
        boolean globalTracers = on("Tracers");
        boolean[] tracer = {
            tracers("Storage ESP", false) && storage,
            tracers("Block ESP", false) && blockEsp,
            tracers("Spawner ESP", false) && spawner,
            tracers("Block Highlights", false) && highlights,
        };
        List<BlockTarget> targets = BagelOverlay.blockTargets;
        for (int i = 0; i < targets.size(); i++) {
            BlockTarget target = targets.get(i);
            int kind = BagelScan.kind(i);
            AABB aabb = new AABB(target.pos()).inflate(0.02D);
            BagelOverlay.ScreenBox box = BagelOverlay.projectBox(mc, aabb, w, h);
            if (box == null) {
                continue;
            }
            if (tracer[Math.max(0, Math.min(3, kind))] && !WorldEsp.working()) {
                BagelOverlay.drawLine(g, w / 2, h - 1, box.centerX(), box.bottom(), target.color());
            }
        }
    }
}
