/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Crystal Aura: places end crystals next to a target and detonates them, judging every crystal by the damage it would
 * deal to the target and to you (distance, line of sight through blocks, armor, Resistance, Protection).
 *
 * <p>Rules: a crystal position or an existing crystal is only used when it deals at least "min_target_damage" (or kills),
 * costs you at most "max_self_damage" and never kills you, and, with "efficient", hurts the target more than you.
 * With "obsidian" it builds a support block when nothing usable exists. Aim goes into the normal movement packet.
 *
 * <p>Not ported from the AUTISM version: crystal spam, vulnerable spam, defend and the crystal view overlay. The AUTISM
 * Lite jar ships its settings but not its algorithm, so everything above is Bagel's own.
 */
public final class CrystalAura extends Module {
    public static final String NAME = "Crystal Aura";

    private static final int MAX_SCAN = 5;
    private static final int EXACT_LIMIT = 14;

    private final SwapState swap = new SwapState();
    private final Map<Integer, Long> recentBreaks = new HashMap<>();
    private final Map<BlockPos, Long> recentPlaces = new HashMap<>();
    private long nextPlaceAt;
    private long nextBreakAt;

    public CrystalAura() {
        super(NAME, "Places and detonates end crystals by calculated damage", Category.COMBAT);
        setting("place", Boolean.TRUE);
        setting("destroy", Boolean.TRUE);
        setting("obsidian", Boolean.TRUE);
        setting("target_range", 8.0D);
        setting("targeting", "Distance");
        setting("entities", "minecraft:player");
        setting("hurt_time", 10);
        setting("switch_back_delay", 20);
        setting("only_above", Boolean.FALSE);
        setting("min_target_damage", 5.0D);
        setting("max_self_damage", 4.0D);
        setting("efficient", Boolean.TRUE);
        setting("terrain", Boolean.TRUE);
        setting("place_delay", 75);
        setting("destroy_delay", 50);
        setting("jitter", 15);
        setting("place_range", 4.5D);
        setting("break_range", 3.0D);
        setting("rotation", "silent");
    }

    @Override
    protected void onDisable(Minecraft mc) {
        swap.restore(mc, mc.player);
        recentBreaks.clear();
        recentPlaces.clear();
        SilentAim.release();
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (!CombatUtil.canRun(mc, player)) {
            return;
        }
        long now = System.currentTimeMillis();
        recentBreaks.values().removeIf(t -> now - t > 300L);
        recentPlaces.values().removeIf(t -> now - t > 450L);

        boolean acted = false;
        if (!player.isUsingItem() && !mc.gameMode.isDestroying() && !SilentAim.blocked(player)) {
            List<LivingEntity> targets = targets(mc, player);
            if (!targets.isEmpty()) {
                if (booleanSetting("destroy", true) && now >= nextBreakAt) {
                    acted = destroy(mc, player, targets, now);
                }
                if (!acted && booleanSetting("place", true) && now >= nextPlaceAt) {
                    acted = place(mc, player, targets.get(0), now);
                }
            }
        }
        swap.tick(mc, player, acted, intSetting("switch_back_delay", 20));
    }

    // ------------------------------------------------------------------ targets

    private List<LivingEntity> targets(Minecraft mc, LocalPlayer player) {
        double range = Math.max(1.0D, doubleSetting("target_range", 8.0D));
        int maxHurt = Math.max(0, intSetting("hurt_time", 10));
        LivingEntity first = CombatUtil.pickTarget(this, mc, player, range, maxHurt);
        List<LivingEntity> out = new ArrayList<>();
        if (first == null) {
            return out;
        }
        out.add(first);
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (out.size() >= 3) {
                break;
            }
            if (entity != first && CombatUtil.validTarget(this, player, entity, range, maxHurt)) {
                out.add((LivingEntity) entity);
            }
        }
        return out;
    }

    private boolean terrain() {
        return booleanSetting("terrain", true);
    }

    private double breakRange(LocalPlayer player) {
        double cap = player.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE) + 1.0D;
        return Math.min(Math.max(1.0D, doubleSetting("break_range", 3.0D)), cap);
    }

    private double placeRange(LocalPlayer player) {
        double cap = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE) + 0.5D;
        return Math.min(Math.max(2.0D, doubleSetting("place_range", 4.5D)), cap);
    }

    // ------------------------------------------------------------------ damage rules

    /** Whether a blast of this size is acceptable: worth it for the target and safe for us. */
    private boolean acceptable(float targetDamage, float selfDamage, LivingEntity target, LocalPlayer player) {
        double min = Math.max(0.0D, doubleSetting("min_target_damage", 5.0D));
        double maxSelf = Math.max(0.0D, doubleSetting("max_self_damage", 4.0D));
        boolean kill = targetDamage >= Explosions.health(target);
        if (!kill && targetDamage < min) {
            return false;
        }
        if (selfDamage > maxSelf || selfDamage >= Explosions.health(player) - 1.0F) {
            return false;
        }
        return kill || !booleanSetting("efficient", true) || targetDamage > selfDamage;
    }

    // ------------------------------------------------------------------ destroy

    private boolean destroy(Minecraft mc, LocalPlayer player, List<LivingEntity> targets, long now) {
        double reach = breakRange(player);
        EndCrystal best = null;
        double bestScore = -Double.MAX_VALUE;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof EndCrystal crystal) || !crystal.isAlive() || recentBreaks.containsKey(crystal.getId())) {
                continue;
            }
            if (CombatUtil.reachTo(player, crystal) > reach) {
                continue;
            }
            Vec3 center = crystal.position();
            float self = Explosions.damage(mc.level, center, Explosions.CRYSTAL, player, terrain(), null);
            for (LivingEntity target : targets) {
                if (Explosions.upperBound(center, Explosions.CRYSTAL, target) < 1.0F) {
                    continue;
                }
                float damage = Explosions.damage(mc.level, center, Explosions.CRYSTAL, target, terrain(), null);
                if (acceptable(damage, self, target, player)) {
                    double score = damage - self * 1.5D;
                    if (score > bestScore) {
                        bestScore = score;
                        best = crystal;
                    }
                }
            }
        }
        if (best == null) {
            return false;
        }
        Vec3 point = best.getBoundingBox().getCenter();
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), point)) {
            return true; // busy turning: nothing else this tick
        }
        mc.gameMode.attack(player, best);
        player.swing(InteractionHand.MAIN_HAND);
        recentBreaks.put(best.getId(), now);
        nextBreakAt = now + CombatUtil.delayMs(intSetting("destroy_delay", 50), intSetting("jitter", 15));
        return true;
    }

    // ------------------------------------------------------------------ place

    private record Spot(BlockPos support, float target, float self, double score) {}

    private boolean place(Minecraft mc, LocalPlayer player, LivingEntity target, long now) {
        InteractionHand hand;
        int slot = -1;
        if (player.getOffhandItem().is(Items.END_CRYSTAL)) {
            hand = InteractionHand.OFF_HAND;
        } else {
            slot = Hotbar.find(player, s -> s.is(Items.END_CRYSTAL));
            hand = InteractionHand.MAIN_HAND;
            if (slot < 0) {
                return false;
            }
        }
        Spot spot = bestSpot(mc, player, target, now);
        if (spot == null) {
            return booleanSetting("obsidian", true) && buildSupport(mc, player, target, now);
        }
        Vec3 click = new Vec3(spot.support.getX() + 0.5D, spot.support.getY() + 1.0D, spot.support.getZ() + 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            return true;
        }
        if (slot >= 0) {
            swap.take(player, slot);
        }
        InteractionResult result = mc.gameMode.useItemOn(player, hand, new BlockHitResult(click, Direction.UP, spot.support, false));
        if (result.consumesAction()) {
            player.swing(hand);
        }
        recentPlaces.put(spot.support, now);
        nextPlaceAt = now + CombatUtil.delayMs(intSetting("place_delay", 75), intSetting("jitter", 15));
        return true;
    }

    private Spot bestSpot(Minecraft mc, LocalPlayer player, LivingEntity target, long now) {
        ClientLevel level = mc.level;
        double reach = placeRange(player);
        double min = Math.max(0.0D, doubleSetting("min_target_damage", 5.0D));
        boolean above = booleanSetting("only_above", false);
        Vec3 eyes = player.getEyePosition();
        BlockPos base = target.blockPosition();
        List<BlockPos> candidates = new ArrayList<>();
        List<Float> bounds = new ArrayList<>();
        for (int dx = -MAX_SCAN; dx <= MAX_SCAN; dx++) {
            for (int dz = -MAX_SCAN; dz <= MAX_SCAN; dz++) {
                for (int dy = -3; dy <= 1; dy++) {
                    BlockPos support = base.offset(dx, dy, dz);
                    if (recentPlaces.containsKey(support) || !isSupport(level.getBlockState(support)) || !level.getBlockState(support.above()).isAir()) {
                        continue;
                    }
                    if (above && support.getY() < base.getY()) {
                        continue;
                    }
                    Vec3 top = new Vec3(support.getX() + 0.5D, support.getY() + 1.0D, support.getZ() + 0.5D);
                    if (eyes.distanceTo(top) > reach) {
                        continue;
                    }
                    float bound = Explosions.upperBound(top, Explosions.CRYSTAL, target);
                    if (bound < min && bound < Explosions.health(target)) {
                        continue;
                    }
                    candidates.add(support);
                    bounds.add(bound);
                }
            }
        }
        // best upper bounds first, then exact damage for only a handful of them
        Integer[] order = new Integer[candidates.size()];
        for (int i = 0; i < order.length; i++) {
            order[i] = i;
        }
        java.util.Arrays.sort(order, (a, b) -> Float.compare(bounds.get(b), bounds.get(a)));
        Spot best = null;
        int checked = 0;
        for (Integer index : order) {
            if (checked >= EXACT_LIMIT) {
                break;
            }
            BlockPos support = candidates.get(index);
            if (!roomForCrystal(level, support)) {
                continue;
            }
            checked++;
            Vec3 top = new Vec3(support.getX() + 0.5D, support.getY() + 1.0D, support.getZ() + 0.5D);
            if (!clickable(level, eyes, top, support, player)) {
                continue;
            }
            float damage = Explosions.damage(level, top, Explosions.CRYSTAL, target, terrain(), null);
            float self = Explosions.damage(level, top, Explosions.CRYSTAL, player, terrain(), null);
            if (!acceptable(damage, self, target, player)) {
                continue;
            }
            double score = damage - self * 1.5D;
            if (best == null || score > best.score) {
                best = new Spot(support, damage, self, score);
            }
        }
        return best;
    }

    private static boolean isSupport(BlockState state) {
        return state.is(Blocks.OBSIDIAN) || state.is(Blocks.BEDROCK);
    }

    /** The crystal needs the two blocks above the support free of entities (vanilla EndCrystalItem rule). */
    private static boolean roomForCrystal(ClientLevel level, BlockPos support) {
        AABB box = new AABB(support.getX(), support.getY() + 1.0D, support.getZ(), support.getX() + 1.0D, support.getY() + 3.0D, support.getZ() + 1.0D);
        return level.getEntities((Entity) null, box, e -> !e.isSpectator()).isEmpty();
    }

    private static boolean clickable(ClientLevel level, Vec3 eyes, Vec3 point, BlockPos support, LocalPlayer player) {
        BlockHitResult hit = level.clip(new ClipContext(eyes, point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(support);
    }

    // ------------------------------------------------------------------ obsidian

    private boolean buildSupport(Minecraft mc, LocalPlayer player, LivingEntity target, long now) {
        int slot = Hotbar.find(player, s -> s.is(Items.OBSIDIAN));
        if (slot < 0 || !(player.getOffhandItem().is(Items.END_CRYSTAL) || Hotbar.find(player, s -> s.is(Items.END_CRYSTAL)) >= 0)) {
            return false;
        }
        ClientLevel level = mc.level;
        double reach = placeRange(player);
        Vec3 eyes = player.getEyePosition();
        BlockPos base = target.blockPosition();
        BlockPos bestPos = null;
        BlockPos bestSupportBlock = null;
        Direction bestFace = null;
        double bestScore = -Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -2; dy <= 0; dy++) {
                    BlockPos pos = base.offset(dx, dy, dz);
                    if (recentPlaces.containsKey(pos) || !level.getBlockState(pos).canBeReplaced() || !level.getBlockState(pos.above()).isAir()) {
                        continue;
                    }
                    if (!level.getEntities((Entity) null, new AABB(pos), e -> !e.isSpectator()).isEmpty() || !roomForCrystal(level, pos)) {
                        continue;
                    }
                    Vec3 crystal = new Vec3(pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D);
                    if (eyes.distanceTo(crystal) > reach) {
                        continue;
                    }
                    if (Explosions.upperBound(crystal, Explosions.CRYSTAL, target) < doubleSetting("min_target_damage", 5.0D)) {
                        continue;
                    }
                    Direction face = clickFace(level, pos);
                    if (face == null) {
                        continue;
                    }
                    BlockPos neighbor = pos.relative(face);
                    Vec3 click = Vec3.atCenterOf(neighbor).add(face.getOpposite().getStepX() * 0.5D, face.getOpposite().getStepY() * 0.5D, face.getOpposite().getStepZ() * 0.5D);
                    if (eyes.distanceTo(click) > reach) {
                        continue;
                    }
                    float damage = Explosions.damage(level, crystal, Explosions.CRYSTAL, target, terrain(), null);
                    float self = Explosions.damage(level, crystal, Explosions.CRYSTAL, player, terrain(), null);
                    if (!acceptable(damage, self, target, player)) {
                        continue;
                    }
                    double score = damage - self * 1.5D;
                    if (score > bestScore) {
                        bestScore = score;
                        bestPos = pos;
                        bestSupportBlock = neighbor;
                        bestFace = face.getOpposite();
                    }
                }
            }
        }
        if (bestPos == null) {
            return false;
        }
        Vec3 click = Vec3.atCenterOf(bestSupportBlock).add(bestFace.getStepX() * 0.5D, bestFace.getStepY() * 0.5D, bestFace.getStepZ() * 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            return true;
        }
        swap.take(player, slot);
        InteractionResult result = mc.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, new BlockHitResult(click, bestFace, bestSupportBlock, false));
        if (result.consumesAction()) {
            player.swing(InteractionHand.MAIN_HAND);
        }
        recentPlaces.put(bestPos, now);
        nextPlaceAt = now + CombatUtil.delayMs(intSetting("place_delay", 75), intSetting("jitter", 15));
        return true;
    }

    /** A direction from {@code pos} to a solid neighbor we can click on (preferring the block below). */
    private static Direction clickFace(ClientLevel level, BlockPos pos) {
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
        for (Direction direction : order) {
            BlockPos neighbor = pos.relative(direction);
            BlockState state = level.getBlockState(neighbor);
            if (!state.isAir() && !state.canBeReplaced() && state.isFaceSturdy(level, neighbor, direction.getOpposite())) {
                return direction;
            }
        }
        return null;
    }
}
