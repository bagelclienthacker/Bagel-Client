/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Attackable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.component.AttackRange;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.PiercingWeapon;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.Holder;

/**
 * Kill Aura, modelled on the KillAura module of AUTISM Client (GPL, the same licence Bagel Client is released under).
 * The behaviour (settings, targeting, cooldown/crit timing, auto sword, shield break, silent aim in the normal movement
 * packet) follows that module; the code is written fresh for Bagel Client.
 *
 * <ul>
 *   <li>Targets: entity filter, "targeting" order (FOV / Type / HP / Distance / Hurt Time / Age), FOV cone,
 *       scan range a little past your reach so the aim is already on target when it comes into reach.</li>
 *   <li>Silent aim: the rotation is written into the <em>normal</em> movement packet (see KillAuraRotationMixin),
 *       so Kill Aura never sends an extra movement or rotation packet. The camera never moves. Angles are snapped to
 *       your mouse sensitivity steps and turn at a limited speed.</li>
 *   <li>It only attacks once the rotation the server already knows points at the target inside your reach.</li>
 *   <li>Timing: waits for the weapon cooldown with a small random offset, optional crit waiting, optional human misses.</li>
 *   <li>Auto sword / shield break: switches to the best sword, or an axe against a raised shield, and back.</li>
 * </ul>
 */
public final class KillAura {
    private static final Random RANDOM = new Random();
    private static final double[] SCAN_H = {0.12D, 0.31D, 0.5D, 0.69D, 0.88D};
    private static final double[] SCAN_V = {0.2D, 0.35D, 0.5D, 0.65D, 0.8D};

    private static LivingEntity target;
    private static int targetId = -1;

    /** Silent rotation that goes into the movement packets while {@link #active}. */
    private static boolean active;
    private static float silentYaw;
    private static float silentPitch;
    /** What the server was last told (the value the mixin returned for the last movement packet). */
    private static float sentYaw;
    private static float sentPitch;
    private static boolean sentKnown;
    /** Counts ticks until the rotation hook (mixin) was first seen; if it never shows up, only aimed-at targets are hit. */
    private static int hookWait;
    private static int lastTickCount = Integer.MIN_VALUE / 2;

    private static int ticksSinceClick = 100;
    private static float clickOffset;
    private static double scanAddition = 2.5D;
    private static int extraTicks;
    private static boolean lastWasMiss;

    private static int driftId = -1;
    private static double driftX;
    private static double driftY;
    private static double driftZ;
    private static double driftTX;
    private static double driftTY;
    private static double driftTZ;
    private static int driftTicks;
    private static int driftTick = -1;
    private static int lostTicks;

    private static int previousSlot = -1;
    private static int switchedTo = -1;
    private static int switchBackTicks;
    private static int hotbarChangeTick = -1;
    private static int lastShieldSeenTick = -100;
    private static int shieldEntityId = -1;
    private static int tickNow;

    private static int pendingHitId = -1;
    private static int pendingHitHurt;
    private static int pendingHitTicks;

    private static Field tickerField;
    private static boolean tickerLookedUp;

    private KillAura() {}

    // ------------------------------------------------------------------ silent rotation hook

    /** Called by the mixin for every yaw that goes into a movement packet. */
    public static float outgoingYaw(LocalPlayer player, float real) {
        float out = rotationLive(player) ? silentYaw : real;
        sentYaw = out;
        sentKnown = true;
        return out;
    }

    /** Called by the mixin for every pitch that goes into a movement packet. */
    public static float outgoingPitch(LocalPlayer player, float real) {
        float out = rotationLive(player) ? silentPitch : real;
        sentPitch = out;
        return out;
    }

    /** Whether Kill Aura currently controls the rotation that goes into the movement packet. */
    public static boolean aiming(LocalPlayer player) {
        return rotationLive(player);
    }

    private static boolean rotationLive(LocalPlayer player) {
        return active && player != null && player.tickCount - lastTickCount <= 2;
    }

    // ------------------------------------------------------------------ main tick

    public static void tick(Module module, Minecraft mc, LocalPlayer player) {
        if (mc.gameMode == null || mc.level == null || player == null || !player.isAlive()) {
            reset();
            return;
        }
        tickNow++;
        if (!sentKnown) {
            hookWait++;
        }
        lastTickCount = player.tickCount;
        ticksSinceClick++;
        confirmHit(mc);
        trackCooldown(player);

        if (!canRun(mc, player)) {
            target = null;
            windDown(player);
            return;
        }
        double reach = reach(player);
        updateTarget(module, mc, player, reach);
        tickAutoSwordReset(mc, player);
        if (target == null) {
            windDown(player);
            return;
        }
        switchBackTicks = Math.max(switchBackTicks, 20);

        Vec3 eye = player.getEyePosition();
        Vec3 point = aimPoint(mc, player, target, reach);
        if (point != null) {
            point = steadyPoint(module, player, target, eye, point, reach);
        }
        float[] want = point == null ? null : anglesTo(eye, point);
        boolean ready = attackReady(module, mc, player, target);
        if (want != null) {
            turnToward(module, player, want[0], want[1], ready);
        }

        if (ready) {
            attackPhase(module, mc, player, target, reach);
        }
    }

    // ------------------------------------------------------------------ gating

    private static boolean canRun(Minecraft mc, LocalPlayer player) {
        return mc.gui.screen() == null
                && !player.isDeadOrDying()
                && !player.isSpectator()
                && !player.isUsingItem()
                && !mc.gameMode.isDestroying();
    }

    private static double reach(LocalPlayer player) {
        return Math.max(0.0D, player.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE));
    }

    // ------------------------------------------------------------------ targets

    private static boolean validate(Module module, Minecraft mc, LocalPlayer player, LivingEntity entity) {
        if (entity == player || entity.isRemoved() || entity.hurtTime > 10 || !shouldBeAttacked(module, player, entity)) {
            return false;
        }
        Vec3 center = entity.getBoundingBox().getCenter();
        float[] a = anglesTo(player.getEyePosition(), center);
        float angle = angleBetween(player.getYRot(), player.getXRot(), a[0], a[1]);
        int fov = Math.max(10, Math.min(360, module.intSetting("fov", 180)));
        if (entity == target) {
            return true; // the silent rotation does not move your camera: never drop a locked target for leaving the fov
        }
        return angle <= fov * 0.5F;
    }

    private static boolean shouldBeAttacked(Module module, LocalPlayer player, LivingEntity entity) {
        if (!(entity instanceof Attackable) || !EntitySelector.CAN_BE_PICKED.test(entity)) {
            return false;
        }
        if (entity.hasPassenger(player) || !entity.isAlive()) {
            return false;
        }
        if (entity instanceof Player other && other.isSleeping()) {
            return false;
        }
        return matches(module, entity);
    }

    static boolean matches(Module module, Entity entity) {
        String list = module.stringSetting("entities", "minecraft:player").trim();
        if (list.equals("*")) {
            return true;
        }
        String id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
        for (String part : list.split(",")) {
            String p = part.trim();
            if (p.equalsIgnoreCase(id) || p.equalsIgnoreCase("minecraft:" + id) || ("minecraft:" + p).equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }

    private static double boxedDistanceSqr(LocalPlayer player, Entity entity) {
        return entity.getBoundingBox().inflate(entity.getPickRadius()).distanceToSqr(player.getEyePosition());
    }

    private static int typeWeight(LivingEntity entity, LocalPlayer player) {
        if (entity instanceof Player) {
            return 0;
        }
        if (entity instanceof Enemy) {
            return 1;
        }
        if (entity instanceof NeutralMob neutral && neutral.getPersistentAngerTarget() != null
                && neutral.getPersistentAngerTarget().matches(player)) {
            return 2;
        }
        return Integer.MAX_VALUE;
    }

    private static Comparator<LivingEntity> comparator(Module module, LocalPlayer player) {
        String mode = module.stringSetting("targeting", "FOV").trim().toLowerCase(Locale.ROOT);
        return switch (mode) {
            case "type" -> Comparator.comparingInt((LivingEntity e) -> typeWeight(e, player));
            case "hp" -> Comparator.comparingDouble((LivingEntity e) -> e.getHealth() + e.getAbsorptionAmount());
            case "distance" -> Comparator.comparingDouble((LivingEntity e) -> boxedDistanceSqr(player, e));
            case "hurt time" -> Comparator.comparingInt((LivingEntity e) -> e.hurtTime);
            case "age" -> Comparator.comparingInt((LivingEntity e) -> -e.tickCount);
            default -> Comparator.comparingDouble((LivingEntity e) -> {
                float[] a = anglesTo(player.getEyePosition(), e.getBoundingBox().getCenter());
                return angleBetween(player.getYRot(), player.getXRot(), a[0], a[1]);
            });
        };
    }

    private static void updateTarget(Module module, Minecraft mc, LocalPlayer player, double reach) {
        double scan = reach + scanAddition;
        List<LivingEntity> candidates = new ArrayList<>();
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity instanceof LivingEntity living && validate(module, mc, player, living)
                    && boxedDistanceSqr(player, living) <= scan * scan) {
                candidates.add(living);
            }
        }
        candidates.sort(comparator(module, player));

        LivingEntity chosen = null;
        // keep the current target while it stays valid and in range
        if (target != null && candidates.contains(target)) {
            if (aimPoint(mc, player, target, reach) != null) {
                chosen = target;
                lostTicks = 0;
            } else if (++lostTicks <= 4) {
                chosen = target; // briefly hidden (corner, own hitbox flicker): do not flap to someone else
            }
        }
        if (chosen == null) {
            for (LivingEntity candidate : candidates) {
                if (aimPoint(mc, player, candidate, reach) != null) {
                    chosen = candidate;
                    break;
                }
            }
        }
        if (chosen == null) {
            target = null;
            targetId = -1;
            return;
        }
        if (chosen.getId() != targetId) {
            targetId = chosen.getId();
            driftId = -1;
            lastWasMiss = false;
            scanAddition = 2.0D + RANDOM.nextDouble();
        }
        target = chosen;
    }

    // ------------------------------------------------------------------ aim point

    /** A point inside the target's hitbox that can be seen and that the aim ray reaches, or null. */
    private static Vec3 aimPoint(Minecraft mc, LocalPlayer player, LivingEntity entity, double reach) {
        Vec3 eye = player.getEyePosition();
        AABB box = entity.getBoundingBox();
        updateDrift(entity);
        double w = box.getXsize();
        double h = box.getYsize();
        double d = box.getZsize();
        Vec3 preferred = new Vec3(
                box.minX + w * Mth.clamp(0.5D + driftX, 0.12D, 0.88D),
                box.minY + h * Mth.clamp(0.56D + driftY, 0.2D, 0.8D),
                box.minZ + d * Mth.clamp(0.5D + driftZ, 0.12D, 0.88D));
        if (usable(mc, player, entity, eye, preferred, reach)) {
            return preferred;
        }
        Vec3 best = null;
        double bestDist = Double.MAX_VALUE;
        for (double fy : SCAN_V) {
            for (double fx : SCAN_H) {
                for (double fz : SCAN_H) {
                    Vec3 p = new Vec3(box.minX + w * fx, box.minY + h * fy, box.minZ + d * fz);
                    double dist = p.distanceToSqr(preferred);
                    if (dist < bestDist && usable(mc, player, entity, eye, p, reach)) {
                        bestDist = dist;
                        best = p;
                    }
                }
            }
        }
        return best;
    }

    private static boolean usable(Minecraft mc, LocalPlayer player, LivingEntity entity, Vec3 eye, Vec3 point, double reach) {
        if (!visible(mc, player, eye, point)) {
            return false;
        }
        // the ray to this point has to hit the box within reach (+ the scan margin, so we can pre-aim)
        Vec3 dir = point.subtract(eye);
        double len = dir.length();
        if (len < 1.0E-6D) {
            return true;
        }
        return len <= reach + scanAddition + 1.0D;
    }

    private static boolean visible(Minecraft mc, LocalPlayer player, Vec3 from, Vec3 to) {
        return mc.level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player)).getType()
                == HitResult.Type.MISS;
    }

    /** Slow random drift of the aim point inside the hitbox, so the aim is not a perfect laser. */
    private static void updateDrift(LivingEntity entity) {
        if (driftId != entity.getId()) {
            driftId = entity.getId();
            driftX = driftY = driftZ = 0.0D;
            driftTX = driftTY = driftTZ = 0.0D;
            driftTicks = 0;
        }
        if (driftTick == tickNow) {
            return; // already advanced this tick (aimPoint is asked several times per tick)
        }
        driftTick = tickNow;
        if (--driftTicks <= 0) {
            driftTX = (RANDOM.nextDouble() - 0.5D) * 0.36D;
            driftTY = (RANDOM.nextDouble() - 0.5D) * 0.24D;
            driftTZ = (RANDOM.nextDouble() - 0.5D) * 0.36D;
            driftTicks = 8 + RANDOM.nextInt(14);
        }
        driftX += (driftTX - driftX) * 0.08D;
        driftY += (driftTY - driftY) * 0.08D;
        driftZ += (driftTZ - driftZ) * 0.08D;
    }

    // ------------------------------------------------------------------ rotation

    static float[] anglesTo(Vec3 eye, Vec3 point) {
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[] {Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90.0F, 90.0F)};
    }

    private static float angleBetween(float yawA, float pitchA, float yawB, float pitchB) {
        float dy = Mth.wrapDegrees(yawB - yawA);
        float dp = pitchB - pitchA;
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    /** One mouse count in degrees at the current sensitivity (vanilla: f^3 * 8 * 0.15). */
    private static float sensitivityStep(Minecraft mc) {
        double s = mc.options.sensitivity().get();
        double f = s * 0.6D + 0.2D;
        return (float) Math.max(0.0005D, f * f * f * 1.2D);
    }

    private static float snapTo(float base, float value, float step) {
        return base + Math.round((value - base) / step) * step;
    }

    /**
     * Decides the final aim point. Already looking at the target: stay on it and only follow its movement (a point in
     * the middle part of the hitbox, nearest to where the sent ray already is), so the aim does not wander around
     * inside the box. Not on it yet: aim at the chosen point, led a little by the target's own movement because the
     * rotation reaches the server a tick late.
     */
    private static Vec3 steadyPoint(Module module, LocalPlayer player, LivingEntity entity, Vec3 eye, Vec3 point, double reach) {
        AABB box = entity.getBoundingBox();
        if (module.booleanSetting("predict", true)) {
            double lead = 1.6D;
            double vx = Mth.clamp(entity.getX() - entity.xo, -0.6D, 0.6D) * lead;
            double vy = Mth.clamp(entity.getY() - entity.yo, -0.5D, 0.5D) * lead * 0.5D;
            double vz = Mth.clamp(entity.getZ() - entity.zo, -0.6D, 0.6D) * lead;
            point = new Vec3(
                    Mth.clamp(point.x + vx, box.minX + box.getXsize() * 0.1D, box.maxX - box.getXsize() * 0.1D),
                    Mth.clamp(point.y + vy, box.minY + box.getYsize() * 0.15D, box.maxY - box.getYsize() * 0.1D),
                    Mth.clamp(point.z + vz, box.minZ + box.getZsize() * 0.1D, box.maxZ - box.getZsize() * 0.1D));
        }
        if (!sentKnown) {
            return point;
        }
        Vec3 dir = Vec3.directionFromRotation(sentPitch, sentYaw);
        Vec3 end = eye.add(dir.scale(reach + 1.0D));
        if (box.inflate(entity.getPickRadius()).clip(eye, end).isEmpty()) {
            return point;
        }
        // on target: nearest point of the central part of the box to where the ray passes at the target's distance
        Vec3 center = box.getCenter();
        Vec3 along = eye.add(dir.scale(eye.distanceTo(center)));
        double hx = box.getXsize() * 0.5D * 0.55D;
        double hy = box.getYsize() * 0.5D * 0.55D;
        double hz = box.getZsize() * 0.5D * 0.55D;
        return new Vec3(
                Mth.clamp(along.x, center.x - hx, center.x + hx),
                Mth.clamp(along.y, center.y - hy, center.y + hy),
                Mth.clamp(along.z, center.z - hz, center.z + hz));
    }

    /** One tick of easing toward (wantYaw, wantPitch): a fraction of the remaining angle, capped, no random jumps. */
    private static void turnToward(Module module, LocalPlayer player, float wantYaw, float wantPitch, boolean imminent) {
        Minecraft mc = Minecraft.getInstance();
        float curYaw = active ? silentYaw : player.getYRot();
        float curPitch = active ? silentPitch : player.getXRot();
        float dyaw = Mth.wrapDegrees(wantYaw - curYaw);
        float dpitch = wantPitch - curPitch;
        double speed = Mth.clamp(module.doubleSetting("turn_speed", 35.0D), 5.0D, 120.0D);
        double smoothing = Mth.clamp(module.doubleSetting("smoothing", 0.45D), 0.05D, 1.0D);
        // a hit is about to happen: close in much faster so the rotation is there when the packet goes out
        double fraction = imminent ? Math.max(smoothing, 0.85D) : smoothing * (0.95D + RANDOM.nextDouble() * 0.1D);
        double maxYaw = imminent ? Math.max(speed, 70.0D) : speed;
        double maxPitch = imminent ? Math.max(speed * 0.55D, 40.0D) : speed * 0.45D;
        float step = sensitivityStep(mc);
        float moveYaw = easeStep(dyaw, fraction, maxYaw, step);
        float movePitch = easeStep(dpitch, fraction * 0.9D, maxPitch, step);
        float newYaw = curYaw + moveYaw;
        float newPitch = Mth.clamp(curPitch + movePitch, -90.0F, 90.0F);
        float baseYaw = sentKnown ? sentYaw : player.getYRot();
        float basePitch = sentKnown ? sentPitch : player.getXRot();
        newYaw = snapTo(baseYaw, baseYaw + Mth.wrapDegrees(newYaw - baseYaw), step);
        newPitch = Mth.clamp(snapTo(basePitch, newPitch, step), -90.0F, 90.0F);
        silentYaw = newYaw;
        silentPitch = newPitch;
        active = true;
    }

    private static float easeStep(float diff, double fraction, double max, float mouseStep) {
        float abs = Math.abs(diff);
        if (abs < 0.05F) {
            return 0.0F;
        }
        double move = Math.min(abs * fraction, max);
        move = Math.max(move, Math.min(abs, mouseStep)); // always at least one mouse count so it can finish
        return Math.copySign((float) Math.min(move, abs), diff);
    }

    /** No target: ease the sent rotation back to the real one, then stop touching the packets. */
    private static void windDown(LocalPlayer player) {
        if (!active) {
            return;
        }
        float dyaw = Mth.wrapDegrees(player.getYRot() - silentYaw);
        float dpitch = player.getXRot() - silentPitch;
        if (Math.abs(dyaw) < 1.0F && Math.abs(dpitch) < 1.0F) {
            active = false;
            return;
        }
        silentYaw += easeStep(dyaw, 0.45D, 30.0D, 0.05F);
        silentPitch = Mth.clamp(silentPitch + easeStep(dpitch, 0.45D, 20.0D, 0.05F), -90.0F, 90.0F);
    }

    private static void reset() {
        target = null;
        targetId = -1;
        active = false;
        sentKnown = false;
        hookWait = 0;
        previousSlot = -1;
        switchedTo = -1;
        pendingHitId = -1;
    }

    // ------------------------------------------------------------------ timing

    private static boolean hasCooldown(LocalPlayer player) {
        return player.getAttributeValue(Attributes.ATTACK_SPEED) < 20.0D;
    }

    private static float attackDelay(LocalPlayer player) {
        double speed = Math.max(0.01D, player.getAttributeValue(Attributes.ATTACK_SPEED));
        return (float) (1.0D / speed * 20.0D);
    }

    private static int tickerValue(LocalPlayer player) {
        if (!tickerLookedUp) {
            tickerLookedUp = true;
            try {
                Field f = LivingEntity.class.getDeclaredField("attackStrengthTicker");
                f.setAccessible(true);
                tickerField = f;
            } catch (ReflectiveOperationException | RuntimeException e) {
                tickerField = null;
            }
        }
        if (tickerField != null) {
            try {
                return tickerField.getInt(player);
            } catch (ReflectiveOperationException | RuntimeException e) {
                tickerField = null;
            }
        }
        float scale = player.getAttackStrengthScale(0.0F);
        float delay = attackDelay(player);
        return scale < 1.0F ? Math.round(scale * delay) : Math.round(delay) + extraTicks;
    }

    private static void trackCooldown(LocalPlayer player) {
        extraTicks = player.getAttackStrengthScale(0.0F) >= 1.0F ? extraTicks + 1 : 0;
    }

    private static boolean cooldownPassed(LocalPlayer player) {
        return tickerValue(player) >= attackDelay(player) + clickOffset;
    }

    private static void newCooldown() {
        double r = (RANDOM.nextDouble() + RANDOM.nextDouble()) * 0.5D;
        clickOffset = (float) (RANDOM.nextDouble() < 0.2D ? -r : r);
        ticksSinceClick = 0;
    }

    private static boolean attackReady(Module module, Minecraft mc, LocalPlayer player, LivingEntity entity) {
        if (player.cannotAttackWithItem(player.getMainHandItem(), 0)) {
            return false;
        }
        boolean timing = hasCooldown(player) ? cooldownPassed(player) : ticksSinceClick >= 2 + RANDOM.nextInt(2);
        if (!timing) {
            return false;
        }
        if (module.booleanSetting("criticals", false) && !player.isFallFlying() && !shieldBreakHitPending(module, entity)
                && shouldWaitForCrit(player)) {
            return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ crits

    private static boolean allowsCriticalHit(LocalPlayer player) {
        Module flight = BagelClient.MODULES.byName("Flight");
        if (flight != null && flight.enabled()) {
            return false;
        }
        return !player.onGround() && !player.isInLiquid() && !player.isPassenger() && !insideWeb(player)
                && !player.hasEffect(MobEffects.LEVITATION) && !player.hasEffect(MobEffects.BLINDNESS)
                && !player.hasEffect(MobEffects.SLOW_FALLING) && !player.onClimbable() && !player.isNoGravity()
                && !player.getAbilities().flying;
    }

    private static boolean insideWeb(LocalPlayer player) {
        return Minecraft.getInstance().level.getBlockStates(player.getBoundingBox())
                .anyMatch(state -> state.is(net.minecraft.world.level.block.Blocks.COBWEB));
    }

    /** True while a better (critical) hit is still coming: we are rising / about to fall and will stay airborne. */
    private static boolean shouldWaitForCrit(LocalPlayer player) {
        double vy = player.getDeltaMovement().y;
        if (!allowsCriticalHit(player) || vy < -0.08D) {
            return false;
        }
        float ticksLeft = Math.max(0.0F, attackDelay(player) * 0.9F - 0.5F - tickerValue(player));
        return willStayAirborne((int) (ticksLeft * 1.3F));
    }

    private static boolean willStayAirborne(int ticks) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        double vy = player.getDeltaMovement().y;
        double offset = 0.0D;
        for (int i = 0; i < ticks; i++) {
            vy = (vy - 0.08D) * 0.98D;
            offset += vy;
            if (!mc.level.noCollision(player, player.getBoundingBox().move(0.0D, offset, 0.0D))) {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ attack

    private static void attackPhase(Module module, Minecraft mc, LocalPlayer player, LivingEntity entity, double reach) {
        if (prepareWeaponSwitch(module, mc, player, entity)) {
            return; // the switch takes this tick, the hit comes on the next one
        }
        // the rotation the server already knows has to point at the target, inside reach, in the open
        float aimYaw = sentYaw;
        float aimPitch = sentPitch;
        if (!sentKnown) {
            if (hookWait < 40) {
                return;
            }
            // the rotation hook is not active (mixin did not apply): fall back to where you really look
            aimYaw = player.getYRot();
            aimPitch = player.getXRot();
        }
        ItemStack held = player.getMainHandItem();
        Vec3 eye = player.getEyePosition();
        Vec3 dir = Vec3.directionFromRotation(aimPitch, aimYaw);
        Vec3 end = eye.add(dir.scale(reach + 1.0D));
        Optional<Vec3> hit = entity.getBoundingBox().inflate(entity.getPickRadius()).clip(eye, end);
        if (hit.isEmpty() || !visible(mc, player, eye, hit.get()) || !inAttackRange(player, held, hit.get())) {
            return;
        }
        if (module.booleanSetting("miss_injection", false) && shouldMiss(module, player, entity)) {
            player.swing(InteractionHand.MAIN_HAND);
            player.resetAttackStrengthTicker();
            newCooldown();
            lastWasMiss = true;
            return;
        }
        lastWasMiss = false;
        // a sprinting hit is never a critical
        if (module.booleanSetting("criticals", false) && allowsCriticalHit(player) && player.isSprinting()) {
            player.setSprinting(false);
        }
        if (fire(module, mc, player, entity, held)) {
            newCooldown();
        }
    }

    private static boolean inAttackRange(LocalPlayer player, ItemStack held, Vec3 point) {
        AttackRange range = held.get(DataComponents.ATTACK_RANGE);
        if (range == null) {
            range = AttackRange.defaultFor(player);
        }
        return range.isInRange(player, point);
    }

    private static boolean fire(Module module, Minecraft mc, LocalPlayer player, LivingEntity entity, ItemStack held) {
        PiercingWeapon piercing = held.get(DataComponents.PIERCING_WEAPON);
        if (piercing != null && !mc.gameMode.isSpectator()) {
            mc.gameMode.piercingAttack(piercing);
            player.swing(InteractionHand.MAIN_HAND);
            queueHit(entity);
            return true;
        }
        if (!attackable(player, entity)) {
            return false;
        }
        String mode = module.stringSetting("attack_mode", "Real Input").trim().toLowerCase(Locale.ROOT);
        if (mode.equals("packet")) {
            mc.getConnection().send(new ServerboundAttackPacket(entity.getId()));
            if (!mc.gameMode.isSpectator()) {
                player.attack(entity);
                player.resetAttackStrengthTicker();
            }
            player.swing(InteractionHand.MAIN_HAND);
        } else {
            mc.gameMode.attack(player, entity);
            player.swing(InteractionHand.MAIN_HAND);
        }
        queueHit(entity);
        return true;
    }

    private static boolean attackable(LocalPlayer player, Entity entity) {
        return entity != null && entity != player && !(entity instanceof ItemEntity) && !(entity instanceof ExperienceOrb)
                && (!(entity instanceof net.minecraft.world.entity.projectile.arrow.AbstractArrow) || entity.isAttackable());
    }

    private static boolean shouldMiss(Module module, LocalPlayer player, LivingEntity entity) {
        if (lastWasMiss) {
            return false;
        }
        double chance = Math.max(1, Math.min(20, module.intSetting("miss_chance", 6))) / 100.0D;
        if (RANDOM.nextDouble() >= chance) {
            return false;
        }
        // never throw away a killing blow
        double damage = estimatedDamage(player, player.getMainHandItem());
        return entity.getHealth() + entity.getAbsorptionAmount() > damage;
    }

    // ------------------------------------------------------------------ hit feedback

    private static void queueHit(LivingEntity entity) {
        pendingHitId = entity.getId();
        pendingHitHurt = entity.hurtTime;
        pendingHitTicks = 6;
    }

    private static void confirmHit(Minecraft mc) {
        if (pendingHitId < 0) {
            return;
        }
        Entity e = mc.level.getEntity(pendingHitId);
        if (e instanceof LivingEntity living && living.hurtTime > pendingHitHurt) {
            Module m = BagelClient.MODULES.byName("Kill Aura");
            if (m == null || m.booleanSetting("hitsound", true)) {
                mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ARROW_HIT_PLAYER, 1.0F, 0.7F));
            }
            pendingHitId = -1;
            return;
        }
        if (--pendingHitTicks <= 0) {
            pendingHitId = -1;
        }
    }

    // ------------------------------------------------------------------ weapons (auto sword, shield break)

    private static boolean wouldBlockHit(LocalPlayer player, LivingEntity entity) {
        if (!entity.isBlocking()) {
            return false;
        }
        Vec3 toUs = player.position().subtract(entity.position()).multiply(1.0D, 0.0D, 1.0D);
        Vec3 facing = entity.getViewVector(1.0F).multiply(1.0D, 0.0D, 1.0D);
        return toUs.lengthSqr() > 1.0E-6D && facing.lengthSqr() > 1.0E-6D && facing.normalize().dot(toUs.normalize()) > 0.0D;
    }

    private static boolean shieldBreakEngaged(Module module, LocalPlayer player, LivingEntity entity) {
        if (!module.booleanSetting("shield_break", true)) {
            return false;
        }
        if (wouldBlockHit(player, entity)) {
            lastShieldSeenTick = tickNow;
            shieldEntityId = entity.getId();
            return true;
        }
        return entity.getId() == shieldEntityId && tickNow - lastShieldSeenTick <= 10;
    }

    private static boolean shieldBreakHitPending(Module module, LivingEntity entity) {
        LocalPlayer player = Minecraft.getInstance().player;
        return player != null && module.booleanSetting("shield_break", true) && wouldBlockHit(player, entity);
    }

    private static boolean prepareWeaponSwitch(Module module, Minecraft mc, LocalPlayer player, LivingEntity entity) {
        boolean shield = shieldBreakEngaged(module, player, entity);
        if (!module.booleanSetting("auto_sword", true) && !shield) {
            return false;
        }
        if (!hasCooldown(player)) {
            return false;
        }
        ItemStack held = player.getMainHandItem();
        if (held.get(DataComponents.PIERCING_WEAPON) != null || held.is(net.minecraft.world.item.Items.MACE)) {
            return false; // a spear or mace in hand is a deliberate choice
        }
        Integer slot = determineWeaponSlot(player, shield);
        if (slot == null || player.isUsingItem()) {
            return false;
        }
        int selected = player.getInventory().getSelectedSlot();
        if (selected == slot) {
            return false;
        }
        if (module.booleanSetting("switch_back", true) && previousSlot < 0) {
            previousSlot = selected;
        }
        switchBackTicks = 20;
        if (hotbarChangeTick == tickNow) {
            return true;
        }
        Hotbar.selectAndSend(mc, player, slot);
        switchedTo = slot;
        hotbarChangeTick = tickNow;
        return true;
    }

    private static Integer determineWeaponSlot(LocalPlayer player, boolean axeOnly) {
        Integer best = null;
        ItemStack bestStack = null;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            boolean ok = axeOnly ? stack.is(ItemTags.AXES) : stack.is(ItemTags.SWORDS) || stack.is(ItemTags.AXES);
            if (!ok) {
                continue;
            }
            if (bestStack == null || compareWeapons(player, stack, bestStack) > 0) {
                best = i;
                bestStack = stack;
            }
        }
        return best;
    }

    private static int compareWeapons(LocalPlayer player, ItemStack a, ItemStack b) {
        int c = Double.compare(estimatedDamage(player, a), estimatedDamage(player, b));
        if (c != 0) {
            return c;
        }
        c = Double.compare(secondaryValue(a), secondaryValue(b));
        if (c != 0) {
            return c;
        }
        c = Boolean.compare(a.is(ItemTags.SWORDS), b.is(ItemTags.SWORDS));
        if (c != 0) {
            return c;
        }
        c = Integer.compare(a.getMaxDamage() - a.getDamageValue(), b.getMaxDamage() - b.getDamageValue());
        if (c != 0) {
            return c;
        }
        return Integer.compare(System.identityHashCode(a), System.identityHashCode(b));
    }

    private static double attributeValue(ItemStack stack, Holder<Attribute> attribute, double base) {
        ItemAttributeModifiers mods = stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
        if (mods == null) {
            return attribute.value().sanitizeValue(base);
        }
        return attribute.value().sanitizeValue(mods.compute(attribute, base, EquipmentSlot.MAINHAND));
    }

    private static int enchantLevel(ItemStack stack, ResourceKey<Enchantment> key) {
        try {
            Holder<Enchantment> holder = Minecraft.getInstance().level.registryAccess()
                    .lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(key);
            return EnchantmentHelper.getItemEnchantmentLevel(holder, stack);
        } catch (RuntimeException e) {
            return 0;
        }
    }

    /** Damage per second style score of an item in the main hand. */
    private static double estimatedDamage(LocalPlayer player, ItemStack stack) {
        double dmg = attributeValue(stack, Attributes.ATTACK_DAMAGE, player.getAttributeBaseValue(Attributes.ATTACK_DAMAGE));
        int sharp = enchantLevel(stack, Enchantments.SHARPNESS);
        if (sharp > 0) {
            dmg += 0.5D * sharp + 0.5D;
        }
        double speed = attributeValue(stack, Attributes.ATTACK_SPEED, player.getAttributeBaseValue(Attributes.ATTACK_SPEED));
        double dps = dmg * Math.min(Math.max(speed, 0.1D), 4.0D);
        dps += Math.max(enchantLevel(stack, Enchantments.FIRE_ASPECT) * 4.0D - 1.0D, 0.0D) * 0.33D;
        return dps;
    }

    private static double secondaryValue(ItemStack stack) {
        return enchantLevel(stack, Enchantments.LOOTING) * 0.05D
                + enchantLevel(stack, Enchantments.UNBREAKING) * 0.05D
                + enchantLevel(stack, Enchantments.MENDING) * 0.1D
                - enchantLevel(stack, Enchantments.VANISHING_CURSE) * 0.1D
                + enchantLevel(stack, Enchantments.SWEEPING_EDGE) * 0.2D
                + enchantLevel(stack, Enchantments.KNOCKBACK) * 0.25D;
    }

    /** With no target for a while, put the hotbar slot back to what it was before auto sword switched it. */
    private static void tickAutoSwordReset(Minecraft mc, LocalPlayer player) {
        Module module = BagelClient.MODULES.byName("Kill Aura");
        if (module == null || !module.booleanSetting("switch_back", true) || previousSlot < 0) {
            return;
        }
        int selected = player.getInventory().getSelectedSlot();
        if (switchedTo >= 0 && selected != switchedTo) {
            // you changed slot yourself, leave it alone
            previousSlot = -1;
            switchedTo = -1;
            return;
        }
        if (target != null) {
            switchBackTicks = 20;
            return;
        }
        if (--switchBackTicks > 0 || hotbarChangeTick == tickNow) {
            return;
        }
        Hotbar.selectAndSend(mc, player, previousSlot);
        hotbarChangeTick = tickNow;
        previousSlot = -1;
        switchedTo = -1;
    }
}
