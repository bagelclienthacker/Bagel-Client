/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.chess;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** A small, self-contained chess engine: legal moves, check/mate/stalemate, and a basic alpha-beta bot. */
public final class ChessEngine {
    public static final int P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
    public static final int CASTLE = 1 << 16;
    public static final int EN_PASSANT = 1 << 17;
    private static final int[] VALUE = {0, 100, 320, 330, 500, 900, 0};
    private static final int[][] KNIGHT = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
    private static final int[][] KING = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    private static final int[][] STRAIGHT = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int[][] DIAGONAL = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    private static final int MATE = 100000;
    private static final Random RANDOM = new Random();

    private ChessEngine() {}

    /** Board position. Squares are rank * 8 + file with rank 0 = white's back rank; white pieces are positive. */
    public static final class Pos {
        public final byte[] b = new byte[64];
        public boolean white = true;
        public int castle = 15; // 1 white short, 2 white long, 4 black short, 8 black long
        public int ep = -1;
        public int half;

        Pos copy() {
            Pos p = new Pos();
            System.arraycopy(b, 0, p.b, 0, 64);
            p.white = white;
            p.castle = castle;
            p.ep = ep;
            p.half = half;
            return p;
        }
    }

    public static Pos start() {
        Pos p = new Pos();
        int[] back = {R, N, B, Q, K, B, N, R};
        for (int f = 0; f < 8; f++) {
            p.b[f] = (byte) back[f];
            p.b[8 + f] = P;
            p.b[48 + f] = -P;
            p.b[56 + f] = (byte) -back[f];
        }
        return p;
    }

    public static int from(int m) {
        return m & 63;
    }

    public static int to(int m) {
        return (m >> 6) & 63;
    }

    public static int promo(int m) {
        return (m >> 12) & 7;
    }

    private static int move(int from, int to, int promo, int flags) {
        return from | (to << 6) | (promo << 12) | flags;
    }

    private static int rank(int sq) {
        return sq >> 3;
    }

    private static int file(int sq) {
        return sq & 7;
    }

    private static boolean on(int r, int f) {
        return r >= 0 && r < 8 && f >= 0 && f < 8;
    }

    public static boolean attacked(Pos p, int sq, boolean byWhite) {
        int r = rank(sq);
        int f = file(sq);
        int pr = r + (byWhite ? -1 : 1);
        for (int df = -1; df <= 1; df += 2) {
            if (on(pr, f + df) && p.b[pr * 8 + f + df] == (byWhite ? P : -P)) {
                return true;
            }
        }
        for (int[] o : KNIGHT) {
            if (on(r + o[0], f + o[1]) && p.b[(r + o[0]) * 8 + f + o[1]] == (byWhite ? N : -N)) {
                return true;
            }
        }
        for (int[] o : KING) {
            if (on(r + o[0], f + o[1]) && p.b[(r + o[0]) * 8 + f + o[1]] == (byWhite ? K : -K)) {
                return true;
            }
        }
        for (int[] d : STRAIGHT) {
            if (slide(p, r, f, d, byWhite, R)) {
                return true;
            }
        }
        for (int[] d : DIAGONAL) {
            if (slide(p, r, f, d, byWhite, B)) {
                return true;
            }
        }
        return false;
    }

    private static boolean slide(Pos p, int r, int f, int[] d, boolean byWhite, int kind) {
        int cr = r + d[0];
        int cf = f + d[1];
        while (on(cr, cf)) {
            int piece = p.b[cr * 8 + cf];
            if (piece != 0) {
                return piece == (byWhite ? kind : -kind) || piece == (byWhite ? Q : -Q);
            }
            cr += d[0];
            cf += d[1];
        }
        return false;
    }

    public static boolean inCheck(Pos p, boolean white) {
        int king = white ? K : -K;
        for (int i = 0; i < 64; i++) {
            if (p.b[i] == king) {
                return attacked(p, i, !white);
            }
        }
        return false;
    }

    private static void addPawn(List<Integer> out, int from, int to, int promoRank) {
        if (rank(to) == promoRank) {
            for (int piece = Q; piece >= N; piece--) {
                out.add(move(from, to, piece, 0));
            }
        } else {
            out.add(move(from, to, 0, 0));
        }
    }

    private static List<Integer> pseudo(Pos p) {
        List<Integer> out = new ArrayList<>(48);
        boolean w = p.white;
        int sign = w ? 1 : -1;
        for (int sq = 0; sq < 64; sq++) {
            int piece = p.b[sq] * sign;
            if (piece <= 0) {
                continue;
            }
            int r = rank(sq);
            int f = file(sq);
            switch (piece) {
                case P -> {
                    int dir = w ? 1 : -1;
                    int promoRank = w ? 7 : 0;
                    int one = sq + 8 * dir;
                    if (p.b[one] == 0) {
                        addPawn(out, sq, one, promoRank);
                        if (r == (w ? 1 : 6) && p.b[one + 8 * dir] == 0) {
                            out.add(move(sq, one + 8 * dir, 0, 0));
                        }
                    }
                    for (int df = -1; df <= 1; df += 2) {
                        if (!on(r + dir, f + df)) {
                            continue;
                        }
                        int t = (r + dir) * 8 + f + df;
                        if (p.b[t] * sign < 0) {
                            addPawn(out, sq, t, promoRank);
                        } else if (t == p.ep) {
                            out.add(move(sq, t, 0, EN_PASSANT));
                        }
                    }
                }
                case N -> {
                    for (int[] o : KNIGHT) {
                        step(p, out, sq, r + o[0], f + o[1], sign);
                    }
                }
                case K -> {
                    for (int[] o : KING) {
                        step(p, out, sq, r + o[0], f + o[1], sign);
                    }
                    castling(p, out, w);
                }
                default -> {
                    if (piece == R || piece == Q) {
                        for (int[] d : STRAIGHT) {
                            ray(p, out, sq, d, sign);
                        }
                    }
                    if (piece == B || piece == Q) {
                        for (int[] d : DIAGONAL) {
                            ray(p, out, sq, d, sign);
                        }
                    }
                }
            }
        }
        return out;
    }

    private static void step(Pos p, List<Integer> out, int from, int r, int f, int sign) {
        if (on(r, f) && p.b[r * 8 + f] * sign <= 0) {
            out.add(move(from, r * 8 + f, 0, 0));
        }
    }

    private static void ray(Pos p, List<Integer> out, int from, int[] d, int sign) {
        int r = rank(from) + d[0];
        int f = file(from) + d[1];
        while (on(r, f)) {
            int piece = p.b[r * 8 + f] * sign;
            if (piece > 0) {
                return;
            }
            out.add(move(from, r * 8 + f, 0, 0));
            if (piece < 0) {
                return;
            }
            r += d[0];
            f += d[1];
        }
    }

    private static void castling(Pos p, List<Integer> out, boolean w) {
        int base = w ? 0 : 56;
        int king = w ? K : -K;
        int rook = w ? R : -R;
        if (p.b[base + 4] != king || attacked(p, base + 4, !w)) {
            return;
        }
        if ((p.castle & (w ? 1 : 4)) != 0 && p.b[base + 7] == rook && p.b[base + 5] == 0 && p.b[base + 6] == 0
                && !attacked(p, base + 5, !w) && !attacked(p, base + 6, !w)) {
            out.add(move(base + 4, base + 6, 0, CASTLE));
        }
        if ((p.castle & (w ? 2 : 8)) != 0 && p.b[base] == rook && p.b[base + 1] == 0 && p.b[base + 2] == 0 && p.b[base + 3] == 0
                && !attacked(p, base + 3, !w) && !attacked(p, base + 2, !w)) {
            out.add(move(base + 4, base + 2, 0, CASTLE));
        }
    }

    public static Pos apply(Pos p, int m) {
        Pos n = p.copy();
        int from = from(m);
        int to = to(m);
        int piece = n.b[from];
        int sign = p.white ? 1 : -1;
        boolean capture = n.b[to] != 0;
        if ((m & EN_PASSANT) != 0) {
            n.b[to - 8 * sign] = 0;
            capture = true;
        }
        if ((m & CASTLE) != 0) {
            if (to > from) {
                n.b[to - 1] = n.b[to + 1];
                n.b[to + 1] = 0;
            } else {
                n.b[to + 1] = n.b[to - 2];
                n.b[to - 2] = 0;
            }
        }
        n.b[from] = 0;
        n.b[to] = (byte) (promo(m) != 0 ? promo(m) * sign : piece);
        n.ep = Math.abs(piece) == P && Math.abs(to - from) == 16 ? (from + to) / 2 : -1;
        if (from == 4 || to == 4) {
            n.castle &= ~3;
        }
        if (from == 60 || to == 60) {
            n.castle &= ~12;
        }
        if (from == 0 || to == 0) {
            n.castle &= ~2;
        }
        if (from == 7 || to == 7) {
            n.castle &= ~1;
        }
        if (from == 56 || to == 56) {
            n.castle &= ~8;
        }
        if (from == 63 || to == 63) {
            n.castle &= ~4;
        }
        n.half = Math.abs(piece) == P || capture ? 0 : p.half + 1;
        n.white = !p.white;
        return n;
    }

    public static List<Integer> legal(Pos p) {
        List<Integer> out = new ArrayList<>(40);
        for (int m : pseudo(p)) {
            Pos n = apply(p, m);
            if (!inCheck(n, p.white)) {
                out.add(m);
            }
        }
        return out;
    }

    /** 0 = playing, 1 = checkmate (side to move lost), 2 = stalemate, 3 = draw (50 moves / not enough material). */
    public static int status(Pos p) {
        if (legal(p).isEmpty()) {
            return inCheck(p, p.white) ? 1 : 2;
        }
        if (p.half >= 100 || insufficient(p)) {
            return 3;
        }
        return 0;
    }

    private static boolean insufficient(Pos p) {
        int minors = 0;
        for (byte piece : p.b) {
            int a = Math.abs(piece);
            if (a == P || a == R || a == Q) {
                return false;
            }
            if (a == N || a == B) {
                minors++;
            }
        }
        return minors <= 1;
    }

    // ---- the bot ----

    private static int eval(Pos p) {
        int score = 0;
        for (int sq = 0; sq < 64; sq++) {
            int piece = p.b[sq];
            if (piece == 0) {
                continue;
            }
            int a = Math.abs(piece);
            boolean w = piece > 0;
            int r = w ? rank(sq) : 7 - rank(sq);
            int f = file(sq);
            int centre = 6 - Math.abs(2 * f - 7) / 2 - Math.abs(2 * rank(sq) - 7) / 2; // 0..6
            int v = VALUE[a];
            if (a == P) {
                v += r * 6 + (f >= 2 && f <= 5 ? centre : 0);
            } else if (a == N || a == B) {
                v += centre * 4;
            } else if (a == K) {
                v += r == 0 ? 8 : -r * 6;
            }
            score += w ? v : -v;
        }
        return p.white ? score : -score;
    }

    private static int order(Pos p, int m) {
        int victim = Math.abs(p.b[to(m)]);
        int attacker = Math.abs(p.b[from(m)]);
        int s = victim != 0 ? 10 * VALUE[victim] - VALUE[attacker] : 0;
        if (promo(m) != 0) {
            s += 800;
        }
        return s;
    }

    private static List<Integer> ordered(Pos p, List<Integer> moves) {
        moves.sort((x, y) -> Integer.compare(order(p, y), order(p, x)));
        return moves;
    }

    private static int quiesce(Pos p, int alpha, int beta, int depth) {
        int stand = eval(p);
        if (stand >= beta) {
            return beta;
        }
        alpha = Math.max(alpha, stand);
        if (depth == 0) {
            return alpha;
        }
        for (int m : ordered(p, legal(p))) {
            if (p.b[to(m)] == 0 && (m & EN_PASSANT) == 0) {
                continue;
            }
            int score = -quiesce(apply(p, m), -beta, -alpha, depth - 1);
            if (score >= beta) {
                return beta;
            }
            alpha = Math.max(alpha, score);
        }
        return alpha;
    }

    private static int search(Pos p, int depth, int alpha, int beta, int ply) {
        List<Integer> moves = legal(p);
        if (moves.isEmpty()) {
            return inCheck(p, p.white) ? -MATE + ply : 0;
        }
        if (depth == 0) {
            return quiesce(p, alpha, beta, 4);
        }
        for (int m : ordered(p, moves)) {
            int score = -search(apply(p, m), depth - 1, -beta, -alpha, ply + 1);
            if (score >= beta) {
                return beta;
            }
            alpha = Math.max(alpha, score);
        }
        return alpha;
    }

    /** Picks a move for the side to move. depth 1 is very weak, 3 is a decent club player's nightmare. */
    public static int bestMove(Pos p, int depth) {
        List<Integer> moves = legal(p);
        if (moves.isEmpty()) {
            return -1;
        }
        int opening = openingMove(p, moves);
        if (opening >= 0) {
            return opening;
        }
        int[] scores = new int[moves.size()];
        int best = Integer.MIN_VALUE;
        for (int i = 0; i < moves.size(); i++) {
            scores[i] = -search(apply(p, moves.get(i)), Math.max(0, depth - 1), -MATE * 2, MATE * 2, 1);
            best = Math.max(best, scores[i]);
        }
        List<Integer> top = new ArrayList<>();
        for (int i = 0; i < moves.size(); i++) {
            if (scores[i] >= best - 12) {
                top.add(moves.get(i));
            }
        }
        return top.get(RANDOM.nextInt(top.size()));
    }

    /** The bot opens with e4 as white and answers with e5 as black (its very first move of the game). */
    private static int openingMove(Pos p, List<Integer> moves) {
        Pos start = start();
        int fromSq, toSq;
        boolean fresh = true;
        if (p.white) {
            for (int i = 0; i < 16; i++) {
                fresh &= p.b[i] == start.b[i];
            }
            fromSq = 12; // e2
            toSq = 28; // e4
        } else {
            for (int i = 48; i < 64; i++) {
                fresh &= p.b[i] == start.b[i];
            }
            fromSq = 52; // e7
            toSq = 36; // e5
        }
        if (!fresh) {
            return -1;
        }
        for (int m : moves) {
            if (from(m) == fromSq && to(m) == toSq) {
                return m;
            }
        }
        return -1;
    }

    public static String name(int square) {
        return "" + (char) ('a' + file(square)) + (char) ('1' + rank(square));
    }
}
