/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.render;

import net.minecraft.client.Minecraft;

/**
 * Kept only so older call sites still link. The Scoreboard Spoofer now rewrites the sidebar at draw time
 * (see gg.bagel.client.extra.ScoreboardFields) and never edits the real scoreboard.
 */
public final class BagelSpoof {
    private BagelSpoof() {}

    public static void sync(Minecraft mc) {}

    public static void restore() {}
}
