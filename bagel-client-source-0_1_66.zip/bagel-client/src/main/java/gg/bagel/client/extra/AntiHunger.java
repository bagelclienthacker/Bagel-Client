/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;

/**
 * Anti Hunger: the server mostly burns food from sprinting and from jumping/landing, so we hide both:
 * sprint start packets are dropped and movement packets claim you are not on the ground while you are not falling.
 */
public final class AntiHunger extends Module {
    public static final String NAME = "Anti Hunger";

    public AntiHunger() {
        super(NAME, "Slows hunger loss by hiding sprinting and ground contact from the server", Category.PLAYER);
        setting("sprint", Boolean.TRUE);
        setting("ground", Boolean.TRUE);
    }

    private static AntiHunger active() {
        if (VanillaMode.active()) {
            return null;
        }
        Module m = BagelClient.MODULES.byName(NAME);
        return m instanceof AntiHunger a && a.enabled() ? a : null;
    }

    /** True when this outgoing packet must not be sent. */
    public static boolean drop(Packet<?> packet) {
        AntiHunger a = active();
        if (a == null || !a.booleanSetting("sprint", true)) {
            return false;
        }
        return packet instanceof ServerboundPlayerCommandPacket command
                && command.getAction() == ServerboundPlayerCommandPacket.Action.START_SPRINTING;
    }

    /** Returns a replacement movement packet claiming "in the air", or null to send the packet unchanged. */
    public static Packet<?> rewrite(Packet<?> packet) {
        AntiHunger a = active();
        if (a == null || !a.booleanSetting("ground", true) || !(packet instanceof ServerboundMovePlayerPacket move) || !move.isOnGround()) {
            return null;
        }
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || player.fallDistance > 0.0D || player.isFallFlying() || player.getAbilities().flying) {
            return null;
        }
        boolean hc = move.horizontalCollision();
        if (move.hasPosition() && move.hasRotation()) {
            return new ServerboundMovePlayerPacket.PosRot(move.getX(0.0D), move.getY(0.0D), move.getZ(0.0D), move.getYRot(0.0F), move.getXRot(0.0F), false, hc);
        }
        if (move.hasPosition()) {
            return new ServerboundMovePlayerPacket.Pos(move.getX(0.0D), move.getY(0.0D), move.getZ(0.0D), false, hc);
        }
        if (move.hasRotation()) {
            return new ServerboundMovePlayerPacket.Rot(move.getYRot(0.0F), move.getXRot(0.0F), false, hc);
        }
        return new ServerboundMovePlayerPacket.StatusOnly(false, hc);
    }
}
