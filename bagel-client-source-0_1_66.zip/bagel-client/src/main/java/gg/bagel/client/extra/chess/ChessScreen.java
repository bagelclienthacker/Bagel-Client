/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.chess;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Offline chess against a basic bot. Click a piece, then click where it should go. */
public final class ChessScreen extends Screen {
    private static final ExecutorService BRAIN = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bagel-chess");
        t.setDaemon(true);
        return t;
    });
    private static final String[] LEVELS = {"Easy", "Normal", "Hard"};
    private static final int LIGHT = 0xFFE8D6B0;
    private static final int DARK = 0xFFA9774C;
    private static final int SELECT = 0xFF6FB36F;
    private static final int LAST = 0xFFD9D26A;
    private static final int CHECK = 0xFFD95C5C;

    // Game state survives closing and re-opening the screen.
    private static ChessEngine.Pos pos = ChessEngine.start();
    private static boolean playerWhite = true;
    private static int level = 1;
    private static int lastMove = -1;
    private static int gameId;
    private static volatile int pending = Integer.MIN_VALUE;
    private static volatile boolean thinking;

    private final Screen parent;
    private int selected = -1;
    private List<Integer> legalCache = new ArrayList<>();
    private int cell;
    private int boardX;
    private int boardY;

    public ChessScreen(Screen parent) {
        super(Component.literal("Chess"));
        this.parent = parent;
    }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            Screen current = mc.gui.screen();
            mc.setScreenAndShow(new ChessScreen(current instanceof ChatScreen ? null : current));
        });
    }

    private static void newGame() {
        pos = ChessEngine.start();
        lastMove = -1;
        gameId++;
        pending = Integer.MIN_VALUE;
        thinking = false;
    }

    private boolean playerTurn() {
        return pos.white == playerWhite;
    }

    @Override
    protected void init() {
        cell = Math.max(16, Math.min(40, Math.min((this.height - 50) / 8, (this.width - 190) / 8)));
        boardX = (this.width - cell * 8 - 150) / 2 + 10;
        boardY = (this.height - cell * 8) / 2;
        int bx = boardX + cell * 8 + 14;
        int by = boardY;
        this.addRenderableWidget(Button.builder(Component.literal("New game"), b -> {
            newGame();
            selected = -1;
            legalCache.clear();
        }).bounds(bx, by, 126, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Playing: " + (playerWhite ? "White" : "Black")), b -> {
            playerWhite = !playerWhite;
            newGame();
            selected = -1;
            legalCache.clear();
            this.rebuildWidgets();
        }).bounds(bx, by + 24, 126, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Bot: " + LEVELS[level]), b -> {
            level = (level + 1) % LEVELS.length;
            this.rebuildWidgets();
        }).bounds(bx, by + 48, 126, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose())
                .bounds(bx, by + cell * 8 - 20, 126, 20).build());
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        int status = ChessEngine.status(pos);
        if (status != 0 || playerTurn()) {
            return;
        }
        int done = pending;
        if (done != Integer.MIN_VALUE) {
            pending = Integer.MIN_VALUE;
            thinking = false;
            if (done >= 0) {
                pos = ChessEngine.apply(pos, done);
                lastMove = done;
            }
            return;
        }
        if (!thinking) {
            thinking = true;
            final ChessEngine.Pos snapshot = pos;
            final int game = gameId;
            final int depth = level + 1;
            BRAIN.execute(() -> {
                int move = ChessEngine.bestMove(snapshot, depth);
                if (game == gameId) {
                    pending = move;
                } else {
                    thinking = false;
                }
            });
        }
    }

    private int squareAt(double mx, double my) {
        int col = (int) Math.floor((mx - boardX) / cell);
        int row = (int) Math.floor((my - boardY) / cell);
        if (col < 0 || col > 7 || row < 0 || row > 7) {
            return -1;
        }
        return playerWhite ? (7 - row) * 8 + col : row * 8 + (7 - col);
    }

    private int screenX(int sq) {
        int file = sq & 7;
        return boardX + (playerWhite ? file : 7 - file) * cell;
    }

    private int screenY(int sq) {
        int rank = sq >> 3;
        return boardY + (playerWhite ? 7 - rank : rank) * cell;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        if (event.button() != 0 || !playerTurn() || ChessEngine.status(pos) != 0) {
            return false;
        }
        int sq = squareAt(event.x(), event.y());
        if (sq < 0) {
            return false;
        }
        if (selected >= 0) {
            int chosen = -1;
            for (int m : legalCache) {
                if (ChessEngine.to(m) == sq && (ChessEngine.promo(m) == 0 || ChessEngine.promo(m) == ChessEngine.Q)) {
                    chosen = m;
                    break;
                }
            }
            if (chosen >= 0) {
                pos = ChessEngine.apply(pos, chosen);
                lastMove = chosen;
                selected = -1;
                legalCache.clear();
                return true;
            }
        }
        int piece = pos.b[sq];
        if (piece != 0 && (piece > 0) == playerWhite) {
            selected = sq;
            legalCache = new ArrayList<>();
            for (int m : ChessEngine.legal(pos)) {
                if (ChessEngine.from(m) == sq) {
                    legalCache.add(m);
                }
            }
        } else {
            selected = -1;
            legalCache.clear();
        }
        return true;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        g.text(this.font, "Chess", boardX, boardY - 14, -1);
        int kingSq = -1;
        if (ChessEngine.inCheck(pos, pos.white)) {
            for (int i = 0; i < 64; i++) {
                if (pos.b[i] == (pos.white ? ChessEngine.K : -ChessEngine.K)) {
                    kingSq = i;
                }
            }
        }
        for (int sq = 0; sq < 64; sq++) {
            int x = screenX(sq);
            int y = screenY(sq);
            boolean lightSquare = (((sq >> 3) + (sq & 7)) & 1) == 1;
            int color = lightSquare ? LIGHT : DARK;
            if (lastMove >= 0 && (sq == ChessEngine.from(lastMove) || sq == ChessEngine.to(lastMove))) {
                color = LAST;
            }
            if (sq == kingSq) {
                color = CHECK;
            }
            if (sq == selected) {
                color = SELECT;
            }
            g.fill(x, y, x + cell, y + cell, color);
        }
        for (int m : legalCache) {
            int to = ChessEngine.to(m);
            int x = screenX(to);
            int y = screenY(to);
            int pad = pos.b[to] != 0 ? 2 : cell / 2 - 3;
            g.fill(x + pad, y + pad, x + cell - pad, y + cell - pad, 0xAA3C8C3C);
        }
        for (int sq = 0; sq < 64; sq++) {
            int piece = pos.b[sq];
            if (piece != 0) {
                ChessSprites.draw(g, Math.abs(piece), piece > 0, screenX(sq), screenY(sq), cell);
            }
        }
        for (int i = 0; i < 8; i++) {
            String file = String.valueOf((char) ('a' + (playerWhite ? i : 7 - i)));
            g.text(this.font, file, boardX + i * cell + cell / 2 - 2, boardY + cell * 8 + 3, 0xFFAAAAAA);
            String rank = String.valueOf(playerWhite ? 8 - i : i + 1);
            g.text(this.font, rank, boardX - 9, boardY + i * cell + cell / 2 - 4, 0xFFAAAAAA);
        }
        int bx = boardX + cell * 8 + 14;
        int status = ChessEngine.status(pos);
        String line;
        int lineColor = -1;
        if (status == 1) {
            boolean youLost = pos.white == playerWhite;
            line = youLost ? "Checkmate - the bot wins" : "Checkmate - you win!";
            lineColor = youLost ? 0xFFFF7777 : 0xFF77FF77;
        } else if (status == 2) {
            line = "Stalemate - draw";
        } else if (status == 3) {
            line = "Draw";
        } else if (playerTurn()) {
            line = ChessEngine.inCheck(pos, pos.white) ? "Your move (check!)" : "Your move";
        } else {
            line = "Bot is thinking...";
        }
        g.text(this.font, line, bx, boardY + 76, lineColor);
        if (lastMove >= 0) {
            String last = "Last: " + ChessEngine.name(ChessEngine.from(lastMove)) + " to " + ChessEngine.name(ChessEngine.to(lastMove));
            g.text(this.font, last, bx, boardY + 90, 0xFFAAAAAA);
        }
        g.text(this.font, "Works offline", bx, boardY + 104, 0xFF888888);
    }
}
