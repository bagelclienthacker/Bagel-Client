/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;

/**
 * Auto Totem with three modes:
 * smart - AUTISM Client's smart swap: a totem in the hotbar is swapped with packets only (select slot, swap with
 *         offhand, select the old slot again), a totem deeper in the inventory uses pickup clicks. It never sends
 *         a second swap until the offhand item really changed (up to 500 ms), then backs off, so it cannot spam,
 * switch - keeps a totem in the offhand using the hotbar swap (no inventory clicks),
 * pickup - keeps a totem in the offhand using inventory pickup clicks.
 * With "hold_until_low_health" the totem is only swapped in when health is low (or a fall / crystal is about
 * to kill you) and the item that was in the offhand is put back once it is safe ("switch_back").
 */
public final class TotemMode {
    private static final int OFFHAND_MENU_SLOT = 45;
    private static int wait;
    /** When the last swap was sent, and what the offhand held then. A swap is confirmed once the offhand item changes. */
    private static long sentAt = -1L;
    private static Item sentOffhand;
    private static int failures;
    private static long blockedUntil;
    /** After a swap that never showed up: try the other method (packet <-> pickup) next time. */
    private static boolean forcePickup;
    /** The item the totem pushed out of the offhand and the inventory slot it went to, for switch back. */
    private static Item displacedItem;
    private static int displacedSlot = -1;
    private static long safeSince = -1L;

    private TotemMode() {}

    /** How long to wait for the server to confirm a swap: ping based, never long enough to leave you without a totem. */
    private static long confirmMs() {
        Minecraft mc = Minecraft.getInstance();
        long latency = 0L;
        try {
            if (mc.getConnection() != null && mc.player != null) {
                net.minecraft.client.multiplayer.PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) {
                    latency = info.getLatency();
                }
            }
        } catch (RuntimeException ignored) {
            // fall back to the base value
        }
        return Math.max(250L, Math.min(700L, 200L + latency * 2L));
    }

    /** True while a sent swap has not shown up in the offhand yet. Times out and then briefly backs off. */
    private static boolean swapPending(LocalPlayer player) {
        if (sentAt < 0L) {
            return false;
        }
        long now = System.currentTimeMillis();
        if (player.getOffhandItem().getItem() != sentOffhand) {
            sentAt = -1L;
            failures = 0;
            forcePickup = false;
            return false;
        }
        if (now - sentAt < confirmMs()) {
            return true;
        }
        sentAt = -1L;
        failures = Math.min(failures + 1, 6);
        blockedUntil = now + Math.min(120L * failures, 360L);
        forcePickup = !forcePickup; // the swap did not go through: try the other method
        return false;
    }

    private static void markSent(LocalPlayer player) {
        sentOffhand = player.getOffhandItem().getItem();
        sentAt = System.currentTimeMillis();
    }

    public static void tick(Module module, Minecraft mc, LocalPlayer player) {
        if (mc.gameMode == null || mc.level == null || player == null || !player.isAlive()) {
            return;
        }
        if (wait > 0) {
            wait--;
        }
        String mode = module.stringSetting("mode", "smart").trim().toLowerCase(Locale.ROOT);
        boolean holdUntilLow = module.booleanSetting("hold_until_low_health", false);
        double threshold = Math.max(1.0D, Math.min(20.0D, module.doubleSetting("health_threshold", 8.0D)));
        double health = player.getHealth() + player.getAbsorptionAmount();
        boolean need = !holdUntilLow || health <= threshold || fallDanger(mc, player, health) || crystalDanger(mc, player, health, threshold);
        boolean menuOk = player.containerMenu == player.inventoryMenu && player.containerMenu.getCarried().isEmpty();
        // low health (or a fall / crystal about to land): no delay, no backoff
        boolean urgent = health <= Math.max(10.0D, threshold) || fallDanger(mc, player, health);

        if (player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            sentAt = -1L;
            failures = 0;
            forcePickup = false;
            blockedUntil = 0L;
            switchBack(module, mc, player, mode, need, health, threshold, holdUntilLow, menuOk);
            return;
        }
        safeSince = -1L;
        if (!need || swapPending(player)) {
            return;
        }
        if (!urgent && (wait > 0 || System.currentTimeMillis() < blockedUntil)) {
            return;
        }
        int slot = findTotem(player);
        if (slot < 0) {
            return;
        }
        boolean packet = usesPacket(mode, slot) || (!menuOk && canPacket(mode, slot));
        if (!packet && !menuOk) {
            return; // inventory clicks need the plain inventory menu and an empty cursor
        }
        ItemStack before = player.getOffhandItem();
        Item beforeItem = before.isEmpty() ? null : before.getItem();
        swap(mc, player, packet, slot);
        if (holdUntilLow && module.booleanSetting("switch_back", true) && beforeItem != null) {
            displacedItem = beforeItem;
            displacedSlot = slot;
        } else {
            displacedItem = null;
            displacedSlot = -1;
        }
        markSent(player);
        wait = Math.max(0, Math.min(20, module.intSetting("delay_ticks", 2)));
    }

    /** Totem is in the offhand and it is safe again: put the old offhand item back (hold_until_low_health only). */
    private static void switchBack(Module module, Minecraft mc, LocalPlayer player, String mode, boolean need, double health,
            double threshold, boolean holdUntilLow, boolean menuOk) {
        if (displacedSlot < 0 || displacedItem == null) {
            return;
        }
        if (!holdUntilLow || !module.booleanSetting("switch_back", true)) {
            displacedItem = null;
            displacedSlot = -1;
            return;
        }
        if (need || health <= threshold + 2.0D) {
            safeSince = -1L;
            return;
        }
        long now = System.currentTimeMillis();
        if (safeSince < 0L) {
            safeSince = now;
        }
        boolean packet = usesPacket(mode, displacedSlot) || (!menuOk && canPacket(mode, displacedSlot));
        if (now - safeSince < Math.max(0, module.intSetting("switch_back_delay", 400)) || wait > 0 || (!packet && !menuOk)
                || swapPending(player) || now < blockedUntil) {
            return;
        }
        if (!player.getInventory().getItem(displacedSlot).is(displacedItem)) {
            displacedItem = null;
            displacedSlot = -1;
            return;
        }
        swap(mc, player, packet, displacedSlot);
        markSent(player);
        displacedItem = null;
        displacedSlot = -1;
        safeSince = -1L;
        wait = Math.max(0, Math.min(20, module.intSetting("delay_ticks", 2)));
    }

    /** Hotbar totem in smart / switch mode: swap with packets, unless that just failed and the other method is due. */
    private static boolean usesPacket(String mode, int slot) {
        return canPacket(mode, slot) && !forcePickup;
    }

    private static boolean canPacket(String mode, int slot) {
        return (mode.equals("smart") || mode.equals("switch")) && slot < 9;
    }

    private static void swap(Minecraft mc, LocalPlayer player, boolean packet, int slot) {
        if (packet) {
            packetSwap(mc, player, slot);
        } else {
            pickupSwap(mc, player, slot);
        }
    }

    private static int findTotem(LocalPlayer player) {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(Items.TOTEM_OF_UNDYING)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Hotbar slot: tell the server to select it, swap with the offhand, and select the old slot again. Packets only,
     * the client's own selected slot never changes, so nothing flickers.
     */
    private static void packetSwap(Minecraft mc, LocalPlayer player, int hotbarSlot) {
        if (mc.getConnection() == null) {
            return;
        }
        int original = player.getInventory().getSelectedSlot();
        if (hotbarSlot != original) {
            mc.getConnection().send(new ServerboundSetCarriedItemPacket(hotbarSlot));
        }
        mc.getConnection().send(new ServerboundPlayerActionPacket(
                ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
        if (hotbarSlot != original) {
            mc.getConnection().send(new ServerboundSetCarriedItemPacket(original));
        }
    }

    /** Any slot: pick the totem up, drop it on the offhand slot, put the old offhand item back. */
    private static void pickupSwap(Minecraft mc, LocalPlayer player, int inventorySlot) {
        int menuSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
        int id = player.inventoryMenu.containerId;
        mc.gameMode.handleContainerInput(id, menuSlot, 0, ContainerInput.PICKUP, player);
        mc.gameMode.handleContainerInput(id, OFFHAND_MENU_SLOT, 0, ContainerInput.PICKUP, player);
        if (!player.inventoryMenu.getCarried().isEmpty()) {
            mc.gameMode.handleContainerInput(id, menuSlot, 0, ContainerInput.PICKUP, player);
        }
    }

    private static boolean fallDanger(Minecraft mc, LocalPlayer player, double health) {
        if (player.onGround() || player.isFallFlying() || player.getDeltaMovement().y > -0.5D) {
            return false;
        }
        double ground = 0.0D;
        BlockPos.MutableBlockPos pos = player.blockPosition().mutable();
        for (int i = 0; i < 64; i++) {
            pos.move(Direction.DOWN);
            if (pos.getY() < mc.level.getMinY()) {
                return true;
            }
            if (!mc.level.getBlockState(pos).getCollisionShape(mc.level, pos).isEmpty()) {
                ground = player.getY() - (pos.getY() + 1.0D);
                break;
            }
            ground = i + 1;
        }
        double total = player.fallDistance + Math.max(0.0D, ground);
        return total - 3.0D >= health - 1.0D;
    }

    private static boolean crystalDanger(Minecraft mc, LocalPlayer player, double health, double threshold) {
        if (health > threshold + 8.0D) {
            return false;
        }
        AABB area = player.getBoundingBox().inflate(8.0D);
        for (Entity entity : mc.level.getEntities(player, area, e -> e instanceof EndCrystal)) {
            return true;
        }
        return false;
    }
}
