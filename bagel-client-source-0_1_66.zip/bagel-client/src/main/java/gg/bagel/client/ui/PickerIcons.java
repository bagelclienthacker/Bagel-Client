/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.ui;

import java.util.Optional;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Icons for the entity list in the module pickers: spawn eggs, or a matching item. */
public final class PickerIcons {
    private PickerIcons() {}

    public static ItemStack forEntity(EntityType<?> type) {
        try {
            Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(type);
            String path = id.getPath();
            Optional<Item> egg = BuiltInRegistries.ITEM.getOptional(
                    Identifier.fromNamespaceAndPath(id.getNamespace(), path + "_spawn_egg"));
            if (egg.isPresent()) {
                return new ItemStack(egg.get());
            }
            Item special = special(path);
            if (special != null) {
                return new ItemStack(special);
            }
            Optional<Item> same = BuiltInRegistries.ITEM.getOptional(id);
            if (same.isPresent() && same.get() != Items.AIR) {
                return new ItemStack(same.get());
            }
        } catch (RuntimeException ignored) {
        }
        return null;
    }

    private static Item special(String path) {
        return switch (path) {
            case "item" -> Items.DIAMOND;
            case "player" -> Items.PLAYER_HEAD;
            case "experience_orb" -> Items.EXPERIENCE_BOTTLE;
            case "falling_block" -> Items.SAND;
            case "end_crystal" -> Items.END_CRYSTAL;
            default -> null;
        };
    }

    public static String storageLabel(String label) {
        return "Shulker Box".equals(label) ? "Shulker Box (all colors)" : label;
    }
}
