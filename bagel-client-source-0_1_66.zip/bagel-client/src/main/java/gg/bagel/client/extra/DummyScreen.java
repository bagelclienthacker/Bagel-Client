/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.blaze3d.platform.InputConstants;
import gg.bagel.client.extra.dummy.Sim;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Hit the Dummy: a ragdoll sandbox in a black box. The dummy wears any player's skin; grab it, hit it, shoot it, thrust
 * a spear into it, or cut it apart (it is a stuffed dummy, so cut parts just pop off with a puff of straw). Damage
 * numbers are close to vanilla but approximate; nothing here touches the server.
 */
public final class DummyScreen extends Screen {
    private enum Kind { GRAB, MELEE, BOW, CROSSBOW, PLACE, IGNITE, HEAL, TOTEM, CANNON }

    private record Weapon(String name, Item item, double damage, int cooldownMs, Kind kind, boolean blade, boolean axe,
            boolean mace, boolean spear, boolean bare) {}

    private static final class Obj {
        final boolean tnt;
        final float scale;
        double x, y, vy;
        boolean lit;
        long fuseAt;
        long popAt;

        Obj(boolean tnt, double x, double y, float scale) {
            this.tnt = tnt;
            this.x = x;
            this.y = y;
            this.scale = scale;
        }
    }

    private static final double MAX_HP = 20;
    private static final int[] FIGHT_WEAPONS = {1, 2, 3, 4, 5, 6, 7, 8};
    private static final String[] FIGHT_NAMES = {"Fist", "Sword", "Axe", "Mace", "Spear", "Trident", "Bow", "Crossbow"};
    private static final String[] ARMOR_NAMES = {"No armor", "Leather", "Chain", "Iron", "Diamond"};
    private static final int[] ARMOR_POINTS = {0, 7, 12, 15, 20};
    private static final double[] ARMOR_TOUGH = {0, 0, 0, 0, 8};
    private static final int[] ARMOR_COLOR = {0, 0xA0683A, 0x9AA0A6, 0xE0E0E0, 0x3FE0D2};

    /** One ragdoll in the box: the sandbox dummy, or a fighter with a weapon, armor and hit points. */
    private static final class Dummy {
        Sim sim;
        Identifier tex;
        boolean slim;
        String name = "Dummy";
        double fx = 0.5;
        boolean fighter;
        int weapon = 2;
        int armor;
        double hp = MAX_HP;
        boolean dead;
        long nextAttack;
        long swingStart = -10_000;
        boolean hitPending;
        long downSince;
        Dummy target;
        int side = 1;
    }

    private record Floating(long born, double x, double y, int dx, String text, int color) {}

    private static final Weapon[] WEAPONS = {
        new Weapon("Grab", Items.LEAD, 0, 0, Kind.GRAB, false, false, false, false, true),
        new Weapon("Fist", Items.STICK, 1.0, 250, Kind.MELEE, false, false, false, false, true),
        new Weapon("Diamond Sword", Items.DIAMOND_SWORD, 7.0, 625, Kind.MELEE, true, false, false, false, false),
        new Weapon("Diamond Axe", Items.DIAMOND_AXE, 9.0, 1000, Kind.MELEE, true, true, false, false, false),
        new Weapon("Mace", Items.MACE, 6.0, 1667, Kind.MELEE, false, false, true, false, false),
        new Weapon("Diamond Spear", Items.DIAMOND_SPEAR, 4.0, 1100, Kind.MELEE, false, false, false, true, false),
        new Weapon("Trident", Items.TRIDENT, 9.0, 910, Kind.MELEE, false, false, false, false, false),
        new Weapon("Bow", Items.BOW, 6.0, 1000, Kind.BOW, false, false, false, false, false),
        new Weapon("Crossbow", Items.CROSSBOW, 7.0, 1250, Kind.CROSSBOW, false, false, false, false, false),
        new Weapon("End Crystal", Items.END_CRYSTAL, 0, 0, Kind.PLACE, false, false, false, false, true),
        new Weapon("TNT", Items.TNT, 0, 0, Kind.PLACE, false, false, false, false, true),
        new Weapon("Flint and Steel", Items.FLINT_AND_STEEL, 0, 0, Kind.IGNITE, false, false, false, false, true),
        // misc tab
        new Weapon("Splash Healing", Items.SPLASH_POTION, 0, 0, Kind.HEAL, false, false, false, false, true),
        new Weapon("Totem of Undying", Items.TOTEM_OF_UNDYING, 0, 0, Kind.TOTEM, false, false, false, false, true),
        new Weapon("stab", Items.FISHING_ROD, 0, 700, Kind.CANNON, false, false, false, false, true),
        new Weapon("nuke", Items.FISHING_ROD, 0, 3500, Kind.CANNON, false, false, false, false, true),
    };
    private static final int MISC_START = 12;
    private static final double CRIT_SPIN = 9.0;
    private static final int[] DRAW_ORDER = {Sim.LEG_R_LO, Sim.LEG_L_LO, Sim.LEG_R_UP, Sim.LEG_L_UP, Sim.HIPS, Sim.CHEST,
        Sim.ARM_R_LO, Sim.ARM_L_LO, Sim.ARM_R_UP, Sim.ARM_L_UP, Sim.HEAD};
    private static final Random RANDOM = new Random();

    private final Screen parent;
    private EditBox nameField;
    private String keepName = "";

    private int selected = 2;
    private boolean blood = true;
    private boolean sharp;
    private int tab;
    private final List<double[]> beams = new ArrayList<>();
    private long totemSound;
    private final List<double[]> sparks = new ArrayList<>(); // x, y, vx, vy, life, maxLife, size, color
    private final List<double[]> rings = new ArrayList<>(); // x, y, bornMs, power
    private final List<double[]> columns = new ArrayList<>(); // x, y, fireAtMs, power: a pillar of explosions going up
    private boolean stand = true;
    private boolean cuts = true;

    private Sim sim; // the dummy nearest the cursor (the one the current action applies to)
    private Dummy cur;
    private Dummy mainD;
    private Dummy grabD;
    private Dummy aimOwner;
    private final List<Dummy> dummies = new ArrayList<>();
    private boolean fightOn;
    private boolean won;
    private int tplSkin;
    private int tplWeapon = 1;
    private int tplArmor = 3;
    private int simK;
    private long lastFrame;

    private boolean leftDown;
    private boolean rightDown;
    private int grabButton = -1;
    private double mx;
    private double my;
    private double vx;
    private double vy;
    private double aimAngle;
    private double prevAim;
    private double spin;
    // the held weapon hangs from the cursor like a pendulum: theta 0 = straight down, gravity pulls it back
    private double theta;
    private double omega;
    private double pvx;
    private double pvy;
    private static final float SCALE = 2.4F;
    private static final double TIP = 22 * SCALE;
    private static final double PEND_G = 1800;
    private static final double PEND_L = 15 * SCALE * 0.8;
    private long motionReadyAt;
    private final List<Obj> objs = new ArrayList<>();

    private long lastSwing = System.currentTimeMillis() - 10_000;
    private long swingStart;
    private long bowDrawStart = -1;
    private boolean loaded;
    private long loadStart = System.currentTimeMillis();
    private long spearReadyAt;

    private double total;
    private double last;
    private double best;
    private int hits;
    private int cutCount;
    private String lastNote = "";
    private final List<double[]> recent = new ArrayList<>();
    private final List<Floating> floats = new ArrayList<>();

    private int boxX;
    private int boxY;
    private int boxW;
    private int boxH;
    private int colX;
    private int arenaX;
    private int arenaY;
    private int arenaW;
    private int arenaH;

    public DummyScreen(Screen parent) {
        super(Component.literal("Hit the Dummy"));
        this.parent = parent;
    }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            Screen current = mc.gui.screen();
            mc.setScreenAndShow(new DummyScreen(current instanceof ChatScreen ? null : current));
        });
    }

    private static long now() {
        return System.currentTimeMillis();
    }

    private Weapon weapon() {
        return WEAPONS[selected];
    }

    private static ItemStack stackFor(Weapon w) {
        ItemStack stack = new ItemStack(w.item());
        if (w.kind() == Kind.HEAL) {
            stack.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.HEALING));
        }
        if (w.kind() == Kind.HEAL || w.kind() == Kind.TOTEM) {
            stack.set(DataComponents.CUSTOM_NAME, Component.literal(w.name()));
        }
        if (w.kind() == Kind.CANNON) {
            stack.set(DataComponents.CUSTOM_NAME, Component.literal(w.name()).withStyle(style -> style.withItalic(true)));
        }
        return stack;
    }

    // ---- layout and widgets ----

    @Override
    protected void init() {
        DummySkin.ensure();
        boxW = Math.min(this.width - 8, 460);
        boxH = Math.min(this.height - 8, 216);
        boxX = (this.width - boxW) / 2;
        boxY = Math.max(2, (this.height - boxH) / 2);
        colX = boxX + 8;
        arenaX = boxX + 136;
        arenaY = boxY + 20;
        arenaW = boxW - 144;
        arenaH = boxH - 28;
        int k = Math.max(2, Math.min(5, (arenaH - 22 - 40) / 32));
        if (mainD == null || simK != k) {
            simK = k;
            respawnAll();
        } else {
            for (Dummy d : dummies) {
                d.sim.left = arenaX + 2;
                d.sim.right = arenaX + arenaW - 2;
                d.sim.top = arenaY + 2;
                d.sim.floorY = arenaY + arenaH - 22;
            }
        }

        this.addRenderableWidget(toggle("Blood", blood, colX, boxY + 90, b -> blood = !blood));
        this.addRenderableWidget(toggle("Sharp V", sharp, colX + 62, boxY + 90, b -> sharp = !sharp));
        this.addRenderableWidget(Button.builder(Component.literal("Clear"), b -> {
            objs.clear();
            beams.clear();
            dummies.removeIf(d -> d != mainD);
            mainD.sim.stains.clear();
            grabD = null;
            won = false;
            focus(mainD);
        }).bounds(colX, boxY + 108, 58, 16).build());
        this.addRenderableWidget(Button.builder(Component.literal("Respawn"), b -> {
            resetStats();
            objs.clear();
            beams.clear();
            sparks.clear();
            rings.clear();
            columns.clear();
            respawnAll();
        }).bounds(colX + 62, boxY + 108, 58, 16).build());
        this.addRenderableWidget(Button.builder(Component.literal("Tools").withColor(tab == 0 ? 0x55FF55 : 0xFFFFFF), b -> setTab(0))
                .bounds(colX, boxY + 3, 38, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal("Misc").withColor(tab == 1 ? 0x55FF55 : 0xFFFFFF), b -> setTab(1))
                .bounds(colX + 41, boxY + 3, 38, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal("Fight").withColor(tab == 2 ? 0x55FF55 : 0xFFFFFF), b -> setTab(2))
                .bounds(colX + 82, boxY + 3, 38, 14).build());
        if (tab == 2) {
            addFightPanel();
        }
        this.addRenderableWidget(toggle("Stand", stand, colX, boxY + 126, b -> stand = !stand));
        this.addRenderableWidget(toggle("Cuts", cuts, colX + 62, boxY + 126, b -> cuts = !cuts));

        nameField = new EditBox(this.font, colX, boxY + 156, 120, 16, Component.literal("Player"));
        nameField.setMaxLength(16);
        nameField.setHint(Component.literal("Player name"));
        nameField.setValue(keepName);
        this.addRenderableWidget(nameField);
        this.addRenderableWidget(Button.builder(Component.literal("Load skin"), b -> loadName())
                .bounds(colX, boxY + 174, 58, 16).build());
        this.addRenderableWidget(Button.builder(Component.literal("My skin"), b -> DummySkin.useMine())
                .bounds(colX + 62, boxY + 174, 58, 16).build());
        this.addRenderableWidget(Button.builder(Component.literal("Saved skins >"), b -> DummySkin.useNextFile())
                .bounds(colX, boxY + 192, 120, 16).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose())
                .bounds(boxX + boxW - 48, boxY + 3, 40, 14).build());
    }

    private Button toggle(String label, boolean on, int x, int y, java.util.function.Consumer<Button> action) {
        return Button.builder(Component.literal(label).withColor(on ? 0x55FF55 : 0xFFFFFF), b -> {
            action.accept(b);
            rebuild();
        }).bounds(x, y, 58, 16).build();
    }

    private int tabFirst() {
        return tab == 1 ? MISC_START : 0;
    }

    private int tabLast() {
        return tab == 0 ? MISC_START : tab == 1 ? WEAPONS.length : 0;
    }

    private void setTab(int newTab) {
        if (tab == newTab) {
            return;
        }
        tab = newTab;
        if (tab == 0) {
            selectWeapon(2);
        } else if (tab == 1) {
            selectWeapon(MISC_START);
        }
        rebuild();
    }

    private void addFightPanel() {
        List<String> files = SkinStore.files();
        String skin = files.isEmpty() ? "none" : files.get(Math.floorMod(tplSkin, files.size())).replaceAll("(?i)\\.png$", "");
        this.addRenderableWidget(Button.builder(Component.literal("Skin: " + this.font.plainSubstrByWidth(skin, 72) + " >"), b -> {
            tplSkin++;
            rebuild();
        }).bounds(colX, boxY + 20, 120, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal(FIGHT_NAMES[tplWeapon]), b -> {
            tplWeapon = (tplWeapon + 1) % FIGHT_NAMES.length;
            rebuild();
        }).bounds(colX, boxY + 36, 58, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal(ARMOR_NAMES[tplArmor]).withColor(tplArmor == 0 ? 0xFFFFFF : ARMOR_COLOR[tplArmor]), b -> {
            tplArmor = (tplArmor + 1) % ARMOR_NAMES.length;
            rebuild();
        }).bounds(colX + 62, boxY + 36, 58, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal("Spawn"), b -> spawnFighter())
                .bounds(colX, boxY + 52, 58, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal(mainD != null && mainD.fighter ? "Main: on" : "Main: off")
                .withColor(mainD != null && mainD.fighter ? 0x55FF55 : 0xFFFFFF), b -> toggleMainFighter())
                .bounds(colX + 62, boxY + 52, 58, 14).build());
        this.addRenderableWidget(Button.builder(Component.literal(fightOn ? "FIGHT: ON" : "FIGHT: OFF")
                .withColor(fightOn ? 0x55FF55 : 0xFF8888), b -> {
                    fightOn = !fightOn;
                    won = false;
                    rebuild();
                }).bounds(colX, boxY + 68, 120, 14).build());
    }

    private void rebuild() {
        keepName = nameField == null ? "" : nameField.getValue();
        this.rebuildWidgets();
    }

    private void loadName() {
        keepName = nameField.getValue();
        DummySkin.lookup(keepName);
    }

    private void focus(Dummy d) {
        cur = d;
        sim = d.sim;
    }

    private void rebuildDummy(Dummy d) {
        boolean main = d == mainD;
        if (main) {
            d.slim = DummySkin.slim;
        }
        d.sim = new Sim(arenaX + arenaW * d.fx, arenaY + arenaH - 22, simK, d.slim, arenaX + 2, arenaX + arenaW - 2,
                arenaY + 2, main ? stand : true);
        d.sim.keepTone = d.fighter;
        if (d.fighter) {
            d.sim.tone = 1.0;
        }
        d.hp = MAX_HP;
        d.dead = false;
        d.target = null;
        d.hitPending = false;
        d.downSince = 0;
    }

    private void respawnAll() {
        if (mainD == null) {
            mainD = new Dummy();
            mainD.fx = 0.58;
            mainD.name = "Dummy";
            dummies.add(0, mainD);
        }
        for (Dummy d : dummies) {
            rebuildDummy(d);
        }
        won = false;
        focus(mainD);
        leftDown = false;
        rightDown = false;
        grabButton = -1;
        grabD = null;
    }

    private void respawnMain() {
        rebuildDummy(mainD);
        grabButton = -1;
        grabD = null;
    }

    private void spawnFighter() {
        if (dummies.size() >= 6) {
            addFloat(arenaX + arenaW / 2.0, arenaY + 60, "The box is full (5 fighters max)", 0xFF8888);
            return;
        }
        List<String> files = SkinStore.files();
        if (files.isEmpty()) {
            addFloat(arenaX + arenaW / 2.0, arenaY + 60, "No saved skins", 0xFF8888);
            return;
        }
        String file = files.get(Math.floorMod(tplSkin, files.size()));
        Identifier tex = SkinStore.textureOf(file);
        if (tex == null) {
            addFloat(arenaX + arenaW / 2.0, arenaY + 60, file + " must be a 64x64 PNG", 0xFF8888);
            return;
        }
        Dummy d = new Dummy();
        d.tex = tex;
        d.slim = SkinStore.slimOf(file);
        d.name = file.replaceAll("(?i)\\.png$", "");
        d.fighter = true;
        d.weapon = FIGHT_WEAPONS[tplWeapon];
        d.armor = tplArmor;
        double bestX = 0.5, bestGap = -1;
        for (int i = 0; i < 16; i++) {
            double f = 0.1 + 0.8 * RANDOM.nextDouble();
            double gap = 9;
            for (Dummy o : dummies) {
                gap = Math.min(gap, Math.abs(f - o.fx));
            }
            if (gap > bestGap) {
                bestGap = gap;
                bestX = f;
            }
        }
        d.fx = bestX;
        rebuildDummy(d);
        dummies.add(d);
        won = false;
        d.sim.sparkle(d.sim.parts[Sim.CHEST].cx(), d.sim.parts[Sim.CHEST].cy(), 16, new int[] {0xFFFFFFFF, 0xFFCCCCCC, 0xFF88CCFF});
        play(SoundEvents.UI_BUTTON_CLICK, 1.2F);
    }

    private void toggleMainFighter() {
        mainD.fighter = !mainD.fighter;
        mainD.weapon = FIGHT_WEAPONS[tplWeapon];
        mainD.armor = tplArmor;
        mainD.sim.keepTone = mainD.fighter;
        if (mainD.fighter) {
            mainD.sim.tone = 1.0;
            mainD.hp = MAX_HP;
            mainD.dead = false;
        }
        won = false;
        rebuild();
    }

    private double[] chestOf(Dummy d) {
        Sim.Part c = d.sim.parts[Sim.CHEST];
        return new double[] {c.cx(), c.cy()};
    }

    /** The dummy with a part under the point, or null. */
    private Dummy dummyAt(double x, double y, double pad) {
        for (int i = dummies.size() - 1; i >= 0; i--) {
            Dummy d = dummies.get(i);
            if (d.sim.hit(x, y, pad) != null) {
                return d;
            }
        }
        return null;
    }

    /** The part under the point (and focus moves to its dummy), or null. */
    private Sim.Part pick(double x, double y, double pad) {
        Dummy d = dummyAt(x, y, pad);
        if (d == null) {
            return null;
        }
        focus(d);
        return d.sim.hit(x, y, pad);
    }

    private double distanceTo(Dummy d, double x, double y) {
        double best = Double.MAX_VALUE;
        for (Sim.Part p : d.sim.parts) {
            best = Math.min(best, Math.hypot(p.cx() - x, p.cy() - y));
        }
        return best;
    }

    private Dummy nearestDummy(double x, double y) {
        Dummy best = mainD;
        double bd = Double.MAX_VALUE;
        for (Dummy d : dummies) {
            double dist = distanceTo(d, x, y);
            if (dist < bd) {
                bd = dist;
                best = d;
            }
        }
        return best;
    }

    private void resetStats() {
        total = 0;
        last = 0;
        best = 0;
        hits = 0;
        cutCount = 0;
        lastNote = "";
        recent.clear();
        floats.clear();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---- sounds ----

    private void play(SoundEvent sound, float pitch) {
        try {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch));
        } catch (Throwable ignored) {
        }
    }

    private void play(Holder<SoundEvent> sound, float pitch) {
        try {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch));
        } catch (Throwable ignored) {
        }
    }

    // ---- combat ----

    private void selectWeapon(int index) {
        selected = index;
        bowDrawStart = -1;
        loaded = false;
        loadStart = now();
        lastSwing = now() - 10_000;
        play(SoundEvents.UI_BUTTON_CLICK, 1.0F);
    }

    private double strength(long t) {
        Weapon w = weapon();
        if (w.cooldownMs() <= 0) {
            return 1.0;
        }
        return Math.min(1.0, (t - lastSwing) / (double) w.cooldownMs());
    }

    /**
     * Mace bonus from how fast the cursor is moving down at the instant of the click: 0 when slow, full when a hard
     * downward swing is caught at its peak speed. Clicking early or late (slower) gives much less.
     */
    private static double smashLevel(double down) {
        return Math.max(0, Math.min(1.0, (down - 250) / 1250.0));
    }

    private static double smashBonus(double down) {
        return 44.0 * Math.pow(smashLevel(down), 1.5);
    }

    private boolean spinCrit() {
        return spin >= CRIT_SPIN;
    }

    /** Damage of one clean swing at full charge (no crit), with the current toggles. */
    private double fullHit() {
        Weapon w = weapon();
        double d = w.damage() + (sharp && !w.bare() ? 3.0 : 0.0);
        return d;
    }

    private static String fmt(double v) {
        String s = String.format(Locale.ROOT, "%.1f", v);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    private void addFloat(double x, double y, String text, int color) {
        floats.add(new Floating(now(), x, y, RANDOM.nextInt(21) - 10, text, color));
    }

    /** Vanilla armor formula; returns the damage a wearer of the armor tier actually takes. */
    private static double armorReduce(double dmg, int armor) {
        double points = ARMOR_POINTS[armor], tough = ARMOR_TOUGH[armor];
        double f = Math.min(20, Math.max(points / 5.0, points - 4 * dmg / (tough + 8)));
        return dmg * (1 - f / 25.0);
    }

    /** Damage after armor; fighters lose hit points and fall when they run out. */
    private double dealt(Dummy d, double dmg) {
        if (!d.fighter || d.dead) {
            return dmg;
        }
        double eff = armorReduce(dmg, d.armor);
        d.hp -= eff;
        if (d.hp <= 0) {
            if (d.sim.totem) {
                totemRevive(d);
            } else {
                knockOut(d);
            }
        }
        return eff;
    }

    /** A totem of undying brings the dummy back every time it would die. */
    private void totemRevive(Dummy d) {
        d.hp = MAX_HP;
        d.sim.extinguish();
        double[] c = chestOf(d);
        d.sim.sparkle(c[0], c[1], 40, new int[] {0xFFFFD84A, 0xFFE8B820, 0xFF7CE06A, 0xFFFFF0A0, 0xFFFFFFFF});
        play(SoundEvents.TOTEM_USE, 1.0F);
        addFloat(c[0], c[1] - 34, "The totem saved " + d.name + "!", 0xFFD84A);
    }

    private void knockOut(Dummy d) {
        d.dead = true;
        d.hp = 0;
        d.sim.drive = 0;
        d.sim.keepTone = false;
        d.sim.knock();
        double[] c = chestOf(d);
        addFloat(c[0], c[1] - 30, d.name + " is out!", 0xFF5555);
        play(SoundEvents.PLAYER_DEATH, 1.0F);
        if (fightOn && !won) {
            Dummy last = null;
            int alive = 0, fighters = 0;
            for (Dummy o : dummies) {
                if (o.fighter) {
                    fighters++;
                    if (!o.dead) {
                        alive++;
                        last = o;
                    }
                }
            }
            if (fighters >= 2 && alive == 1) {
                won = true;
                addFloat(arenaX + arenaW / 2.0, arenaY + 70, last.name + " wins!", 0xFFD84A);
            }
        }
    }

    private void register(double rawDmg, String note, double x, double y) {
        double dmg = dealt(cur, rawDmg);
        total += dmg;
        last = dmg;
        best = Math.max(best, dmg);
        hits++;
        lastNote = note;
        recent.add(new double[] {now(), dmg});
        play(SoundEvents.PLAYER_HURT, 1.0F);
        int color = note.equals("CRIT") ? 0xFFAA00 : note.equals("SMASH") || note.equals("THRUST") || note.equals("BLAST") ? 0xFF5555 : 0xFFFFFF;
        addFloat(x, y, fmt(dmg) + (note.isEmpty() || note.equals("weak") ? "" : " " + note), color);
    }

    /** One landed hit: shove the part, count the damage, and cut a joint if the weapon allows it. */
    private void strike(Sim.Part part, double x, double y, double dmg, double dirx, double diry, double kick, String note,
            double cutReach, boolean breakOff) {
        double len = Math.max(1e-6, Math.hypot(dirx, diry));
        double dx = dirx / len * kick, dy = diry / len * kick;
        sim.kick(part, x, y, dx, dy);
        register(dmg, note, x, y);
        if (sim.blood) {
            sim.splatter(x, y, dx, dy, (int) Math.min(14, 2 + dmg * 0.8));
        } else if (dmg > 9) {
            sim.puff(x, y, 6, 160);
        }
        if (cuts && cutReach > 0) {
            Sim.Joint joint = sim.nearestJoint(x, y, cutReach * sim.k);
            if (joint != null && sim.sever(joint, dx * 1.1, dy * 1.1 - 120)) {
                cutCount++;
                addFloat(x, y - 12, breakOff ? "BROKE OFF!" : "CUT!", 0xFFD27F);
                play(SoundEvents.SHEEP_SHEAR, 1.0F);
            }
        }
    }

    private double[] chest() {
        Sim.Part c = sim.parts[Sim.CHEST];
        return new double[] {c.cx(), c.cy()};
    }

    private double angleToChest() {
        double[] c = chest();
        return Math.atan2(c[1] - my, c[0] - mx);
    }

    private void swing() {
        Weapon w = weapon();
        long t = now();
        double s = strength(t);
        double scale = 0.2 + 0.8 * s * s;
        double dmg = w.damage() * scale + (sharp && !w.bare() ? 3.0 * s : 0.0);
        double bonus = w.mace() ? smashBonus(Math.max(0, vy)) : 0;
        boolean smash = bonus >= 4;
        if (smash) {
            dmg += bonus * s;
        }
        boolean crits = spinCrit() && s > 0.9;
        if (crits) {
            dmg *= 1.5;
        }
        lastSwing = t;
        swingStart = t;
        double reach = w.spear() ? 24 * SCALE / 1.4 : 0;
        double ang = w.spear() ? angleToChest() : 0;
        if (!w.spear()) {
            omega += (angleToChest() > Math.PI / 2 || angleToChest() < -Math.PI / 2 ? -1 : 1) * 16;
        }
        Sim.Part part = pick(mx, my, 5);
        double hx = mx, hy = my;
        if (part == null && !w.spear()) {
            hx = tipX();
            hy = tipY();
            part = pick(hx, hy, 5);
        }
        if (part == null && reach > 0) {
            hx = mx + Math.cos(ang) * reach;
            hy = my + Math.sin(ang) * reach;
            part = pick(hx, hy, 4);
        }
        if (part == null) {
            play(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F);
            return;
        }
        SoundEvent sound = smash ? (bonus > 18 ? SoundEvents.MACE_SMASH_GROUND_HEAVY : SoundEvents.MACE_SMASH_GROUND)
                : crits ? SoundEvents.PLAYER_ATTACK_CRIT
                : s > 0.9 ? SoundEvents.PLAYER_ATTACK_STRONG : SoundEvents.PLAYER_ATTACK_WEAK;
        play(sound, 1.0F);
        double dirx = w.spear() ? Math.cos(ang) : 160 + vx * 0.5;
        double diry = w.spear() ? Math.sin(ang) : -40 + vy * 0.5;
        double kick = Math.min(2200, 60 + dmg * 38);
        String note = smash ? "SMASH" : crits ? "CRIT" : s < 0.9 ? "weak" : "";
        double cutReach = 0;
        boolean breakOff = false;
        if (s >= 0.9 && w.blade()) {
            cutReach = w.axe() ? 3.6 : 2.8;
        } else if (smash && dmg >= 18) {
            cutReach = 3.2;
            breakOff = true;
        }
        strike(part, hx, hy, dmg, dirx, diry, kick, note, cutReach, breakOff);
        if (smash) {
            sim.kick(part, hx, hy, 0, kick * 0.5);
        }
    }

    private double tipX() {
        return mx + TIP * Math.sin(theta);
    }

    private double tipY() {
        return my + TIP * Math.cos(theta);
    }

    /** Holding left and swinging the weapon's tip through the dummy slashes it; damage grows with tip speed. */
    private void motionHit() {
        Weapon w = weapon();
        if (!leftDown || w.kind() != Kind.MELEE || w.spear() || now() < motionReadyAt) {
            return;
        }
        double tvx = vx + TIP * omega * Math.cos(theta);
        double tvy = vy - TIP * omega * Math.sin(theta);
        double speed = Math.hypot(tvx, tvy);
        double hx = tipX(), hy = tipY();
        if (speed < 350 || !inArena(hx, hy)) {
            return;
        }
        Sim.Part part = pick(hx, hy, 5);
        if (part == null) {
            return;
        }
        motionReadyAt = now() + 160;
        double dmg = w.damage() * (0.4 + Math.min(speed / 800.0, 2.2)) + (sharp && !w.bare() ? 3.0 : 0.0);
        boolean crits = spinCrit();
        if (crits) {
            dmg *= 1.5;
        }
        play(crits ? SoundEvents.PLAYER_ATTACK_CRIT : SoundEvents.PLAYER_ATTACK_STRONG, 1.0F);
        double reach = w.blade() && speed >= 600 ? (w.axe() ? 3.6 : 2.8) : 0;
        strike(part, hx, hy, dmg, tvx, tvy, Math.min(2200, 60 + dmg * 30 + speed * 0.25), crits ? "CRIT" : "", reach, false);
        omega *= 0.5;
    }

    /** Right-hold spear: the faster the cursor moves into the dummy, the harder the thrust. */
    private void spearThrust() {
        Weapon w = weapon();
        double speed = Math.hypot(vx, vy);
        if (speed < 260 || now() < spearReadyAt) {
            return;
        }
        Sim.Part part = pick(mx, my, 3);
        if (part == null) {
            return;
        }
        spearReadyAt = now() + 250;
        double dmg = w.damage() * (0.4 + Math.min(speed / 700.0, 2.6)) + (sharp ? 3.0 : 0.0);
        boolean crits = spinCrit();
        if (crits) {
            dmg *= 1.5;
        }
        double kick = Math.min(2400, speed * 0.7 + dmg * 22);
        play(speed > 900 ? SoundEvents.PLAYER_ATTACK_CRIT : SoundEvents.PLAYER_ATTACK_STRONG, 1.0F);
        strike(part, mx, my, dmg, vx, vy, kick, crits ? "CRIT" : speed > 700 ? "THRUST" : "", 0, false);
    }

    // ---- ranged (auto aim) ----

    /** Aim point: the part nearest the held bow or crossbow (the cursor), led by how fast it is moving. */
    private double[] autoTarget(double speed) {
        Sim.Part nearest = mainD.sim.parts[Sim.CHEST];
        Dummy owner = mainD;
        double best = Double.MAX_VALUE;
        for (Dummy dm : dummies) {
            for (Sim.Part p : dm.sim.parts) {
                double d = Math.hypot(p.cx() - mx, p.cy() - my);
                if (d < best) {
                    best = d;
                    nearest = p;
                    owner = dm;
                }
            }
        }
        aimOwner = owner;
        double[] v = owner.sim.partVelocity(nearest);
        double tx = nearest.cx(), ty = nearest.cy();
        for (int i = 0; i < 2; i++) {
            double time = Math.hypot(tx - mx, ty - my) / speed;
            tx = nearest.cx() + v[0] * time;
            ty = nearest.cy() + v[1] * time;
        }
        return new double[] {tx, ty};
    }

    private double aimAt(double speed) {
        double[] target = autoTarget(speed);
        return Math.atan2(target[1] - my, target[0] - mx);
    }

    private void releaseBow() {
        long held = now() - bowDrawStart;
        bowDrawStart = -1;
        double pull = Math.min(1.0, held / 1000.0);
        double f = (pull * pull + pull * 2.0) / 3.0;
        if (f < 0.1) {
            return;
        }
        f = Math.min(1.0, f);
        double dmg = Math.ceil(f * 3.0 * 2.0);
        if (pull >= 1.0) {
            dmg += RANDOM.nextInt((int) (dmg / 2) + 3);
        }
        double speed = 700 + 900 * f;
        double[] target = autoTarget(speed);
        play(SoundEvents.ARROW_SHOOT, 0.9F + (float) f * 0.4F);
        focus(aimOwner);
        sim.shoot(mx, my, target[0], target[1], speed, dmg, false);
    }

    private void fireCrossbow() {
        if (!loaded) {
            return;
        }
        loaded = false;
        loadStart = now();
        double[] target = autoTarget(1700);
        play(SoundEvents.CROSSBOW_SHOOT, 1.0F);
        focus(aimOwner);
        sim.shoot(mx, my, target[0], target[1], 1700, 7.0 + RANDOM.nextInt(6), true);
    }

    private void arrowHit(Sim.Arrow a) {
        double[] pos = sim.arrowPos(a);
        double speed = Math.max(1, Math.hypot(a.vx, a.vy));
        double kick = Math.min(1600, 80 + a.damage * 28);
        sim.kick(a.part, pos[0], pos[1], a.vx / speed * kick, a.vy / speed * kick);
        if (sim.blood) {
            sim.splatter(pos[0], pos[1], a.vx, a.vy, 6);
        }
        play(SoundEvents.ARROW_HIT_PLAYER, 1.0F);
        register(a.damage, a.crossbow ? "bolt" : "arrow", pos[0], pos[1]);
    }

    // ---- explosives and fire ----

    private Obj objectAt(double x, double y, double radius) {
        Obj best = null;
        double bd = radius;
        for (Obj o : objs) {
            double d = Math.hypot(o.x - x, o.y - y);
            if (d <= bd) {
                bd = d;
                best = o;
            }
        }
        return best;
    }

    private void place(boolean tnt) {
        if (objs.size() >= 10) {
            addFloat(mx, my, "Too many!", 0xFF8888);
            return;
        }
        objs.add(new Obj(tnt, mx, my, 2.0F));
        play(SoundEvents.UI_BUTTON_CLICK, 0.8F);
    }

    private void light(Obj o, long delay) {
        if (!o.tnt || o.lit) {
            return;
        }
        o.lit = true;
        o.fuseAt = now() + delay;
        play(SoundEvents.TNT_PRIMED, 1.0F);
    }

    private void shorten(Obj o, long delay) {
        if (o.lit) {
            o.fuseAt = Math.min(o.fuseAt, now() + delay);
        } else {
            light(o, delay);
        }
    }

    private void detonate(Obj o) {
        if (!objs.remove(o)) {
            return;
        }
        blast(o.x, o.y, o.tnt ? 4.0 : 6.0, o.tnt ? 1.0F : 0.85F);
    }

    /** Explosion particles: a shockwave ring, a fireball and flying sparks and debris, scaled by power. */
    private void burst(double x, double y, double power) {
        burst(x, y, power, false);
    }

    /** With up set the debris and fire shoot upward like a pillar of TNT. */
    private void burst(double x, double y, double power, boolean up) {
        int[] colors = {0xFFFFF2B0, 0xFFFFC040, 0xFFFF7A20, 0xFFE04010, 0xFF888888, 0xFF555555, 0xFFFFFFFF};
        int n = (int) (24 + power * 14);
        for (int i = 0; i < n; i++) {
            double ang = RANDOM.nextDouble() * Math.PI * 2;
            double sp = (60 + RANDOM.nextDouble() * 560) * (0.45 + power / 9.0);
            double life = 0.45 + RANDOM.nextDouble() * 0.8;
            int color = colors[RANDOM.nextInt(colors.length)];
            double svx = Math.cos(ang) * sp, svy = Math.sin(ang) * sp - 60;
            if (up) {
                svx *= 0.45;
                svy = -Math.abs(svy) * 1.3 - 160;
            }
            sparks.add(new double[] {x, y, svx, svy, life, life, 2 + RANDOM.nextInt(power > 7 ? 4 : 3), color});
        }
        rings.add(new double[] {x, y, now(), power});
    }

    /** An explosion at a point: damages and flings every dummy, and sets off or pops nearby objects. */
    private void blast(double x, double y, double power, float pitch) {
        play(SoundEvents.GENERIC_EXPLODE, pitch);
        burst(x, y, power);
        for (Dummy d : new ArrayList<>(dummies)) {
            double dmg = d.sim.explode(x, y, power);
            if (dmg <= 0) {
                continue;
            }
            focus(d);
            dmg = dealt(d, dmg);
            double[] c = chestOf(d);
            total += dmg;
            last = dmg;
            best = Math.max(best, dmg);
            hits++;
            lastNote = "BLAST";
            recent.add(new double[] {now(), dmg});
            addFloat(c[0], c[1] - 20, fmt(dmg) + " BLAST", 0xFF5555);
            if (d.sim.blood) {
                d.sim.splatter(c[0], c[1], c[0] - x, c[1] - y - 20, 12);
            }
        }
        double reach = power * 2 * 17.78 * simK * 0.45;
        for (Obj other : new ArrayList<>(objs)) {
            if (Math.hypot(other.x - x, other.y - y) <= reach) {
                if (other.tnt) {
                    shorten(other, 350);
                } else {
                    other.popAt = now() + 120;
                }
            }
        }
    }

    private void heal() {
        play(SoundEvents.SPLASH_POTION_BREAK, 1.0F);
        sim.sparkle(mx, my, 18, new int[] {0xFFFF5A8A, 0xFFFF8FB0, 0xFFFFD0DC});
        boolean any = false;
        for (Dummy d : dummies) {
            if (distanceTo(d, mx, my) > 70) {
                continue;
            }
            any = true;
            int n = d.sim.mend();
            boolean revived = false;
            if (d.fighter) {
                revived = d.dead;
                d.hp = MAX_HP;
                if (d.dead) {
                    d.dead = false;
                    d.sim.keepTone = true;
                    d.sim.standUp(chestOf(d)[0]);
                }
            }
            double[] c = chestOf(d);
            d.sim.sparkle(c[0], c[1], 20, new int[] {0xFFFF5A8A, 0xFFFF8FB0, 0xFFFFD0DC, 0xFFFFFFFF});
            addFloat(c[0], c[1] - 22, revived ? "Back on its feet!" : n > 0 ? "Put back together!" : "Healed", 0xFF7FB0);
        }
        if (!any) {
            addFloat(mx, my, "Missed!", 0xFF8888);
        }
    }

    private void toggleTotem() {
        Dummy d = nearestDummy(mx, my);
        if (distanceTo(d, mx, my) > 70) {
            addFloat(mx, my, "Click a dummy", 0xFF8888);
            return;
        }
        d.sim.totem = !d.sim.totem;
        double[] c = chestOf(d);
        if (d.sim.totem) {
            play(SoundEvents.TOTEM_USE, 1.0F);
        } else {
            play(SoundEvents.UI_BUTTON_CLICK, 1.0F);
        }
        d.sim.sparkle(c[0], c[1], 16, new int[] {0xFFFFD84A, 0xFFE8B820, 0xFF7CE06A, 0xFFFFF0A0});
        addFloat(c[0], c[1] - 22, d.sim.totem ? "Totem: can't be cut apart" : "Totem removed", 0xFFD84A);
    }

    private void fireCannon() {
        Weapon w = weapon();
        long t = now();
        if (strength(t) < 1.0 || !inArena(mx, my)) {
            return;
        }
        lastSwing = t;
        play(SoundEvents.FISHING_BOBBER_THROW, 0.8F);
        if (w.name().equals("stab")) {
            // a single beam from the sky: explodes the instant it lands
            beams.add(new double[] {mx, my, t});
            play(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.2F);
            blast(mx, my, 9.0, 0.7F);
            // like a ton of TNT going straight up
            int steps = (int) Math.min(16, (my - arenaY) / 16);
            for (int i = 1; i <= steps; i++) {
                columns.add(new double[] {mx + (RANDOM.nextDouble() - 0.5) * 12, my - i * 16.0, t + i * 28L, 6.0});
            }
            return;
        }
        // nuke: TNT rains all over the ground and goes off two seconds later
        int count = 20;
        for (int i = 0; i < count; i++) {
            double x = arenaX + 10 + RANDOM.nextDouble() * (arenaW - 20);
            double y = arenaY + 4 - RANDOM.nextDouble() * 80;
            Obj o = new Obj(true, x, y, 1.3F);
            o.vy = 200 + RANDOM.nextDouble() * 200;
            o.lit = true;
            o.fuseAt = t + 2000;
            objs.add(o);
        }
        play(SoundEvents.TNT_PRIMED, 1.0F);
    }

    private void igniteAt() {
        Obj o = objectAt(mx, my, 18);
        if (o != null) {
            if (o.tnt) {
                play(SoundEvents.FLINTANDSTEEL_USE, 1.0F);
                light(o, 4000);
            }
            return;
        }
        Sim.Part part = pick(mx, my, 5);
        if (part != null) {
            play(SoundEvents.FLINTANDSTEEL_USE, 1.0F);
            sim.ignite(6.0);
            addFloat(mx, my, "On fire!", 0xFFAA33);
        }
    }

    private void updateObjects(double dt, long t) {
        for (Obj o : new ArrayList<>(objs)) {
            if (o.tnt) {
                o.vy += 1100 * dt;
                o.y = Math.min(mainD.sim.floorY - 8 * o.scale, o.y + o.vy * dt);
                if (o.y >= mainD.sim.floorY - 8 * o.scale) {
                    o.vy = 0;
                }
                if (o.lit && t >= o.fuseAt) {
                    detonate(o);
                }
            } else if (o.popAt > 0 && t >= o.popAt) {
                detonate(o);
            }
        }
        for (Dummy d : dummies) {
            for (Sim.Arrow a : d.sim.arrows) {
                if (a.stuck) {
                    continue;
                }
                Obj o = objectAt(a.x, a.y, 14);
                if (o != null && !o.tnt) {
                    a.stuck = true;
                    o.popAt = t;
                }
            }
        }
    }

    // ---- fighters ----

    private static boolean ranged(Weapon w) {
        return w.kind() == Kind.BOW || w.kind() == Kind.CROSSBOW;
    }

    private static double lenOf(Weapon w) {
        return switch (w.name()) {
            case "Diamond Sword" -> 11;
            case "Diamond Axe" -> 10;
            case "Mace" -> 10;
            case "Diamond Spear" -> 20;
            case "Trident" -> 16;
            default -> 2;
        };
    }

    private static double reachOf(Weapon w, double k) {
        return k * (9 + lenOf(w));
    }

    private static double fighterDamage(Weapon w) {
        return w.mace() ? 12 : w.spear() ? 5 : w.damage();
    }

    private double[] handOf(Dummy d) {
        return d.sim.parts[d.side > 0 ? Sim.ARM_L_LO : Sim.ARM_R_LO].point(0.5, 1.0);
    }

    private Dummy chooseTarget(Dummy d) {
        Dummy best = null;
        double bd = Double.MAX_VALUE;
        double[] me = chestOf(d);
        for (Dummy o : dummies) {
            if (o == d || !o.fighter || o.dead) {
                continue;
            }
            double dist = Math.abs(chestOf(o)[0] - me[0]);
            if (dist < bd) {
                bd = dist;
                best = o;
            }
        }
        if (best == null && mainD != d && !mainD.fighter) {
            best = mainD;
        }
        return best;
    }

    private void updateFighters(long t) {
        for (Dummy d : dummies) {
            if (!d.fighter) {
                continue;
            }
            if (d.dead) {
                d.sim.drive = 0;
                continue;
            }
            boolean upright = d.sim.tilt() <= 1.0;
            if (!upright) {
                if (d.downSince == 0) {
                    d.downSince = t;
                } else if (t - d.downSince > 1500) {
                    d.sim.standUp(chestOf(d)[0]);
                    d.downSince = 0;
                }
            } else {
                d.downSince = 0;
            }
            Dummy target = fightOn ? chooseTarget(d) : null;
            d.target = target;
            if (target == null || !upright) {
                d.sim.drive = 0;
                continue;
            }
            double[] me = chestOf(d), tc = chestOf(target);
            double dx = tc[0] - me[0];
            d.side = dx >= 0 ? 1 : -1;
            Weapon w = WEAPONS[d.weapon];
            double dist = Math.abs(dx), speed = 20.0 * simK, reach = reachOf(w, simK);
            if (ranged(w)) {
                d.sim.drive = dist > 270 ? d.side * speed : dist < 150 ? -d.side * speed : 0;
            } else {
                d.sim.drive = dist > reach * 0.8 ? d.side * speed : 0;
            }
            if (d.hitPending && t - d.swingStart >= 110) {
                d.hitPending = false;
                meleeHit(d, target, w);
            }
            if (t >= d.nextAttack) {
                if (ranged(w)) {
                    if (dist > 100 && dist < 520) {
                        fighterShoot(d, target, w, t);
                    }
                } else if (dist <= reach) {
                    d.swingStart = t;
                    d.hitPending = true;
                    d.nextAttack = t + (long) (w.cooldownMs() * 1.25) + RANDOM.nextInt(250);
                }
            }
        }
    }

    private void meleeHit(Dummy d, Dummy victim, Weapon w) {
        double[] hand = handOf(d);
        double[] vc = chestOf(victim);
        double ddx = vc[0] - hand[0], ddy = vc[1] - hand[1], dd = Math.max(1.0, Math.hypot(ddx, ddy));
        double len = Math.min(dd, simK * lenOf(w));
        double tipX = hand[0] + ddx / dd * len, tipY = hand[1] + ddy / dd * len;
        Sim.Part part = null;
        double bd = Double.MAX_VALUE;
        for (Sim.Part p : victim.sim.parts) {
            double dist = Math.hypot(p.cx() - tipX, p.cy() - tipY);
            if (dist < bd) {
                bd = dist;
                part = p;
            }
        }
        if (part == null || bd > simK * 8) {
            play(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F);
            return;
        }
        double dmg = fighterDamage(w);
        focus(victim);
        double eff = dealt(victim, dmg);
        double px = part.cx(), py = part.cy();
        victim.sim.kick(part, px, py, d.side * (200 + dmg * 45), -90);
        if (victim.sim.blood) {
            victim.sim.splatter(px, py, d.side * 200, -60, (int) Math.min(12, 2 + eff));
        } else if (dmg > 8) {
            victim.sim.puff(px, py, 5, 140);
        }
        addFloat(px, py - 10, fmt(eff), 0xFFFFFF);
        play(SoundEvents.PLAYER_ATTACK_STRONG, 1.0F);
        if (cuts && w.blade() && RANDOM.nextInt(100) < 16) {
            Sim.Joint joint = victim.sim.nearestJoint(px, py, 2.6 * simK);
            if (joint != null && victim.sim.sever(joint, d.side * 300, -150)) {
                addFloat(px, py - 22, "CUT!", 0xFFD27F);
                play(SoundEvents.SHEEP_SHEAR, 1.0F);
            }
        }
    }

    private void fighterShoot(Dummy d, Dummy victim, Weapon w, long t) {
        boolean xb = w.kind() == Kind.CROSSBOW;
        double speed = xb ? 1700 : 1300;
        double[] hand = handOf(d);
        Sim.Part tp = victim.sim.parts[Sim.CHEST];
        double[] v = victim.sim.partVelocity(tp);
        double time = Math.hypot(tp.cx() - hand[0], tp.cy() - hand[1]) / speed;
        Sim.Arrow a = victim.sim.shoot(hand[0], hand[1], tp.cx() + v[0] * time, tp.cy() + v[1] * time, speed,
                xb ? 8 + RANDOM.nextInt(4) : 6 + RANDOM.nextInt(4), xb);
        a.fromFighter = true;
        d.swingStart = t;
        d.nextAttack = t + (long) (w.cooldownMs() * 1.3) + RANDOM.nextInt(300);
        play(xb ? SoundEvents.CROSSBOW_SHOOT : SoundEvents.ARROW_SHOOT, 1.0F);
    }

    private void fighterArrowHit(Dummy victim, Sim.Arrow a) {
        double[] pos = victim.sim.arrowPos(a);
        double speed = Math.max(1, Math.hypot(a.vx, a.vy));
        double kick = Math.min(1200, 80 + a.damage * 22);
        victim.sim.kick(a.part, pos[0], pos[1], a.vx / speed * kick, a.vy / speed * kick);
        if (victim.sim.blood) {
            victim.sim.splatter(pos[0], pos[1], a.vx, a.vy, 5);
        }
        focus(victim);
        double eff = dealt(victim, a.damage);
        play(SoundEvents.ARROW_HIT_PLAYER, 1.0F);
        addFloat(pos[0], pos[1] - 8, fmt(eff), 0xFFFFFF);
    }

    // ---- input ----

    private boolean inArena(double x, double y) {
        return x >= arenaX && x < arenaX + arenaW && y >= arenaY && y < arenaY + arenaH;
    }

    private int slotAt(double x, double y) {
        int col = (int) Math.floor((x - colX) / 22.0);
        int row = (int) Math.floor((y - (boxY + 20)) / 22.0);
        if (col < 0 || col > 4 || row < 0 || row > 2 || x - colX - col * 22 > 20 || y - (boxY + 20) - row * 22 > 20) {
            return -1;
        }
        int index = tabFirst() + row * 5 + col;
        return index < tabLast() ? index : -1;
    }

    private void tryGrab(int button) {
        Sim.Part part = pick(mx, my, 4);
        if (part != null) {
            sim.grab(part, mx, my);
            grabD = cur;
            grabButton = button;
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        mx = event.x();
        my = event.y();
        int button = event.button();
        if (button == 0) {
            int slot = slotAt(mx, my);
            if (slot >= 0) {
                selectWeapon(slot);
                return true;
            }
        }
        if (!inArena(mx, my) || (button != 0 && button != 1)) {
            return false;
        }
        Weapon w = weapon();
        if (button == 0) {
            leftDown = true;
            switch (w.kind()) {
                case MELEE -> {
                    Obj o = objectAt(mx, my, 16);
                    if (o != null) {
                        swingStart = now();
                        omega += 14;
                        if (!o.tnt) {
                            o.popAt = now();
                        } else {
                            play(SoundEvents.PLAYER_ATTACK_WEAK, 0.7F);
                        }
                    } else {
                        swing();
                    }
                }
                case PLACE -> place(w.name().equals("TNT"));
                case HEAL -> heal();
                case TOTEM -> toggleTotem();
                case CANNON -> fireCannon();
                case IGNITE -> igniteAt();
                default -> tryGrab(0);
            }
        } else {
            rightDown = true;
            switch (w.kind()) {
                case BOW -> bowDrawStart = now();
                case CROSSBOW -> fireCrossbow();
                case MELEE -> {
                    if (!w.spear()) {
                        tryGrab(1);
                    }
                }
                default -> tryGrab(1);
            }
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        int button = event.button();
        boolean handled = false;
        if (button == 0) {
            leftDown = false;
        } else if (button == 1) {
            rightDown = false;
            if (bowDrawStart >= 0) {
                releaseBow();
                handled = true;
            }
        }
        if (grabButton == button) {
            if (grabD != null) {
                grabD.sim.release();
                grabD = null;
            }
            grabButton = -1;
            handled = true;
        }
        return handled || super.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if ((event.key() == InputConstants.KEY_RETURN || event.key() == InputConstants.KEY_NUMPADENTER) && nameField != null && nameField.isFocused()) {
            loadName();
            return true;
        }
        return super.keyPressed(event);
    }

    // ---- drawing helpers ----

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractBackground(g, mouseX, mouseY, delta);
        g.fill(boxX, boxY, boxX + boxW, boxY + boxH, 0xFF000000);
        g.outline(boxX, boxY, boxW, boxH, 0xFF5A5A5A);
        g.fill(arenaX, arenaY, arenaX + arenaW, arenaY + arenaH, 0xFF141414);
        g.outline(arenaX, arenaY, arenaW, arenaH, 0xFF3C3C3C);
        int ground = arenaY + arenaH - 22;
        g.fill(arenaX + 1, ground, arenaX + arenaW - 1, arenaY + arenaH - 1, 0xFF262626);
        g.fill(arenaX + 1, ground, arenaX + arenaW - 1, ground + 1, 0xFF4A4A4A);
    }

    private static void enter(GuiGraphicsExtractor g, double x, double y, double rot) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().rotate((float) rot);
    }

    private static void leave(GuiGraphicsExtractor g) {
        g.pose().popMatrix();
    }

    /** {u, v, overlayU, overlayV, width, height} in skin pixels for a body part. */
    private static int[] uv(int kind, boolean slim) {
        int aw = slim ? 3 : 4;
        return switch (kind) {
            case Sim.HEAD -> new int[] {8, 8, 40, 8, 8, 8};
            case Sim.CHEST -> new int[] {20, 20, 20, 36, 8, 6};
            case Sim.HIPS -> new int[] {20, 26, 20, 42, 8, 6};
            case Sim.ARM_R_UP -> new int[] {44, 20, 44, 36, aw, 6};
            case Sim.ARM_R_LO -> new int[] {44, 26, 44, 42, aw, 6};
            case Sim.ARM_L_UP -> new int[] {36, 52, 52, 52, aw, 6};
            case Sim.ARM_L_LO -> new int[] {36, 58, 52, 58, aw, 6};
            case Sim.LEG_R_UP -> new int[] {4, 20, 4, 36, 4, 6};
            case Sim.LEG_R_LO -> new int[] {4, 26, 4, 42, 4, 6};
            case Sim.LEG_L_UP -> new int[] {20, 52, 4, 52, 4, 6};
            default -> new int[] {20, 58, 4, 58, 4, 6};
        };
    }

    private void drawPart(GuiGraphicsExtractor g, Identifier tex, Sim.Part p, boolean slim, int armor, boolean dead) {
        int[] t = uv(p.kind, slim);
        int w = (int) Math.round(p.w), h = (int) Math.round(p.h);
        int tint = dead ? 0xFF909090 : p.flash > 0 ? 0xFFFF7070 : 0xFFFFFFFF;
        enter(g, p.cx(), p.cy(), p.angle());
        g.blit(RenderPipelines.GUI_TEXTURED, tex, -w / 2, -h / 2, (float) t[0], (float) t[1], w, h, t[4], t[5], 64, 64, tint);
        g.blit(RenderPipelines.GUI_TEXTURED, tex, -w / 2, -h / 2, (float) t[2], (float) t[3], w, h, t[4], t[5], 64, 64, tint);
        if (armor > 0 && p.kind != Sim.ARM_R_LO && p.kind != Sim.ARM_L_LO) {
            int x0 = -w / 2, y0 = -h / 2, x1 = x0 + w, y1 = y0 + h;
            if (p.kind == Sim.HEAD) {
                y1 = y0 + h * 5 / 8;
            } else if (p.kind == Sim.LEG_R_LO || p.kind == Sim.LEG_L_LO) {
                y0 = y1 - h * 3 / 5;
            }
            g.fill(x0, y0, x1, y1, (0xB4 << 24) | ARMOR_COLOR[armor]);
            g.outline(x0, y0, x1 - x0, y1 - y0, 0x66000000);
        }
        leave(g);
    }

    private void drawFighterWeapon(GuiGraphicsExtractor g, Dummy d, long t) {
        Weapon w = WEAPONS[d.weapon];
        if (w.bare()) {
            return;
        }
        ItemStack stack = new ItemStack(w.item());
        Sim.Part arm = d.sim.parts[d.side > 0 ? Sim.ARM_L_LO : Sim.ARM_R_LO];
        double[] hand = arm.point(0.5, 0.95);
        float sc = (float) (simK * 0.55);
        long since = t - d.swingStart;
        if (ranged(w) || w.spear()) {
            double ang = d.side > 0 ? -0.3 : Math.PI + 0.3;
            if (d.target != null) {
                double[] tc = chestOf(d.target);
                ang = Math.atan2(tc[1] - hand[1], tc[0] - hand[0]);
            }
            if (ranged(w)) {
                enter(g, hand[0] + Math.cos(ang) * simK * 3, hand[1] + Math.sin(ang) * simK * 3, ang + 3 * Math.PI / 4);
                g.pose().scale(sc, sc);
                g.item(stack, -8, -8);
                leave(g);
                return;
            }
            double off = w.spear() && since < 220 ? Math.sin(Math.PI * since / 220.0) * simK * 3 : 0;
            enter(g, hand[0] + Math.cos(ang) * off, hand[1] + Math.sin(ang) * off, ang + Math.PI / 4);
            g.pose().scale(sc, sc);
        } else {
            double sweep = since < 220 ? -0.9 + 2.5 * since / 220.0 : 0.0;
            double rot = arm.angle() + sweep;
            enter(g, hand[0], hand[1], d.side > 0 ? rot : -rot);
            g.pose().scale(d.side > 0 ? sc : -sc, sc);
        }
        g.item(stack, 0, -16);
        leave(g);
    }

    private void drawDummy(GuiGraphicsExtractor g, Dummy d, long t) {
        Identifier tex = d == mainD ? DummySkin.texture : d.tex;
        if (tex != null) {
            for (int kind : DRAW_ORDER) {
                drawPart(g, tex, d.sim.parts[kind], d.slim, d.fighter ? d.armor : 0, d.dead);
            }
        }
        if (d.fighter) {
            drawFighterWeapon(g, d, t);
            Sim.Part head = d.sim.parts[Sim.HEAD];
            int bx = (int) head.cx(), by = (int) (head.cy() - head.h * 0.5 - 8);
            g.fill(bx - 18, by, bx + 18, by + 4, 0xFF000000);
            int filled = (int) (34 * Math.max(0, d.hp) / MAX_HP);
            g.fill(bx - 17, by + 1, bx - 17 + filled, by + 3, d.hp / MAX_HP > 0.3 ? 0xFF3FBF3F : 0xFFD04040);
            g.text(this.font, d.name, bx - this.font.width(d.name) / 2, by - 10, d.dead ? 0xFF888888 : 0xFFFFFFFF);
        }
    }

    private void meter(GuiGraphicsExtractor g, int cx, int y, int w, double fraction, int color, String label) {
        int x = cx - w / 2;
        g.fill(x - 1, y - 1, x + w + 1, y + 11, 0xFF555555);
        g.fill(x, y, x + w, y + 10, 0xFF000000);
        g.fill(x, y, x + (int) (w * Math.max(0, Math.min(1, fraction))), y + 10, color);
        g.text(this.font, label, cx - this.font.width(label) / 2, y + 1, 0xFFFFFFFF);
    }

    private String describe() {
        Weapon w = weapon();
        return switch (w.kind()) {
            case GRAB -> "Grab: drag the dummy around and throw it";
            case MELEE -> w.mace() ? "Mace: " + fmt(fullHit()) + " dmg, up to +44 from downward speed"
                    : w.name() + ": " + fmt(fullHit()) + " dmg, spin fast for crits";
            case BOW -> "Bow: 6-11 dmg, auto aim, full draw 1s";
            case CROSSBOW -> "Crossbow: 7-12 dmg, auto aim, 1.25s reload";
            case PLACE -> w.name().equals("TNT") ? "TNT: 4s fuse, power 4" : "End Crystal: pops when hit, power 6";
            case IGNITE -> "Flint and Steel: light TNT or the dummy";
            case HEAL -> "Splash Healing: puts the dummy back together";
            case TOTEM -> "Totem of Undying: the dummy can't be cut apart";
            case CANNON -> w.name().equals("stab") ? "stab: instant orbital strike, power 9"
                    : "nuke: TNT rain, 2 second fuse";
        };
    }

    private String hint() {
        Weapon w = weapon();
        return switch (w.kind()) {
            case GRAB -> "Left or right drag to grab";
            case MELEE -> w.mace() ? "Left: smash - click while the cursor is moving down fast"
                    : w.spear() ? "Left: jab   Right hold + move fast: thrust"
                    : "Left: swing   Hold left + whip the cursor: slash   Right: grab";
            case BOW -> "Right hold: draw, release: shoot   Left: grab";
            case CROSSBOW -> "Right click: fire   Left: grab";
            case PLACE -> w.name().equals("TNT") ? "Left: place   light it with flint and steel" : "Left: place   hit it with anything to pop it";
            case IGNITE -> "Left click TNT or the dummy   Right: grab";
            case HEAL -> "Left: throw it at the dummy   Right: grab";
            case TOTEM -> "Left: click the dummy to toggle   Right: grab";
            case CANNON -> "Left: cast the rod where you want it to land";
        };
    }

    private void drawHeld(GuiGraphicsExtractor g, long t) {
        Weapon w = weapon();
        ItemStack stack = stackFor(w);
        if (w.kind() == Kind.GRAB) {
            return;
        }
        if (w.kind() == Kind.BOW || w.kind() == Kind.CROSSBOW) {
            // the bow and crossbow sprites bulge toward their upper-left, so that corner is turned toward the dummy
            double ang = aimAt(w.kind() == Kind.BOW ? 700 + 900 * Math.min(1.0, Math.max(0, now() - bowDrawStart) / 1000.0) : 1700);
            enter(g, mx + Math.cos(ang) * 14, my + Math.sin(ang) * 14, ang + 3 * Math.PI / 4);
            g.pose().scale(SCALE, SCALE);
            g.item(stack, -8, -8);
            leave(g);
            return;
        }
        if (w.spear() || w.kind() == Kind.BOW || w.kind() == Kind.CROSSBOW) {
            double ang = w.spear() ? (rightDown && Math.hypot(vx, vy) > 80 ? aimAngle : angleToChest())
                    : aimAt(w.kind() == Kind.BOW ? 700 + 900 * Math.min(1.0, Math.max(0, now() - bowDrawStart) / 1000.0) : 1700);
            double off = 0;
            long since = t - swingStart;
            if (w.spear() && since < 160) {
                off = Math.sin(Math.PI * since / 160.0) * 22 * SCALE / 1.4;
            }
            enter(g, mx + Math.cos(ang) * off, my + Math.sin(ang) * off, ang + Math.PI / 4);
            g.pose().scale(SCALE, SCALE);
            g.item(stack, -16, 0);
            leave(g);
            return;
        }
        if (w.kind() == Kind.PLACE || w.kind() == Kind.HEAL || w.kind() == Kind.TOTEM) {
            enter(g, mx, my, 0);
            g.pose().scale(2.0F, 2.0F);
            g.item(stack, -8, -8);
            leave(g);
            return;
        }
        enter(g, mx, my, 3 * Math.PI / 4 - theta);
        g.pose().scale(SCALE, SCALE);
        g.item(stack, 0, -16);
        leave(g);
    }

    private void aimGuide(GuiGraphicsExtractor g, double speed) {
        double[] target = autoTarget(speed);
        double ox = mx, oy = my;
        double dx = target[0] - ox, dy = target[1] - oy, d = Math.hypot(dx, dy);
        if (d < 10) {
            return;
        }
        for (double s = 12; s < d; s += 10) {
            int px = (int) (ox + dx / d * s), py = (int) (oy + dy / d * s);
            g.fill(px, py, px + 2, py + 2, 0x90CCCCCC);
        }
        g.fill((int) ox - 2, (int) oy - 2, (int) ox + 3, (int) oy + 3, 0xFFAAAAAA);
        g.fill((int) target[0] - 3, (int) target[1] - 3, (int) target[0] + 4, (int) target[1] + 4, 0x80FF5555);
    }

    private void drawObjects(GuiGraphicsExtractor g, long t) {
        for (Obj o : objs) {
            ItemStack stack = new ItemStack(o.tnt ? Items.TNT : Items.END_CRYSTAL);
            enter(g, o.x, o.y, 0);
            g.pose().scale(o.scale, o.scale);
            g.item(stack, -8, -8);
            leave(g);
            if (o.lit && (t / 140) % 2 == 0) {
                int r = (int) (7 * o.scale);
                g.fill((int) o.x - r, (int) o.y - r, (int) o.x + r, (int) o.y + r, 0x99FFFFFF);
            }
        }
    }

    // ---- frame ----

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        long t = now();
        double dt = lastFrame == 0 ? 0.016 : Math.min(0.05, (t - lastFrame) / 1000.0);
        lastFrame = t;
        double nx = mouseX, ny = mouseY;
        if (dt > 0) {
            double sx = (nx - mx) / dt, sy = (ny - my) / dt;
            vx += (sx - vx) * 0.35;
            vy += (sy - vy) * 0.35;
        }
        mx = nx;
        my = ny;
        double speed = Math.hypot(vx, vy);
        if (speed > 80) {
            aimAngle = Math.atan2(vy, vx);
        }
        // spin: how fast the direction of the cursor's motion turns (circle the cursor to spin the weapon)
        if (speed > 150 && dt > 0) {
            double turn = aimAngle - prevAim;
            while (turn > Math.PI) {
                turn -= 2 * Math.PI;
            }
            while (turn < -Math.PI) {
                turn += 2 * Math.PI;
            }
            spin += (Math.abs(turn) / dt - spin) * 0.3;
            prevAim = aimAngle;
        } else {
            spin *= 0.9;
            prevAim = aimAngle;
        }
        // the held weapon is a pendulum hanging from the cursor: gravity pulls it down, cursor acceleration whips it
        if (dt > 0) {
            double ax = Math.max(-14000, Math.min(14000, (vx - pvx) / dt));
            double ay = Math.max(-14000, Math.min(14000, (vy - pvy) / dt));
            int steps = 6;
            double h = dt / steps;
            for (int i = 0; i < steps; i++) {
                double acc = -((PEND_G - ay) * Math.sin(theta) + ax * Math.cos(theta)) / PEND_L - 1.4 * omega;
                omega += acc * h;
                omega = Math.max(-45, Math.min(45, omega));
                theta += omega * h;
            }
            while (theta > Math.PI) {
                theta -= 2 * Math.PI;
            }
            while (theta < -Math.PI) {
                theta += 2 * Math.PI;
            }
        }
        pvx = vx;
        pvy = vy;

        if (mainD.slim != DummySkin.slim) {
            respawnMain();
        }
        for (Dummy d : dummies) {
            d.sim.blood = blood;
        }
        focus(nearestDummy(mx, my));
        Weapon w = weapon();
        if (w.kind() == Kind.CROSSBOW && !loaded && t - loadStart >= 1250) {
            loaded = true;
            play(SoundEvents.CROSSBOW_LOADING_END, 1.0F);
        }
        if (grabButton >= 0 && grabD != null) {
            grabD.sim.dragTo(mx, my);
        }
        if (w.spear() && rightDown && inArena(mx, my)) {
            spearThrust();
        }
        motionHit();
        updateFighters(t);
        for (Dummy d : new ArrayList<>(dummies)) {
            d.sim.advance(dt);
            focus(d);
            for (Sim.Arrow a : d.sim.flyArrows(dt)) {
                if (a.fromFighter) {
                    fighterArrowHit(d, a);
                } else {
                    arrowHit(a);
                }
            }
            int ticks = d.sim.takeFireTicks();
            if (ticks > 0) {
                double[] c = chestOf(d);
                for (int i = 0; i < ticks; i++) {
                    register(1.0, "fire", c[0], c[1] - 20);
                }
            }
            if (d.sim.takeTotemPops() > 0 && t - totemSound > 400) {
                totemSound = t;
                double[] c = chestOf(d);
                play(SoundEvents.TOTEM_USE, 1.3F);
                addFloat(c[0], c[1] - 24, "TOTEM!", 0xFFD84A);
            }
        }
        updateObjects(dt, t);
        for (int i = sparks.size() - 1; i >= 0; i--) {
            double[] sp = sparks.get(i);
            sp[4] -= dt;
            sp[3] += 900 * dt * (sp[7] == 0xFF888888 || sp[7] == 0xFF555555 ? -0.25 : 0.6);
            sp[0] += sp[2] * dt;
            sp[1] += sp[3] * dt;
            if (sp[4] <= 0 || sp[0] < arenaX || sp[0] > arenaX + arenaW) {
                sparks.remove(i);
            } else if (sp[1] > mainD.sim.floorY) {
                sp[1] = mainD.sim.floorY;
                sp[3] = 0;
                sp[2] *= 0.7;
            }
        }
        rings.removeIf(r -> t - (long) r[2] > 450);
        for (int i = columns.size() - 1; i >= 0; i--) {
            double[] c = columns.get(i);
            if (t >= (long) c[2]) {
                columns.remove(i);
                burst(c[0], c[1], c[3], true);
                if (RANDOM.nextInt(3) == 0) {
                    play(SoundEvents.GENERIC_EXPLODE, 0.9F + RANDOM.nextFloat() * 0.4F);
                }
            }
        }
        focus(nearestDummy(mx, my));
        recent.removeIf(e -> t - e[0] > 5000);
        floats.removeIf(f -> t - f.born() > 900);

        for (int i = tabFirst(); i < tabLast(); i++) {
            int rel = i - tabFirst();
            int sx = colX + (rel % 5) * 22;
            int sy = boxY + 20 + (rel / 5) * 22;
            boolean on = i == selected;
            g.fill(sx, sy, sx + 20, sy + 20, on ? 0xFF5B8DD6 : 0xFF3A3A3A);
            g.fill(sx + 1, sy + 1, sx + 19, sy + 19, on ? 0xFF1E2F4A : 0xFF1A1A1A);
            g.item(stackFor(WEAPONS[i]), sx + 2, sy + 2);
        }
        int hover = slotAt(mouseX, mouseY);
        if (hover >= 0) {
            g.setTooltipForNextFrame(this.font, stackFor(WEAPONS[hover]), mouseX, mouseY);
        }
        g.text(this.font, "Skin: " + this.font.plainSubstrByWidth(DummySkin.label, 80), colX, boxY + 146, 0xFFAAAAAA);
        String status = this.font.plainSubstrByWidth(DummySkin.status, 92);
        g.text(this.font, status, arenaX + arenaW - this.font.width(status) - 5, arenaY + arenaH - 11, 0xFF777777);

        // everything below stays inside the black box
        g.enableScissor(arenaX + 1, arenaY + 1, arenaX + arenaW - 1, arenaY + arenaH - 1);
        // blood stains on the floor
        for (Dummy d : dummies) {
            for (double[] stain : d.sim.stains) {
                int sx = (int) stain[0];
                g.fill(sx, (int) d.sim.floorY - 1, sx + (int) stain[1], (int) d.sim.floorY + 2, 0xFF7A0C0C);
            }
        }
        drawObjects(g, t);
        beams.removeIf(b -> t - (long) b[2] > 350);
        for (double[] b : beams) {
            double age = (t - (long) b[2]) / 350.0;
            int a = (int) (255 * (1 - age));
            int bx = (int) b[0], by = (int) b[1];
            int half = (int) (4 + 10 * (1 - age));
            g.fill(bx - half, arenaY, bx + half, by, ((a / 3) << 24) | 0x88CCFF);
            g.fill(bx - 2, arenaY, bx + 2, by, (a << 24) | 0xFFFFFF);
            int r = (int) (10 + 26 * age);
            g.fill(bx - r, by - r / 2, bx + r, by + r / 2, ((a / 2) << 24) | 0xFFFFFF);
        }

        for (double[] r : rings) {
            double age = (t - (long) r[2]) / 450.0;
            double radius = (16 + r[3] * 16) * Math.sqrt(age);
            int a = (int) (230 * (1 - age));
            for (int i = 0; i < 36; i++) {
                double ang = i * Math.PI * 2 / 36;
                int px = (int) (r[0] + Math.cos(ang) * radius), py = (int) (r[1] + Math.sin(ang) * radius * 0.6);
                g.fill(px, py, px + 3, py + 3, (a << 24) | 0xFFE6B0);
            }
        }

        // arrows in flight or stuck
        for (Dummy d : dummies) {
            for (Sim.Arrow a : d.sim.arrows) {
                double[] p = d.sim.arrowPos(a);
                enter(g, p[0], p[1], d.sim.arrowAngle(a));
                g.fill(-14, -1, 0, 1, a.crossbow ? 0xFF7A5A33 : 0xFFB08850);
                g.fill(0, -2, 3, 2, 0xFFCCCCCC);
                g.fill(-14, -2, -10, 2, 0xFFEEEEEE);
                leave(g);
            }
        }

        // the dummies
        for (Dummy d : dummies) {
            drawDummy(g, d, t);
            if (d.sim.totem) {
                Sim.Part head = d.sim.parts[Sim.HEAD];
                enter(g, head.cx() + head.w * 0.5 + 12, head.cy(), 0);
                g.pose().scale(1.3F, 1.3F);
                g.item(new ItemStack(Items.TOTEM_OF_UNDYING), -8, -8);
                leave(g);
            }
            for (Sim.Fx f : d.sim.fx) {
                int a = (int) Math.max(0, Math.min(255, f.life * 400));
                g.fill((int) f.x, (int) f.y, (int) f.x + f.size, (int) f.y + f.size, (a << 24) | (f.color & 0xFFFFFF));
            }
        }
        double[] gp = grabD != null ? grabD.sim.grabPoint() : null;
        if (gp != null) {
            int steps = 12;
            for (int i = 0; i <= steps; i++) {
                int px = (int) (gp[0] + (mx - gp[0]) * i / steps), py = (int) (gp[1] + (my - gp[1]) * i / steps);
                g.fill(px, py, px + 2, py + 2, 0xFFFFD27F);
            }
        }
        if (inArena(mx, my)) {
            if (w.kind() == Kind.BOW && bowDrawStart >= 0) {
                aimGuide(g, 700 + 900 * Math.min(1.0, (t - bowDrawStart) / 1000.0));
            } else if (w.kind() == Kind.CROSSBOW && loaded) {
                aimGuide(g, 1700);
            }
            drawHeld(g, t);
        }

        for (double[] sp : sparks) {
            int a = (int) Math.max(0, Math.min(255, 255 * sp[4] / sp[5] * 1.4));
            g.fill((int) sp[0], (int) sp[1], (int) sp[0] + (int) sp[6], (int) sp[1] + (int) sp[6], (a << 24) | ((int) sp[7] & 0xFFFFFF));
        }

        // text
        int cx = arenaX + arenaW / 2;
        String info = this.font.plainSubstrByWidth(describe(), arenaW - 12);
        g.text(this.font, info, cx - this.font.width(info) / 2, arenaY + 6, 0xFFFFD27F);
        String hint = this.font.plainSubstrByWidth(hint(), arenaW - 12);
        g.text(this.font, hint, cx - this.font.width(hint) / 2, arenaY + 18, 0xFF888888);
        double dps = 0;
        for (double[] e : recent) {
            dps += e[1];
        }
        dps /= 5.0;
        String[] lines = {
            "Last: " + fmt(last) + (lastNote.isEmpty() ? "" : " " + lastNote),
            "Best: " + fmt(best),
            "Total: " + fmt(total),
            "Hits: " + hits,
            "DPS: " + fmt(dps),
            "Cuts: " + cutCount,
            "Parts: " + mainD.sim.attached() + "/" + Sim.PART_COUNT,
        };
        int sy = arenaY + 32;
        for (String line : lines) {
            g.text(this.font, line, arenaX + 8, sy, 0xFFBBBBBB);
            sy += 10;
        }

        int meterY = arenaY + arenaH - 17;
        switch (w.kind()) {
            case GRAB -> meter(g, cx, meterY, 120, sim.grabbing() ? 1 : 0, 0xFF5B8DD6, sim.grabbing() ? "Holding" : "Drag me");
            case MELEE -> {
                if (w.spear() && rightDown) {
                    meter(g, cx, meterY, 120, speed / 1200.0, speed >= 260 ? 0xFFCC5533 : 0xFF666666, "Speed " + (int) speed);
                } else {
                    double s = strength(t);
                    meter(g, cx, meterY, 120, s, s >= 0.9 ? 0xFF3FA13F : 0xFF9A9A2A, "Cooldown " + (int) (s * 100) + "%");
                }
                meter(g, cx, meterY - 13, 120, spin / CRIT_SPIN, spinCrit() ? 0xFFE0A030 : 0xFF555588,
                        spinCrit() ? "Spin - CRIT ready" : "Spin " + fmt(spin) + " / " + fmt(CRIT_SPIN));
            }
            case BOW -> {
                double pull = bowDrawStart < 0 ? 0 : Math.min(1.0, (t - bowDrawStart) / 1000.0);
                meter(g, cx, meterY, 120, pull, pull >= 1.0 ? 0xFF3FA13F : 0xFF9A9A2A, bowDrawStart < 0 ? "Hold right click" : "Draw " + (int) (pull * 100) + "%");
            }
            case CROSSBOW -> {
                double load = loaded ? 1.0 : Math.min(1.0, (t - loadStart) / 1250.0);
                meter(g, cx, meterY, 120, load, loaded ? 0xFF3FA13F : 0xFF9A9A2A, loaded ? "Loaded - right click" : "Loading " + (int) (load * 100) + "%");
            }
            case PLACE -> meter(g, cx, meterY, 120, objs.size() / 10.0, 0xFF9A6A2A, "Placed " + objs.size() + "/10");
            case IGNITE -> meter(g, cx, meterY, 120, sim.burning() ? 1 : 0, 0xFFE06A10, sim.burning() ? "Burning" : "Ready");
            case HEAL -> meter(g, cx, meterY, 120, sim.attached() / (double) Sim.PART_COUNT, 0xFFD94F7F, "Parts " + sim.attached() + "/" + Sim.PART_COUNT);
            case TOTEM -> meter(g, cx, meterY, 120, sim.totem ? 1 : 0, 0xFFC9A227, sim.totem ? "Totem active" : "No totem");
            case CANNON -> {
                double s = strength(t);
                meter(g, cx, meterY, 120, s, s >= 1.0 ? 0xFF3FA13F : 0xFF9A9A2A, s >= 1.0 ? "Ready" : "Recharging " + (int) (s * 100) + "%");
            }
        }
        if (w.mace()) {
            double down = Math.max(0, vy);
            double lvl = smashLevel(down);
            meter(g, cx, meterY - 26, 120, lvl, lvl > 0.6 ? 0xFFCC5533 : 0xFF666666, "Smash +" + fmt(smashBonus(down)) + " (click at peak)");
        }

        for (Floating f : floats) {
            long age = t - f.born();
            int alpha = (int) (255 * (1.0 - age / 900.0));
            if (alpha < 8) {
                continue;
            }
            int y = (int) (f.y() - 8 - age * 0.045);
            g.text(this.font, f.text(), (int) f.x() + f.dx() - this.font.width(f.text()) / 2, y, (alpha << 24) | f.color());
        }
        g.disableScissor();
    }
}
