/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.extra.mixin.MinecraftUserAccessor;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;

/** Swaps the game's logged-in session. Takes effect the next time you join a server. */
final class Sessions {
    private Sessions() {}

    static void apply(String name, String uuid, String accessToken) {
        Minecraft mc = Minecraft.getInstance();
        User user = new User(name, UUID.fromString(uuid), accessToken, Optional.empty(), Optional.empty());
        ((MinecraftUserAccessor) (Object) mc).bagel$setUser(user);
    }
}
