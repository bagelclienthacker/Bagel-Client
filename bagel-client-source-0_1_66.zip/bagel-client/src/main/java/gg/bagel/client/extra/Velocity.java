/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Anti knockback: scales (or removes) the velocity the server gives you. */
public final class Velocity extends Module {
    public static final String NAME = "Velocity";
    private static Vec3 beforeExplosion;

    public Velocity() {
        super(NAME, "Reduce or cancel knockback", Category.COMBAT);
        setting("horizontal", 0);
        setting("vertical", 0);
        setting("explosions", Boolean.TRUE);
    }

    private static Velocity active() {
        Module m = BagelClient.MODULES.byName(NAME);
        return m instanceof Velocity v && v.enabled() && !VanillaMode.active() ? v : null;
    }

    private double horizontal() {
        return Math.max(0, Math.min(200, intSetting("horizontal", 0))) / 100.0D;
    }

    private double vertical() {
        return Math.max(0, Math.min(200, intSetting("vertical", 0))) / 100.0D;
    }

    /** Velocity packet for us. Returns true when it was handled here and vanilla should skip it. */
    public static boolean handle(LocalPlayer player, Vec3 motion) {
        Velocity v = active();
        if (v == null) {
            return false;
        }
        double h = v.horizontal();
        double y = v.vertical();
        if (h >= 1.0D && y >= 1.0D) {
            return false;
        }
        if (h > 0.0D || y > 0.0D) {
            player.lerpMotion(new Vec3(motion.x * h, motion.y * y, motion.z * h));
        }
        return true;
    }

    public static void explosionBefore(LocalPlayer player) {
        beforeExplosion = player == null ? null : player.getDeltaMovement();
    }

    public static void explosionAfter(LocalPlayer player) {
        Vec3 before = beforeExplosion;
        beforeExplosion = null;
        Velocity v = active();
        if (v == null || before == null || player == null || !v.booleanSetting("explosions", true)) {
            return;
        }
        Vec3 after = player.getDeltaMovement();
        Vec3 delta = after.subtract(before);
        player.setDeltaMovement(before.add(delta.x * v.horizontal(), delta.y * v.vertical(), delta.z * v.horizontal()));
    }
}
