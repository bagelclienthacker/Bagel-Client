/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.util.CameraRig;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While Freecam flies the camera, the real player gets no movement input and keeps its crouch state. */
@Mixin(KeyboardInput.class)
public abstract class FreecamInputMixin {
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void bagel$freecamInput(CallbackInfo ci) {
        if (CameraRig.mode() == CameraRig.Mode.FREECAM) {
            ClientInput input = (ClientInput) (Object) this;
            input.keyPresses = new Input(false, false, false, false, false, CameraRig.crouched(), false);
        }
    }
}
