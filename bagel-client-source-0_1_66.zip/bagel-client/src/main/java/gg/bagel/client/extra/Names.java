/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.util.Set;
import java.util.TreeSet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;

/** Player-name helpers shared by the commands and pickers. */
final class Names {
    private Names() {}

    /** Profile name looked up reflectively so it works with either accessor spelling. */
    static String profile(PlayerInfo info) {
        Object profile = info.getProfile();
        for (String method : new String[] {"name", "getName"}) {
            try {
                Object value = profile.getClass().getMethod(method).invoke(profile);
                if (value instanceof String s && !s.isEmpty()) {
                    return s;
                }
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return null;
    }

    static Set<String> online() {
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        Minecraft mc = Minecraft.getInstance();
        try {
            ClientPacketListener connection = mc.getConnection();
            if (connection != null) {
                for (PlayerInfo info : connection.getOnlinePlayers()) {
                    String name = profile(info);
                    if (name != null) {
                        names.add(name);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            if (mc.level != null) {
                mc.level.players().forEach(p -> names.add(p.getName().getString()));
            }
        } catch (Throwable ignored) {
        }
        return names;
    }

    static PlayerInfo info(String name) {
        try {
            ClientPacketListener connection = Minecraft.getInstance().getConnection();
            if (connection != null) {
                for (PlayerInfo info : connection.getOnlinePlayers()) {
                    if (name.equalsIgnoreCase(profile(info))) {
                        return info;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}
