/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Anchor Aura (Overworld and End, where respawn anchors explode): places an anchor next to a target, charges it with
 * glowstone and detonates it, judging every step by the damage it would deal to the target and to you.
 *
 * <p>Order each tick: detonate a charged anchor that is worth it, otherwise charge an empty one, otherwise place a new one.
 * When the blast would hurt you too much a glowstone block is put between you and the anchor first ("glowstone_shield").
 * "force_engage" places an anchor even when nothing meets the damage minimum (the self-damage limit still applies).
 *
 * <p>The AUTISM Lite jar ships this module's settings but not its algorithm, so the logic here is Bagel's own.
 */
public final class AnchorAura extends Module {
    public static final String NAME = "Anchor Aura";

    private final SwapState swap = new SwapState();
    private final Map<BlockPos, Long> recentUse = new HashMap<>();
    private long nextStepAt;
    private int shields;

    public AnchorAura() {
        super(NAME, "Places, charges and detonates respawn anchors by calculated damage", Category.COMBAT);
        setting("place", Boolean.TRUE);
        setting("charge", Boolean.TRUE);
        setting("detonate", Boolean.TRUE);
        setting("target_range", 8.0D);
        setting("targeting", "Distance");
        setting("entities", "minecraft:player");
        setting("hurt_time", 10);
        setting("switch_back_delay", 20);
        setting("only_above", Boolean.FALSE);
        setting("force_engage", Boolean.TRUE);
        setting("min_target_damage", 5.0D);
        setting("max_self_damage", 4.0D);
        setting("efficient", Boolean.TRUE);
        setting("terrain", Boolean.TRUE);
        setting("glowstone_shield", Boolean.TRUE);
        setting("step_delay", 75);
        setting("step_jitter", 15);
        setting("place_range", 4.5D);
        setting("rotation", "silent");
    }

    @Override
    protected void onDisable(Minecraft mc) {
        swap.restore(mc, mc.player);
        recentUse.clear();
        shields = 0;
        SilentAim.release();
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (!CombatUtil.canRun(mc, player) || !CombatUtil.overworldOrEnd(mc)) {
            return;
        }
        long now = System.currentTimeMillis();
        recentUse.values().removeIf(t -> now - t > 400L);

        boolean acted = false;
        if (!player.isUsingItem() && !player.isShiftKeyDown() && !mc.gameMode.isDestroying() && !SilentAim.blocked(player) && now >= nextStepAt) {
            LivingEntity target = CombatUtil.pickTarget(this, mc, player, Math.max(1.0D, doubleSetting("target_range", 8.0D)), Math.max(0, intSetting("hurt_time", 10)));
            if (target != null) {
                acted = step(mc, player, target, now);
            }
        }
        swap.tick(mc, player, acted, intSetting("switch_back_delay", 20));
    }

    // ------------------------------------------------------------------ rules

    private boolean terrain() {
        return booleanSetting("terrain", true);
    }

    private double reach(LocalPlayer player) {
        double cap = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE) + 0.5D;
        return Math.min(Math.max(2.0D, doubleSetting("place_range", 4.5D)), cap);
    }

    private boolean affordable(float self, LocalPlayer player) {
        return self <= Math.max(0.0D, doubleSetting("max_self_damage", 4.0D)) && self < Explosions.health(player) - 1.0F;
    }

    private boolean worth(float damage, float self, LivingEntity target) {
        double min = Math.max(0.0D, doubleSetting("min_target_damage", 5.0D));
        boolean kill = damage >= Explosions.health(target);
        if (!kill && damage < min) {
            return false;
        }
        return kill || !booleanSetting("efficient", true) || damage > self;
    }

    private void pause(long now) {
        nextStepAt = now + CombatUtil.delayMs(intSetting("step_delay", 75), intSetting("step_jitter", 15));
    }

    // ------------------------------------------------------------------ main decision

    private boolean step(Minecraft mc, LocalPlayer player, LivingEntity target, long now) {
        ClientLevel level = mc.level;
        double reach = reach(player);
        boolean offhandFuel = player.getOffhandItem().is(Items.GLOWSTONE);
        int needCharge = offhandFuel ? 4 : 1; // glowstone in the off hand would be used instead of the detonation click

        BlockPos detonate = null;
        BlockPos charge = null;
        BlockPos shieldFor = null;
        double bestDetonate = -Double.MAX_VALUE;
        BlockPos base = target.blockPosition();
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                for (int dy = -4; dy <= 4; dy++) {
                    BlockPos pos = base.offset(dx, dy, dz);
                    BlockState state = level.getBlockState(pos);
                    if (!state.is(Blocks.RESPAWN_ANCHOR) || recentUse.containsKey(pos)) {
                        continue;
                    }
                    Vec3 center = Vec3.atCenterOf(pos);
                    if (player.getEyePosition().distanceTo(center) > reach) {
                        continue;
                    }
                    int charges = state.getValue(BlockStateProperties.RESPAWN_ANCHOR_CHARGES);
                    float damage = Explosions.damage(level, center, Explosions.ANCHOR, target, terrain(), pos);
                    float self = Explosions.damage(level, center, Explosions.ANCHOR, player, terrain(), pos);
                    boolean usable = worth(damage, self, target) || (booleanSetting("force_engage", true) && damage > 0.5F);
                    if (!usable) {
                        continue;
                    }
                    if (charges >= needCharge && booleanSetting("detonate", true)) {
                        if (affordable(self, player)) {
                            if (damage - self > bestDetonate) {
                                bestDetonate = damage - self;
                                detonate = pos;
                            }
                        } else if (booleanSetting("glowstone_shield", true)) {
                            shieldFor = pos;
                        }
                    } else if (charges < needCharge && booleanSetting("charge", true) && charge == null && affordable(self, player)) {
                        charge = pos;
                    }
                }
            }
        }
        if (detonate != null) {
            return useOnAnchor(mc, player, detonate, true, now);
        }
        if (shieldFor != null && shields < 3 && shield(mc, player, shieldFor, now)) {
            return true;
        }
        if (charge != null) {
            return useOnAnchor(mc, player, charge, false, now);
        }
        if (booleanSetting("place", true) && noAnchorPending(level, base, now)) {
            return placeAnchor(mc, player, target, now);
        }
        return false;
    }

    /** An anchor we just placed may not have reached the client yet. */
    private boolean noAnchorPending(ClientLevel level, BlockPos base, long now) {
        for (Long time : recentUse.values()) {
            if (now - time < 400L) {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ charge / detonate

    private boolean useOnAnchor(Minecraft mc, LocalPlayer player, BlockPos pos, boolean detonate, long now) {
        InteractionHand hand = InteractionHand.MAIN_HAND;
        int slot = -1;
        if (detonate) {
            // a main-hand item that is not glowstone, so the click explodes the anchor instead of charging it
            int selected = player.getInventory().getSelectedSlot();
            if (player.getInventory().getItem(selected).is(Items.GLOWSTONE)) {
                slot = Hotbar.find(player, s -> !s.is(Items.GLOWSTONE));
                if (slot < 0) {
                    return false;
                }
            }
        } else if (player.getOffhandItem().is(Items.GLOWSTONE)) {
            hand = InteractionHand.OFF_HAND;
        } else {
            slot = Hotbar.find(player, s -> s.is(Items.GLOWSTONE));
            if (slot < 0) {
                return false;
            }
        }
        Vec3 eyes = player.getEyePosition();
        Vec3 center = Vec3.atCenterOf(pos);
        Direction face = Direction.getApproximateNearest(eyes.x - center.x, eyes.y - center.y, eyes.z - center.z);
        Vec3 click = center.add(face.getStepX() * 0.5D, face.getStepY() * 0.5D, face.getStepZ() * 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            return true;
        }
        if (slot >= 0) {
            swap.take(player, slot);
        }
        InteractionResult result = mc.gameMode.useItemOn(player, hand, new BlockHitResult(click, face, pos, false));
        if (result.consumesAction()) {
            player.swing(hand);
        }
        recentUse.put(pos, now);
        pause(now);
        return true;
    }

    // ------------------------------------------------------------------ place anchor

    private boolean placeAnchor(Minecraft mc, LocalPlayer player, LivingEntity target, long now) {
        InteractionHand hand = InteractionHand.MAIN_HAND;
        int slot = -1;
        if (player.getOffhandItem().is(Items.RESPAWN_ANCHOR)) {
            hand = InteractionHand.OFF_HAND;
        } else {
            slot = Hotbar.find(player, s -> s.is(Items.RESPAWN_ANCHOR));
            if (slot < 0) {
                return false;
            }
        }
        ClientLevel level = mc.level;
        double reach = reach(player);
        Vec3 eyes = player.getEyePosition();
        BlockPos base = target.blockPosition();
        boolean force = booleanSetting("force_engage", true);
        boolean above = booleanSetting("only_above", false);

        BlockPos best = null;
        Direction bestFace = null;
        double bestScore = -Double.MAX_VALUE;
        BlockPos fallback = null;
        Direction fallbackFace = null;
        double fallbackScore = -Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    BlockPos pos = base.offset(dx, dy, dz);
                    if (above && pos.getY() <= base.getY()) {
                        continue;
                    }
                    if (!level.getBlockState(pos).canBeReplaced() || recentUse.containsKey(pos)) {
                        continue;
                    }
                    Vec3 center = Vec3.atCenterOf(pos);
                    if (eyes.distanceTo(center) > reach || Explosions.upperBound(center, Explosions.ANCHOR, target) < 1.0F) {
                        continue;
                    }
                    if (!level.getEntities((Entity) null, new AABB(pos), e -> !e.isSpectator()).isEmpty()) {
                        continue;
                    }
                    Direction face = clickFace(level, pos);
                    if (face == null) {
                        continue;
                    }
                    float damage = Explosions.damage(level, center, Explosions.ANCHOR, target, terrain(), pos);
                    float self = Explosions.damage(level, center, Explosions.ANCHOR, player, terrain(), pos);
                    if (!affordable(self, player)) {
                        continue;
                    }
                    double score = damage - self * 1.5D;
                    if (worth(damage, self, target)) {
                        if (score > bestScore) {
                            bestScore = score;
                            best = pos;
                            bestFace = face;
                        }
                    } else if (force && damage > 0.5F && score > fallbackScore) {
                        fallbackScore = score;
                        fallback = pos;
                        fallbackFace = face;
                    }
                }
            }
        }
        if (best == null) {
            best = fallback;
            bestFace = fallbackFace;
        }
        if (best == null) {
            return false;
        }
        BlockPos support = best.relative(bestFace);
        Direction clicked = bestFace.getOpposite();
        Vec3 click = Vec3.atCenterOf(support).add(clicked.getStepX() * 0.5D, clicked.getStepY() * 0.5D, clicked.getStepZ() * 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            return true;
        }
        if (slot >= 0) {
            swap.take(player, slot);
        }
        InteractionResult result = mc.gameMode.useItemOn(player, hand, new BlockHitResult(click, clicked, support, false));
        if (result.consumesAction()) {
            player.swing(hand);
        }
        recentUse.put(best, now);
        shields = 0;
        pause(now);
        return true;
    }

    // ------------------------------------------------------------------ glowstone shield

    /** Puts a glowstone block on the line between the anchor and you so the blast is blocked. */
    private boolean shield(Minecraft mc, LocalPlayer player, BlockPos anchor, long now) {
        int slot = Hotbar.find(player, s -> s.is(Items.GLOWSTONE));
        InteractionHand hand = InteractionHand.MAIN_HAND;
        if (player.getOffhandItem().is(Items.GLOWSTONE)) {
            hand = InteractionHand.OFF_HAND;
            slot = -1;
        } else if (slot < 0) {
            return false;
        }
        ClientLevel level = mc.level;
        Vec3 from = Vec3.atCenterOf(anchor);
        Vec3 body = player.getBoundingBox().getCenter();
        Vec3 dir = body.subtract(from);
        double length = dir.length();
        if (length < 1.0D) {
            return false;
        }
        dir = dir.scale(1.0D / length);
        double reach = reach(player);
        BlockPos chosen = null;
        Direction chosenFace = null;
        for (double t = 1.0D; t < Math.min(length - 0.4D, 3.0D); t += 0.5D) {
            BlockPos cell = BlockPos.containing(from.add(dir.scale(t)));
            if (cell.equals(anchor) || !level.getBlockState(cell).canBeReplaced() || new AABB(cell).intersects(player.getBoundingBox())) {
                continue;
            }
            if (!level.getEntities((Entity) null, new AABB(cell), e -> !e.isSpectator()).isEmpty()) {
                continue;
            }
            if (player.getEyePosition().distanceTo(Vec3.atCenterOf(cell)) > reach) {
                continue;
            }
            Direction face = clickFace(level, cell);
            if (face != null) {
                chosen = cell;
                chosenFace = face;
                break;
            }
        }
        if (chosen == null) {
            return false;
        }
        BlockPos support = chosen.relative(chosenFace);
        Direction clicked = chosenFace.getOpposite();
        Vec3 click = Vec3.atCenterOf(support).add(clicked.getStepX() * 0.5D, clicked.getStepY() * 0.5D, clicked.getStepZ() * 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            return true;
        }
        if (slot >= 0) {
            swap.take(player, slot);
        }
        InteractionResult result = mc.gameMode.useItemOn(player, hand, new BlockHitResult(click, clicked, support, false));
        if (result.consumesAction()) {
            player.swing(hand);
        }
        shields++;
        recentUse.put(chosen, now);
        pause(now);
        return true;
    }

    /** A direction from {@code pos} to a solid neighbor we can click on. */
    private static Direction clickFace(ClientLevel level, BlockPos pos) {
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction direction : order) {
            BlockPos neighbor = pos.relative(direction);
            BlockState state = level.getBlockState(neighbor);
            if (!state.isAir() && !state.canBeReplaced() && state.isFaceSturdy(level, neighbor, direction.getOpposite())) {
                return direction;
            }
        }
        return null;
    }
}
