/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import java.util.Locale;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.CrafterBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.TrappedChestBlock;

/** Per-type storage colours (same set and defaults as AUTISM Client's Storage ESP). */
public final class StorageColors {
    public static final String MODULE = "Storage ESP";
    public static final String[][] DEFAULTS = {
        {"trapped_chest_color", "#FF2020"},
        {"chest_color", "#FFA000"},
        {"ender_chest_color", "#7800FF"},
        {"barrel_color", "#FFA000"},
        {"shulker_color", "#B766FF"},
        {"hopper_color", "#7C8AFF"},
        {"dispenser_color", "#B04848"},
        {"furnace_color", "#CCB266"},
        {"crafter_color", "#D8AE6B"},
        {"other_color", "#8C8C8C"},
    };

    private StorageColors() {}

    /** Settings string of every colour, used to refresh the scan cache when one changes. */
    public static String signature() {
        Module m = BagelClient.MODULES.byName(MODULE);
        if (m == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (String[] d : DEFAULTS) {
            sb.append(m.stringSetting(d[0], d[1])).append(';');
        }
        return sb.toString();
    }

    /** Returns {colour, label} for a storage block. */
    public static Object[] describe(Block block) {
        String key;
        String label;
        if (block instanceof TrappedChestBlock) {
            key = "trapped_chest_color";
            label = "Trapped Chest";
        } else if (block instanceof ChestBlock) {
            key = "chest_color";
            label = "Chest";
        } else if (block instanceof EnderChestBlock) {
            key = "ender_chest_color";
            label = "Ender Chest";
        } else if (block instanceof BarrelBlock) {
            key = "barrel_color";
            label = "Barrel";
        } else if (block instanceof ShulkerBoxBlock) {
            key = "shulker_color";
            label = "Shulker Box";
        } else if (block instanceof HopperBlock) {
            key = "hopper_color";
            label = "Hopper";
        } else if (block instanceof DispenserBlock) {
            key = "dispenser_color";
            label = BuiltInRegistries.BLOCK.getKey(block).getPath().equals("dropper") ? "Dropper" : "Dispenser";
        } else if (block instanceof AbstractFurnaceBlock) {
            key = "furnace_color";
            label = pretty(BuiltInRegistries.BLOCK.getKey(block).getPath());
        } else if (block instanceof CrafterBlock) {
            key = "crafter_color";
            label = "Crafter";
        } else {
            key = "other_color";
            label = pretty(BuiltInRegistries.BLOCK.getKey(block).getPath());
        }
        String fallback = "#8C8C8C";
        for (String[] d : DEFAULTS) {
            if (d[0].equals(key)) {
                fallback = d[1];
            }
        }
        Module m = BagelClient.MODULES.byName(MODULE);
        String text = m == null ? fallback : m.stringSetting(key, fallback);
        return new Object[] {parse(text, parse(fallback, 0xFF8C8C8C)), label};
    }

    private static final java.util.Map<String, Integer> NAMED = java.util.Map.ofEntries(
            java.util.Map.entry("red", 0xFF4040), java.util.Map.entry("green", 0x40D040), java.util.Map.entry("lime", 0x80FF40),
            java.util.Map.entry("blue", 0x4070FF), java.util.Map.entry("yellow", 0xFFE040), java.util.Map.entry("orange", 0xFF9020),
            java.util.Map.entry("purple", 0xA050FF), java.util.Map.entry("pink", 0xFF80C0), java.util.Map.entry("cyan", 0x40E0E0),
            java.util.Map.entry("white", 0xFFFFFF), java.util.Map.entry("black", 0x101010), java.util.Map.entry("gray", 0x8C8C8C),
            java.util.Map.entry("grey", 0x8C8C8C), java.util.Map.entry("magenta", 0xFF40FF), java.util.Map.entry("gold", 0xFFC800),
            java.util.Map.entry("brown", 0x9A6A3A));

    /** Accepts color names (red, cyan...), RRGGBB, #RRGGBB, 0xRRGGBB and #AARRGGBB. The result is always opaque. */
    public static int parse(String text, int fallback) {
        if (text == null) {
            return fallback;
        }
        String t = text.trim();
        Integer named = NAMED.get(t.toLowerCase(Locale.ROOT));
        if (named != null) {
            return 0xFF000000 | named;
        }
        if (t.startsWith("#")) {
            t = t.substring(1);
        } else if (t.toLowerCase(Locale.ROOT).startsWith("0x")) {
            t = t.substring(2);
        }
        try {
            if (t.length() == 6 || t.length() == 8) {
                long v = Long.parseLong(t, 16);
                return 0xFF000000 | (int) (v & 0xFFFFFF);
            }
        } catch (NumberFormatException ignored) {
            // fall through
        }
        return fallback;
    }

    private static String pretty(String path) {
        StringBuilder out = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) {
                continue;
            }
            if (out.length() > 0) {
                out.append(' ');
            }
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }
}
