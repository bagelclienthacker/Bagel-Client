/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.extra.SilentAim;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Silent aim for the combat modules (Kill Aura, Crystal/Anchor/Bed/Mace Aura): the yaw and pitch that go into the normal movement packet are replaced while Kill Aura is
 * aiming. No extra packet is sent, and the camera (the real rotation) never changes.
 */
@Mixin(LocalPlayer.class)
public abstract class KillAuraRotationMixin {
    @Redirect(method = "sendPosition", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getYRot()F"), require = 0)
    private float bagel$sendYaw(LocalPlayer self) {
        return SilentAim.outgoingYaw(self, self.getYRot());
    }

    @Redirect(method = "sendPosition", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getXRot()F"), require = 0)
    private float bagel$sendPitch(LocalPlayer self) {
        return SilentAim.outgoingPitch(self, self.getXRot());
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getYRot()F"), require = 0)
    private float bagel$ridingYaw(LocalPlayer self) {
        return SilentAim.outgoingYaw(self, self.getYRot());
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getXRot()F"), require = 0)
    private float bagel$ridingPitch(LocalPlayer self) {
        return SilentAim.outgoingPitch(self, self.getXRot());
    }
}
