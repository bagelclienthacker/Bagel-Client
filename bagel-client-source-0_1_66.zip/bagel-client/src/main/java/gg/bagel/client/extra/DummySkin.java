/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.blaze3d.platform.NativeImage;
import gg.bagel.client.BagelClient;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

/** Which skin the Hit the Dummy target wears: your own, an online player's, any Mojang account, or a saved file. */
public final class DummySkin {
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10)).build();
    private static final Map<String, Loaded> CACHE = new HashMap<>();
    private static int counter;
    private static int fileIndex = -1;

    public static volatile Identifier texture;
    public static volatile boolean slim;
    public static volatile String label = "";
    public static volatile String status = "";

    private record Loaded(Identifier id, boolean slim) {}

    private DummySkin() {}

    private static void use(Identifier id, boolean slimArms, String name) {
        texture = id;
        slim = slimArms;
        label = name;
    }

    private static void usePlayerSkin(PlayerSkin skin, String name) {
        use(skin.body().texturePath(), skin.model() == PlayerModelType.SLIM, name);
    }

    public static void ensure() {
        if (texture != null) {
            return;
        }
        useSteve();
    }

    /** The default skin: Steve (also saved as Steve.png in the saved skins). */
    public static void useSteve() {
        SkinStore.ensureSteve();
        use(Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png"), false, "Steve");
        status = "Steve";
    }

    public static void useMine() {
        Minecraft mc = Minecraft.getInstance();
        String mine = mc.getUser().getName();
        try {
            if (mc.player != null) {
                usePlayerSkin(mc.player.getSkin(), mine);
                status = "Using your skin";
                return;
            }
        } catch (Throwable ignored) {
        }
        lookup(mine);
    }

    public static void useNextFile() {
        List<String> files = SkinStore.files();
        if (files.isEmpty()) {
            status = "No saved skins in config/bagel/skins";
            return;
        }
        fileIndex = (fileIndex + 1) % files.size();
        String file = files.get(fileIndex);
        Identifier id = SkinStore.textureOf(file);
        if (id == null) {
            status = file + " must be a 64x64 PNG";
            return;
        }
        use(id, SkinStore.slimOf(file), file.replaceAll("(?i)\\.png$", ""));
        status = "Using saved skin " + file;
    }

    /** Online players are read from the tab list; anyone else is looked up on Mojang's servers (needs internet). */
    public static void lookup(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (!NAME.matcher(name).matches()) {
            status = "Type a Minecraft username";
            return;
        }
        PlayerInfo info = Names.info(name);
        if (info != null) {
            usePlayerSkin(info.getSkin(), name);
            status = name + " (online)";
            return;
        }
        Loaded cached = CACHE.get(name.toLowerCase(Locale.ROOT));
        if (cached != null) {
            use(cached.id(), cached.slim(), name);
            status = name;
            return;
        }
        status = "Looking up " + name + "...";
        Thread t = new Thread(() -> fetch(name), "Bagel-Dummy-Skin");
        t.setDaemon(true);
        t.start();
    }

    private static String get(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).GET().build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IllegalStateException("HTTP " + response.statusCode());
        }
        return response.body();
    }

    private static String find(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        if (!m.find()) {
            throw new IllegalStateException("missing field");
        }
        return m.group(1);
    }

    private static void fetch(String name) {
        try {
            String accountJson = get("https://api.mojang.com/users/profiles/minecraft/" + name);
            String id = find(accountJson, "\"id\"\\s*:\\s*\"([0-9a-fA-F]+)\"");
            String exact = find(accountJson, "\"name\"\\s*:\\s*\"([^\"]+)\"");
            String profileJson = get("https://sessionserver.mojang.com/session/minecraft/profile/" + id);
            String encoded = find(profileJson, "\"value\"\\s*:\\s*\"([^\"]+)\"");
            String textures = new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8);
            String skinUrl = find(textures, "\"SKIN\"\\s*:\\s*\\{[^}]*?\"url\"\\s*:\\s*\"([^\"]+)\"");
            boolean slimArms = Pattern.compile("\"model\"\\s*:\\s*\"slim\"").matcher(textures).find();
            HttpRequest request = HttpRequest.newBuilder(URI.create(skinUrl))
                    .timeout(Duration.ofSeconds(20)).GET().build();
            byte[] bytes = HTTP.send(request, HttpResponse.BodyHandlers.ofByteArray()).body();
            if (bytes.length < 64 || bytes.length > 200_000) {
                throw new IllegalStateException("unexpected skin size");
            }
            NativeImage image = SkinStore.toModern(NativeImage.read(bytes));
            Minecraft mc = Minecraft.getInstance();
            mc.execute(() -> {
                Identifier tex = Identifier.fromNamespaceAndPath("bagel", "dummy/" + exact.toLowerCase(Locale.ROOT) + "_" + (counter++));
                mc.getTextureManager().register(tex, new DynamicTexture(() -> "Bagel dummy " + exact, image));
                CACHE.put(name.toLowerCase(Locale.ROOT), new Loaded(tex, slimArms));
                use(tex, slimArms, exact);
                status = exact + (slimArms ? " (slim arms)" : "");
            });
        } catch (Throwable e) {
            BagelClient.LOGGER.warn("Hit the Dummy could not load skin " + name, e);
            status = "Could not load " + name + " (offline, or no such player)";
        }
    }
}
