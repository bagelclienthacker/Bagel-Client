/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

/** A Component flattened to text plus one resolved Style per character, so text can be swapped and rebuilt. */
final class Flat {
    final StringBuilder text = new StringBuilder();
    final List<Style> styles = new ArrayList<>();

    static Flat of(Component component) {
        Flat flat = new Flat();
        component.visit((style, string) -> {
            for (int i = 0; i < string.length(); i++) {
                flat.text.append(string.charAt(i));
                flat.styles.add(style);
            }
            return Optional.empty();
        }, Style.EMPTY);
        return flat;
    }

    void replace(int start, int end, String with, Style style) {
        text.replace(start, end, with);
        styles.subList(start, end).clear();
        styles.addAll(start, Collections.nCopies(with.length(), style));
    }

    MutableComponent build() {
        MutableComponent root = Component.empty();
        int n = text.length();
        int i = 0;
        while (i < n) {
            Style style = styles.get(i);
            int j = i + 1;
            while (j < n && styles.get(j).equals(style)) {
                j++;
            }
            root.append(Component.literal(text.substring(i, j)).withStyle(style));
            i = j;
        }
        return root;
    }
}
