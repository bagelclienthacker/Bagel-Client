/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Built-in account switcher for offline accounts. */
public final class AccountScreen extends Screen {
    private static final int PER_PAGE = 7;
    private final Screen parent;
    private EditBox nameField;
    private int page;
    private volatile String status = "";

    public AccountScreen(Screen parent) {
        super(Component.literal("Accounts"));
        this.parent = parent;
    }

    /** Opens the switcher (used by the Bagel main menu). */
    public static void open(net.minecraft.client.Minecraft mc, Screen parent) {
        mc.setScreenAndShow(new AccountScreen(parent));
    }

    private static List<AccountStore.Account> offlineAccounts() {
        List<AccountStore.Account> out = new ArrayList<>();
        for (AccountStore.Account account : AccountStore.all()) {
            if (!account.microsoft()) {
                out.add(account);
            }
        }
        return out;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 150;
        nameField = new EditBox(this.font, left, 40, 190, 20, Component.literal("Offline name"));
        nameField.setMaxLength(16);
        nameField.setHint(Component.literal("Offline username"));
        this.addRenderableWidget(nameField);
        this.addRenderableWidget(Button.builder(Component.literal("Add offline"), b -> {
            String name = nameField.getValue().trim();
            if (name.matches("[A-Za-z0-9_]{3,16}")) {
                AccountStore.add(AccountStore.offline(name));
                status = "Added offline account " + name;
                this.rebuildWidgets();
            } else {
                status = "Names use 3-16 letters, numbers or _";
            }
        }).bounds(left + 195, 40, 105, 20).build());

        List<AccountStore.Account> accounts = offlineAccounts();
        String current = this.minecraft.getUser().getName();
        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            if (index >= accounts.size()) {
                break;
            }
            AccountStore.Account account = accounts.get(index);
            boolean active = account.name().equals(current);
            String label = (active ? "> " : "") + account.name() + "  [Offline]";
            this.addRenderableWidget(Button.builder(Component.literal(label), b -> use(account))
                    .bounds(left, 72 + i * 22, 270, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                AccountStore.remove(account);
                this.rebuildWidgets();
            }).bounds(left + 275, 72 + i * 22, 25, 20).build());
        }
        int paging = 72 + PER_PAGE * 22;
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page = Math.max(0, page - 1);
            this.rebuildWidgets();
        }).bounds(left, paging, 40, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            if ((page + 1) * PER_PAGE < offlineAccounts().size()) {
                page++;
            }
            this.rebuildWidgets();
        }).bounds(left + 45, paging, 40, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(left + 200, paging, 100, 20).build());
    }

    private void use(AccountStore.Account account) {
        Sessions.apply(account.name(), account.uuid(), "0");
        status = "Now playing as " + account.name() + " (applies when you join a server)";
        this.rebuildWidgets();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        int cx = this.width / 2;
        graphics.text(this.font, "Accounts", cx - this.font.width("Accounts") / 2, 14, -1);
        String playing = "Playing as: " + this.minecraft.getUser().getName();
        graphics.text(this.font, playing, cx - this.font.width(playing) / 2, 26, 0xFFFFB347);
        String s = status;
        if (!s.isEmpty()) {
            graphics.text(this.font, s, cx - this.font.width(s) / 2, this.height - 30, -1);
        }
        String note = "Offline accounts only work on offline-mode servers";
        graphics.text(this.font, note, cx - this.font.width(note) / 2, this.height - 18, 0xFFAAAAAA);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }
}
