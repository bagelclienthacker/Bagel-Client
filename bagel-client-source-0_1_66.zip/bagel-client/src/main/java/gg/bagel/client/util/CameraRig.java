/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.util;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Freecam and Free Look.
 * Freecam: a detached camera entity flies around while the real player stays put.
 * Free Look: the player keeps facing the same way, only the view turns.
 * Mouse movement is redirected here by EntityTurnMixin, and Free Look is applied in
 * CameraFreeLookMixin.
 */
public final class CameraRig {
    public enum Mode {
        NONE,
        FREECAM,
        FREE_LOOK
    }

    static final class DetachedCamera extends Entity {
        DetachedCamera(Level level, EntityType<?> type) {
            super(type, level);
        }

        @Override
        protected void defineSynchedData(SynchedEntityData.Builder builder) {}

        @Override
        protected void readAdditionalSaveData(ValueInput input) {}

        @Override
        protected void addAdditionalSaveData(ValueOutput output) {}

        @Override
        public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
            return false;
        }
    }

    private static DetachedCamera camera;
    private static Vec3 playerAnchor;
    private static boolean crouchedAtStart;
    private static Mode mode = Mode.NONE;
    private static boolean sawKeyDown;
    private static float lookYaw;
    private static float lookPitch;

    private CameraRig() {}

    public static Mode mode() {
        return mode;
    }

    /** True when the player was crouching as freecam started: it stays crouched for the whole flight. */
    public static boolean crouched() {
        return crouchedAtStart;
    }

    /** Scroll wheel while freecam is active changes the speed (like AUTISM). Returns true when used. */
    public static boolean scroll(double amount) {
        Minecraft mc = Minecraft.getInstance();
        if (mode != Mode.FREECAM || amount == 0.0D || mc.gui.screen() != null) {
            return false;
        }
        Module freecam = BagelClient.MODULES.byName("Freecam");
        if (freecam == null) {
            return false;
        }
        double speed = freecam.doubleSetting("speed", 0.5D);
        speed *= amount > 0.0D ? 1.2D : 1.0D / 1.2D;
        speed = Math.max(0.05D, Math.min(10.0D, Math.round(speed * 100.0D) / 100.0D));
        freecam.setSetting("speed", speed);
        mc.gui.hud.setOverlayMessage(Component.literal("Freecam speed " + speed), false);
        return true;
    }

    public static boolean freeLookActive() {
        return mode == Mode.FREE_LOOK;
    }

    public static float lookYaw() {
        return lookYaw;
    }

    public static float lookPitch() {
        return lookPitch;
    }

    /** Called by EntityTurnMixin. Returns true when the mouse movement was used by the camera. */
    public static boolean turn(double dx, double dy) {
        float yawDelta = (float) dx * 0.15F;
        float pitchDelta = (float) dy * 0.15F;
        if (mode == Mode.FREE_LOOK) {
            lookYaw += yawDelta;
            lookPitch = Mth.clamp(lookPitch + pitchDelta, -90.0F, 90.0F);
            return true;
        }
        if (mode == Mode.FREECAM && camera != null) {
            float pitch = Mth.clamp(camera.getXRot() + pitchDelta, -90.0F, 90.0F);
            float yaw = camera.getYRot() + yawDelta;
            camera.setXRot(pitch);
            camera.setYRot(yaw);
            camera.xRotO = pitch;
            camera.yRotO = yaw;
            return true;
        }
        return false;
    }

    public static void disable(Minecraft mc) {
        stop(mc);
    }

    public static void tick(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            stop(mc);
            return;
        }
        Module freecam = BagelClient.MODULES.byName("Freecam");
        if (freecam != null) {
            freecam.settings().remove("hold"); // old hold-to-use setting, now hold_key (off = plain toggle)
        }
        Module freeLook = BagelClient.MODULES.byName("Free Look");
        Mode wanted = freecam != null && freecam.enabled()
                ? Mode.FREECAM
                : freeLook != null && freeLook.enabled() ? Mode.FREE_LOOK : Mode.NONE;
        if (wanted != mode) {
            stop(mc);
            if (wanted != Mode.NONE) {
                start(mc, wanted);
            }
        }
        if (mode == Mode.FREECAM && freecam != null && freecam.booleanSetting("hold_key", false) && freecam.keyCode() > 0) {
            // hold-to-use like AUTISM: freecam lasts exactly as long as the bind is held down
            boolean down = InputConstants.isKeyDown(mc.getWindow(), freecam.keyCode());
            if (down) {
                sawKeyDown = true;
            } else if (sawKeyDown) {
                freecam.setEnabled(false, mc);
                stop(mc);
                return;
            }
        }
        if (mode == Mode.FREECAM && camera != null && freecam != null) {
            double speed = Math.max(0.05D, Math.min(10.0D, freecam.doubleSetting("speed", 0.5D)));
            camera.setOldPosAndRot();
            double yaw = Math.toRadians(camera.getYRot());
            double pitch = Math.toRadians(camera.getXRot());
            Vec3 forward = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
            Vec3 right = new Vec3(Math.cos(yaw), 0.0D, Math.sin(yaw));
            Vec3 move = Vec3.ZERO;
            if (mc.options.keyUp.isDown()) {
                move = move.add(forward);
            }
            if (mc.options.keyDown.isDown()) {
                move = move.subtract(forward);
            }
            if (mc.options.keyRight.isDown()) {
                move = move.subtract(right);
            }
            if (mc.options.keyLeft.isDown()) {
                move = move.add(right);
            }
            if (mc.options.keyJump.isDown()) {
                move = move.add(0.0D, 1.0D, 0.0D);
            }
            if (mc.options.keyShift.isDown()) {
                move = move.add(0.0D, -1.0D, 0.0D);
            }
            if (move.lengthSqr() > 0.0D) {
                camera.setPos(camera.position().add(move.normalize().scale(speed)));
            }
            // the real player stays frozen where it was (and keeps its crouch)
            player.input.keyPresses = new Input(false, false, false, false, false, crouchedAtStart, false);
            player.setPos(playerAnchor.x, playerAnchor.y, playerAnchor.z);
            player.setDeltaMovement(Vec3.ZERO);
        }
    }

    private static void start(Minecraft mc, Mode wanted) {
        LocalPlayer player = mc.player;
        sawKeyDown = false;
        playerAnchor = player.position();
        crouchedAtStart = player.isCrouching();
        lookYaw = player.getYRot();
        lookPitch = player.getXRot();
        if (wanted == Mode.FREECAM) {
            Entity view = mc.getCameraEntity();
            camera = new DetachedCamera(player.level(), player.getType());
            camera.setPos(player.getX(), player.getY(), player.getZ());
            camera.setYRot(view == null ? player.getYRot() : view.getYRot());
            camera.setXRot(view == null ? player.getXRot() : view.getXRot());
            camera.setOldPosAndRot();
            mc.setCameraEntity(camera);
        }
        mode = wanted;
    }

    private static void stop(Minecraft mc) {
        if (mode != Mode.NONE && mc.player != null) {
            if (mode == Mode.FREECAM) {
                mc.setCameraEntity(mc.player);
                mc.player.input.keyPresses = new Input(false, false, false, false, false, crouchedAtStart, false);
            }
        }
        camera = null;
        playerAnchor = null;
        crouchedAtStart = false;
        mode = Mode.NONE;
    }
}
