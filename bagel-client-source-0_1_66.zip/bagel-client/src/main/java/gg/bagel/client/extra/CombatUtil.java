/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import java.util.Locale;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Target picking, timing and small checks shared by the rewritten combat modules. */
final class CombatUtil {
    static final Random RANDOM = new Random();

    private CombatUtil() {}

    static boolean canRun(Minecraft mc, LocalPlayer player) {
        return player != null && mc.level != null && mc.gameMode != null && player.isAlive()
                && !player.isSpectator() && mc.gui.screen() == null;
    }

    static boolean validTarget(Module module, LocalPlayer player, Entity entity, double range, int maxHurt) {
        if (!(entity instanceof LivingEntity living) || entity == player || entity.isRemoved() || !living.isAlive()) {
            return false;
        }
        if (living.hurtTime > maxHurt || living.isSpectator() || living.getHealth() <= 0.0F) {
            return false;
        }
        if (entity instanceof Player other && other.isSleeping()) {
            return false;
        }
        if (!KillAura.matches(module, entity)) {
            return false;
        }
        return player.distanceTo(entity) <= range;
    }

    /** Best target by the module's "targeting" setting: Distance (default), HP or FOV. */
    static LivingEntity pickTarget(Module module, Minecraft mc, LocalPlayer player, double range, int maxHurt) {
        String mode = module.stringSetting("targeting", "Distance").trim().toLowerCase(Locale.ROOT);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!validTarget(module, player, entity, range, maxHurt)) {
                continue;
            }
            LivingEntity living = (LivingEntity) entity;
            double score;
            switch (mode) {
                case "hp":
                    score = Explosions.health(living);
                    break;
                case "fov":
                    score = angleToLook(player, living.getBoundingBox().getCenter());
                    break;
                default:
                    score = player.distanceToSqr(living);
                    break;
            }
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    static double angleToLook(LocalPlayer player, Vec3 point) {
        float[] want = KillAura.anglesTo(player.getEyePosition(), point);
        float dy = Mth.wrapDegrees(want[0] - player.getYRot());
        float dp = want[1] - player.getXRot();
        return Math.sqrt(dy * dy + dp * dp);
    }

    /** Distance from the eyes to the closest point of the entity's hitbox. */
    static double reachTo(LocalPlayer player, Entity entity) {
        Vec3 eyes = player.getEyePosition();
        AABB box = entity.getBoundingBox();
        double dx = Math.max(Math.max(box.minX - eyes.x, 0.0D), eyes.x - box.maxX);
        double dy = Math.max(Math.max(box.minY - eyes.y, 0.0D), eyes.y - box.maxY);
        double dz = Math.max(Math.max(box.minZ - eyes.z, 0.0D), eyes.z - box.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** A random delay: {@code base} milliseconds plus up to {@code jitter} more. */
    static long delayMs(int base, int jitter) {
        return Math.max(0, base) + (jitter > 0 ? RANDOM.nextInt(jitter + 1) : 0);
    }

    static boolean overworldOrEnd(Minecraft mc) {
        String path = mc.level.dimension().identifier().getPath();
        return !path.equals("the_nether");
    }

    static String dimension(Minecraft mc) {
        return mc.level.dimension().identifier().getPath();
    }

    /**
     * Aim gate for an action that wants the server to know the rotation. "none" never turns, "fast" turns and acts in the
     * same tick (the packet with the rotation follows), "silent" turns and acts once the server has received it.
     */
    static boolean aimed(Minecraft mc, LocalPlayer player, String mode, Vec3 point) {
        String m = mode == null ? "silent" : mode.trim().toLowerCase(Locale.ROOT);
        if (m.equals("none")) {
            return true;
        }
        if (SilentAim.blocked(player)) {
            return false;
        }
        float[] want = KillAura.anglesTo(player.getEyePosition(), point);
        SilentAim.aim(mc, player, want[0], want[1]);
        if (m.equals("fast")) {
            return true;
        }
        return SilentAim.ready(player, SilentAim.wantedYaw(), SilentAim.wantedPitch(), 4.0F);
    }
}
