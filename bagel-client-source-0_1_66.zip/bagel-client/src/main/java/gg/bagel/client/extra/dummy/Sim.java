/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.dummy;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A tiny 2D ragdoll sandbox (no Minecraft types, so it can be tested headless). Every body part is a rigid box made of
 * four verlet points; parts are held together by pin joints that can be cut. Nothing here is graphic: cut parts just
 * separate and a puff of straw flies out, like a stuffed training dummy.
 */
public final class Sim {
    public static final int HEAD = 0, CHEST = 1, HIPS = 2, ARM_R_UP = 3, ARM_R_LO = 4, ARM_L_UP = 5, ARM_L_LO = 6,
            LEG_R_UP = 7, LEG_R_LO = 8, LEG_L_UP = 9, LEG_L_LO = 10;
    public static final int PART_COUNT = 11;

    private static final double DT = 1.0 / 120.0;
    private static final int ITERATIONS = 12;
    private static final double GRAVITY = 1100.0;
    private static final Random RANDOM = new Random();

    public static final class P {
        public double x, y, px, py;
    }

    public static final class Part {
        public final int kind;
        public final double w, h;
        public final P[] c = {new P(), new P(), new P(), new P()}; // TL, TR, BR, BL
        public double flash;

        Part(int kind, double cx, double cy, double w, double h) {
            this.kind = kind;
            this.w = w;
            this.h = h;
            double[][] o = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            for (int i = 0; i < 4; i++) {
                c[i].x = c[i].px = cx + o[i][0] * w / 2;
                c[i].y = c[i].py = cy + o[i][1] * h / 2;
            }
        }

        public double cx() {
            return (c[0].x + c[1].x + c[2].x + c[3].x) / 4;
        }

        public double cy() {
            return (c[0].y + c[1].y + c[2].y + c[3].y) / 4;
        }

        /** Rotation of the part: angle of its top edge. */
        public double angle() {
            return Math.atan2(c[1].y - c[0].y, c[1].x - c[0].x);
        }

        /** World position of a point given in box fractions (0..1 across, 0..1 down). */
        public double[] point(double ax, double ay) {
            double ux = c[1].x - c[0].x, uy = c[1].y - c[0].y, vx = c[3].x - c[0].x, vy = c[3].y - c[0].y;
            return new double[] {c[0].x + ux * ax + vx * ay, c[0].y + uy * ax + vy * ay};
        }

        /** Box fractions of a world point (inverse of point()). */
        public double[] local(double x, double y) {
            double ux = c[1].x - c[0].x, uy = c[1].y - c[0].y, vx = c[3].x - c[0].x, vy = c[3].y - c[0].y;
            double det = ux * vy - uy * vx;
            if (Math.abs(det) < 1e-9) {
                return new double[] {0.5, 0.5};
            }
            double dx = x - c[0].x, dy = y - c[0].y;
            return new double[] {(dx * vy - dy * vx) / det, (ux * dy - uy * dx) / det};
        }

        public boolean contains(double x, double y, double pad) {
            double[] l = local(x, y);
            double px = pad / Math.max(1, w), py = pad / Math.max(1, h);
            return l[0] >= -px && l[0] <= 1 + px && l[1] >= -py && l[1] <= 1 + py;
        }

        void rotateAbout(double ax, double ay, double phi) {
            double cos = Math.cos(phi), sin = Math.sin(phi);
            for (P p : c) {
                double dx = p.x - ax, dy = p.y - ay;
                p.x = ax + dx * cos - dy * sin;
                p.y = ay + dx * sin + dy * cos;
            }
        }
    }

    public static final class Joint {
        public final String name;
        public final Part a, b;
        final double ax, ay, bx, by, limit;
        public boolean alive = true;

        Joint(String name, Part a, double ax, double ay, Part b, double bx, double by, double limitDegrees) {
            this.name = name;
            this.a = a;
            this.ax = ax;
            this.ay = ay;
            this.b = b;
            this.bx = bx;
            this.by = by;
            this.limit = Math.toRadians(limitDegrees);
        }

        public double[] world() {
            double[] pa = a.point(ax, ay);
            double[] pb = b.point(bx, by);
            return new double[] {(pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2};
        }
    }

    public static final class Fx {
        public double x, y, vx, vy, life;
        public double grav = 0.5;
        public int size, color;
        public boolean blood;
    }

    public static final class Wound {
        final Part part;
        final double ax, ay;
        double time;

        Wound(Part part, double ax, double ay, double time) {
            this.part = part;
            this.ax = ax;
            this.ay = ay;
            this.time = time;
        }
    }

    public static final class Arrow {
        public double x, y, vx, vy;
        public boolean crossbow, stuck, fromFighter;
        public Part part;
        public double la, lb, relAngle;
        public double damage;
        public double age;
    }

    public final Part[] parts = new Part[PART_COUNT];
    public final List<Joint> joints = new ArrayList<>();
    public final List<Fx> fx = new ArrayList<>();
    public final List<double[]> stains = new ArrayList<>();
    private final List<Wound> wounds = new ArrayList<>();
    public boolean blood = true;
    /** A totem of undying keeps the dummy from being cut or blown apart. */
    public boolean totem;
    private int totemPops;
    private int settle;
    private double burn;
    private double fireAcc;
    private int fireTicks;
    public final List<Arrow> arrows = new ArrayList<>();
    public final double k;
    public double floorY, left, right, top;
    public boolean stand;
    public double tone;
    private boolean knocked;
    /** Fighters keep their muscle tone when hit, so they wobble instead of going limp. */
    public boolean keepTone;
    /** Walking speed in px/s (positive = right); the whole body is carried along. */
    public double drive;
    private double stepClock;
    private boolean legAlt;
    private boolean slimBody;
    private double acc;

    private Part grabPart;
    private double grabAx, grabAy, grabX, grabY;

    public Sim(double cx, double floorY, double k, boolean slim, double left, double right, double top, boolean stand) {
        this.k = k;
        this.slimBody = slim;
        this.floorY = floorY;
        this.left = left;
        this.right = right;
        this.top = top;
        this.stand = stand;
        this.tone = stand ? 1.0 : 0.0;
        double aw = (slim ? 3 : 4) * k;
        double torso = 8 * k, six = 6 * k;
        double y = floorY;
        parts[LEG_R_LO] = new Part(LEG_R_LO, cx - 2 * k, y - 3 * k, 4 * k, six);
        parts[LEG_L_LO] = new Part(LEG_L_LO, cx + 2 * k, y - 3 * k, 4 * k, six);
        parts[LEG_R_UP] = new Part(LEG_R_UP, cx - 2 * k, y - 9 * k, 4 * k, six);
        parts[LEG_L_UP] = new Part(LEG_L_UP, cx + 2 * k, y - 9 * k, 4 * k, six);
        parts[HIPS] = new Part(HIPS, cx, y - 15 * k, torso, six);
        parts[CHEST] = new Part(CHEST, cx, y - 21 * k, torso, six);
        parts[HEAD] = new Part(HEAD, cx, y - 28 * k, 8 * k, 8 * k);
        parts[ARM_R_UP] = new Part(ARM_R_UP, cx - 4 * k - aw / 2, y - 21 * k, aw, six);
        parts[ARM_R_LO] = new Part(ARM_R_LO, cx - 4 * k - aw / 2, y - 15 * k, aw, six);
        parts[ARM_L_UP] = new Part(ARM_L_UP, cx + 4 * k + aw / 2, y - 21 * k, aw, six);
        parts[ARM_L_LO] = new Part(ARM_L_LO, cx + 4 * k + aw / 2, y - 15 * k, aw, six);
        joints.add(new Joint("neck", parts[HEAD], 0.5, 1, parts[CHEST], 0.5, 0, 55));
        joints.add(new Joint("waist", parts[CHEST], 0.5, 1, parts[HIPS], 0.5, 0, 60));
        joints.add(new Joint("right shoulder", parts[CHEST], 0, 0.14, parts[ARM_R_UP], 1, 0.14, 170));
        joints.add(new Joint("right elbow", parts[ARM_R_UP], 0.5, 1, parts[ARM_R_LO], 0.5, 0, 110));
        joints.add(new Joint("left shoulder", parts[CHEST], 1, 0.14, parts[ARM_L_UP], 0, 0.14, 170));
        joints.add(new Joint("left elbow", parts[ARM_L_UP], 0.5, 1, parts[ARM_L_LO], 0.5, 0, 110));
        joints.add(new Joint("right hip", parts[HIPS], 0.25, 1, parts[LEG_R_UP], 0.5, 0, 100));
        joints.add(new Joint("right knee", parts[LEG_R_UP], 0.5, 1, parts[LEG_R_LO], 0.5, 0, 100));
        joints.add(new Joint("left hip", parts[HIPS], 0.75, 1, parts[LEG_L_UP], 0.5, 0, 100));
        joints.add(new Joint("left knee", parts[LEG_L_UP], 0.5, 1, parts[LEG_L_LO], 0.5, 0, 100));
    }

    public int attached() {
        // number of parts still connected to the chest
        boolean[] seen = new boolean[PART_COUNT];
        List<Part> stack = new ArrayList<>();
        stack.add(parts[CHEST]);
        seen[CHEST] = true;
        int n = 0;
        while (!stack.isEmpty()) {
            Part p = stack.remove(stack.size() - 1);
            n++;
            for (Joint j : joints) {
                if (!j.alive) {
                    continue;
                }
                Part other = j.a == p ? j.b : j.b == p ? j.a : null;
                if (other != null && !seen[other.kind]) {
                    seen[other.kind] = true;
                    stack.add(other);
                }
            }
        }
        return n;
    }

    // ---- stepping ----

    public void advance(double seconds) {
        acc += Math.min(seconds, 0.05);
        while (acc >= DT) {
            acc -= DT;
            step();
        }
    }

    public void knock() {
        if (keepTone) {
            return;
        }
        knocked = true;
    }

    private void step() {
        if (knocked && tone > 0.0) {
            tone = Math.max(0.0, tone - DT * 4.0);
        }
        for (Part part : parts) {
            part.flash = Math.max(0, part.flash - DT);
            for (P p : part.c) {
                double vx = (p.x - p.px) * 0.9995, vy = (p.y - p.py) * 0.9995;
                p.px = p.x;
                p.py = p.y;
                p.x += vx;
                p.y += vy + GRAVITY * DT * DT;
            }
        }
        for (int it = 0; it < ITERATIONS; it++) {
            for (Part part : parts) {
                rigid(part);
            }
            for (Joint j : joints) {
                if (j.alive) {
                    pin(j);
                }
            }
            double s = tone * 0.35;
            for (Joint j : joints) {
                if (j.alive) {
                    angular(j, s);
                }
            }
            if (grabPart != null) {
                double[] p = grabPart.point(grabAx, grabAy);
                pull(grabPart, grabAx, grabAy, p[0], p[1], grabX, grabY, 0.35);
            }
            if ((it & 1) == 0) {
                collide();
            }
            bounds();
        }
        if (burn > 0) {
            burn -= DT;
            fireAcc += DT;
            if (fireAcc >= 1.0) {
                fireAcc -= 1.0;
                fireTicks++;
            }
            if (RANDOM.nextInt(3) == 0) {
                Part p = parts[RANDOM.nextInt(PART_COUNT)];
                double[] at = p.point(RANDOM.nextDouble(), RANDOM.nextDouble());
                fire(at[0], at[1], 1);
            }
        }
        for (int i = wounds.size() - 1; i >= 0; i--) {
            Wound w = wounds.get(i);
            w.time -= DT;
            if (w.time <= 0) {
                wounds.remove(i);
            } else if (blood && RANDOM.nextInt(2) == 0) {
                double[] at = w.part.point(w.ax, w.ay);
                splatter(at[0], at[1], RANDOM.nextDouble() * 2 - 1, -0.5 + RANDOM.nextDouble() * 0.5, 1);
            }
        }
        for (int i = fx.size() - 1; i >= 0; i--) {
            Fx f = fx.get(i);
            f.life -= DT;
            f.vy += GRAVITY * f.grav * DT;
            f.x += f.vx * DT;
            f.y += f.vy * DT;
            if (f.x < left || f.x > right) {
                if (f.blood) {
                    fx.remove(i);
                    continue;
                }
                f.x = Math.max(left, Math.min(right, f.x));
                f.vx = -f.vx * 0.5;
            }
            if (f.y < top) {
                f.y = top;
                f.vy = Math.abs(f.vy) * 0.3;
            }
            if (f.y >= floorY && f.grav > 0) {
                if (f.blood) {
                    if (stains.size() < 160 && f.x > left && f.x < right - 4) {
                        stains.add(new double[] {f.x, 2 + RANDOM.nextInt(3)});
                    }
                    fx.remove(i);
                    continue;
                }
                f.y = floorY;
                f.vy = 0;
                f.vx *= 0.8;
            }
            if (f.life <= 0) {
                fx.remove(i);
            }
        }
        for (Arrow a : arrows) {
            a.age += DT;
        }
        arrows.removeIf(a -> a.age > 20);
        if (drive != 0 && tone > 0.3) {
            double d = drive * DT;
            for (Part p : parts) {
                for (P c : p.c) {
                    c.x += d;
                    c.px += d;
                }
            }
            stepClock += DT;
            if (stepClock > 0.24) {
                stepClock = 0;
                legAlt = !legAlt;
                Part leg = parts[legAlt ? LEG_R_LO : LEG_L_LO];
                for (P c : leg.c) {
                    c.y -= 0.35 * k;
                }
            }
        }
        if (settle > 0) {
            // after a heal the pieces may overlap: let them push apart without gaining speed
            settle--;
            for (Part p : parts) {
                for (P c : p.c) {
                    c.px = c.x;
                    c.py = c.y;
                }
            }
        }
    }

    private static void dist(P a, P b, double rest) {
        double dx = b.x - a.x, dy = b.y - a.y;
        double d = Math.sqrt(dx * dx + dy * dy);
        if (d < 1e-9) {
            return;
        }
        double diff = (d - rest) / d * 0.5;
        a.x += dx * diff;
        a.y += dy * diff;
        b.x -= dx * diff;
        b.y -= dy * diff;
    }

    private static void rigid(Part p) {
        dist(p.c[0], p.c[1], p.w);
        dist(p.c[3], p.c[2], p.w);
        dist(p.c[0], p.c[3], p.h);
        dist(p.c[1], p.c[2], p.h);
        double diag = Math.sqrt(p.w * p.w + p.h * p.h);
        dist(p.c[0], p.c[2], diag);
        dist(p.c[1], p.c[3], diag);
    }

    private static double[] weights(double ax, double ay) {
        return new double[] {(1 - ax) * (1 - ay), ax * (1 - ay), ax * ay, (1 - ax) * ay};
    }

    /** Moves point (ax,ay) of part a toward world point (tx,ty), spreading the move over its four corners. */
    private static void pull(Part a, double ax, double ay, double wx, double wy, double tx, double ty, double stiff) {
        double[] w = weights(ax, ay);
        double sum = 0;
        for (double v : w) {
            sum += v * v;
        }
        double dx = (tx - wx) * stiff, dy = (ty - wy) * stiff;
        for (int i = 0; i < 4; i++) {
            a.c[i].x += w[i] * dx / sum;
            a.c[i].y += w[i] * dy / sum;
        }
    }

    private static void pin(Joint j) {
        double[] wa = weights(j.ax, j.ay), wb = weights(j.bx, j.by);
        double[] pa = j.a.point(j.ax, j.ay), pb = j.b.point(j.bx, j.by);
        double dx = pb[0] - pa[0], dy = pb[1] - pa[1];
        double sum = 0;
        for (int i = 0; i < 4; i++) {
            sum += wa[i] * wa[i] + wb[i] * wb[i];
        }
        for (int i = 0; i < 4; i++) {
            j.a.c[i].x += wa[i] * dx / sum;
            j.a.c[i].y += wa[i] * dy / sum;
            j.b.c[i].x -= wb[i] * dx / sum;
            j.b.c[i].y -= wb[i] * dy / sum;
        }
    }

    private static double wrap(double a) {
        while (a > Math.PI) {
            a -= 2 * Math.PI;
        }
        while (a < -Math.PI) {
            a += 2 * Math.PI;
        }
        return a;
    }

    private static void angular(Joint j, double stiff) {
        double rel = wrap(j.b.angle() - j.a.angle());
        double fix = rel * stiff;
        double over = Math.abs(rel) > j.limit ? rel - Math.signum(rel) * j.limit : 0;
        double total = fix + over * 0.6;
        if (Math.abs(total) < 1e-9) {
            return;
        }
        j.b.rotateAbout(j.b.cx(), j.b.cy(), -total * 0.5);
        j.a.rotateAbout(j.a.cx(), j.a.cy(), total * 0.5);
    }

    private boolean joined(Part a, Part b) {
        for (Joint j : joints) {
            if (j.alive && ((j.a == a && j.b == b) || (j.a == b && j.b == a))) {
                return true;
            }
        }
        return false;
    }

    private static double[][] circles(Part p) {
        double r = Math.min(p.w, p.h) * 0.5 * 0.92;
        if (p.h > p.w * 1.2) {
            double[] a = p.point(0.5, 0.3), b = p.point(0.5, 0.7);
            return new double[][] {{a[0], a[1], r}, {b[0], b[1], r}};
        }
        return new double[][] {{p.cx(), p.cy(), r}};
    }

    /** Keeps parts that are not joined from sinking into each other (round approximations). */
    private void collide() {
        for (int i = 0; i < PART_COUNT; i++) {
            for (int j = i + 1; j < PART_COUNT; j++) {
                Part a = parts[i], b = parts[j];
                if (joined(a, b)) {
                    continue;
                }
                if (Math.hypot(a.cx() - b.cx(), a.cy() - b.cy()) > a.h + b.h) {
                    continue;
                }
                double nx = 0, ny = 0;
                int hits = 0;
                double depth = 0;
                for (double[] ca : circles(a)) {
                    for (double[] cb : circles(b)) {
                        double dx = cb[0] - ca[0], dy = cb[1] - ca[1];
                        double d = Math.hypot(dx, dy), min = ca[2] + cb[2];
                        if (d < min && d > 1e-6) {
                            nx += dx / d;
                            ny += dy / d;
                            depth = Math.max(depth, min - d);
                            hits++;
                        }
                    }
                }
                if (hits == 0) {
                    continue;
                }
                double len = Math.hypot(nx, ny);
                if (len < 1e-9) {
                    continue;
                }
                nx /= len;
                ny /= len;
                double push = depth * 0.5 * 0.6;
                for (P p : a.c) {
                    p.x -= nx * push;
                    p.y -= ny * push;
                }
                for (P p : b.c) {
                    p.x += nx * push;
                    p.y += ny * push;
                }
            }
        }
    }

    private void bounds() {
        for (Part part : parts) {
            for (P p : part.c) {
                if (p.y > floorY) {
                    p.y = floorY;
                    p.px += (p.x - p.px) * 0.5;
                    p.py = p.y;
                }
                if (p.y < top) {
                    p.y = top;
                    p.py = p.y;
                }
                if (p.x < left) {
                    p.x = left;
                    p.px = p.x + (p.x - p.px) * -0.3;
                }
                if (p.x > right) {
                    p.x = right;
                    p.px = p.x + (p.x - p.px) * -0.3;
                }
            }
        }
    }

    // ---- interaction ----

    /** Topmost part under a point (later parts in the array are drawn on top). */
    public Part hit(double x, double y, double pad) {
        Part found = null;
        double best = Double.MAX_VALUE;
        for (Part p : parts) {
            if (p.contains(x, y, pad)) {
                double d = Math.hypot(p.cx() - x, p.cy() - y);
                if (d < best) {
                    best = d;
                    found = p;
                }
            }
        }
        return found;
    }

    public Joint nearestJoint(double x, double y, double maxDist) {
        Joint best = null;
        double bd = maxDist;
        for (Joint j : joints) {
            if (!j.alive) {
                continue;
            }
            double[] w = j.world();
            double d = Math.hypot(w[0] - x, w[1] - y);
            if (d <= bd) {
                bd = d;
                best = j;
            }
        }
        return best;
    }

    /** Gives a part a push (px/s) at a point; hitting off-centre spins it. */
    public void kick(Part part, double wx, double wy, double vx, double vy) {
        double[] l = part.local(wx, wy);
        double[] w = weights(Math.max(0, Math.min(1, l[0])), Math.max(0, Math.min(1, l[1])));
        for (int i = 0; i < 4; i++) {
            double f = 0.35 + 1.3 * w[i];
            part.c[i].px = part.c[i].x - vx * f * DT;
            part.c[i].py = part.c[i].y - vy * f * DT;
        }
        part.flash = 0.3;
        knock();
    }

    public boolean sever(Joint j, double vx, double vy) {
        if (!j.alive) {
            return false;
        }
        if (totem) {
            double[] at = j.world();
            totemPops++;
            sparkle(at[0], at[1], 14, new int[] {0xFFFFD84A, 0xFFE8B820, 0xFF7CE06A, 0xFFFFF0A0});
            return false;
        }
        j.alive = false;
        double[] w = j.world();
        puff(w[0], w[1], blood ? 30 : 16, 260);
        if (blood) {
            wounds.add(new Wound(j.a, j.ax, j.ay, 1.4));
            wounds.add(new Wound(j.b, j.bx, j.by, 1.4));
        }
        kick(j.b, w[0], w[1], vx, vy);
        kick(j.a, w[0], w[1], -vx * 0.4, -vy * 0.4);
        knock();
        return true;
    }

    /** How far the chest is tipped over, in radians (0 = upright). */
    public double tilt() {
        double a = parts[CHEST].angle();
        while (a > Math.PI) {
            a -= 2 * Math.PI;
        }
        while (a < -Math.PI) {
            a += 2 * Math.PI;
        }
        return Math.abs(a);
    }

    /** Puts the dummy back on its feet at the given x (cut-off parts stay where they are). */
    public void standUp(double cx) {
        Sim t = new Sim(cx, floorY, k, slimBody, left, right, top, true);
        for (Part p : component(parts[CHEST], null)) {
            Part q = t.parts[p.kind];
            for (int i = 0; i < 4; i++) {
                p.c[i].x = q.c[i].x;
                p.c[i].y = q.c[i].y;
                p.c[i].px = p.c[i].x;
                p.c[i].py = p.c[i].y;
            }
        }
        tone = 1.0;
        knocked = false;
        settle = 25;
    }

    /** Number of cuts the totem has blocked since the last call. */
    public int takeTotemPops() {
        int n = totemPops;
        totemPops = 0;
        return n;
    }

    /** A burst of coloured sparks that drift upward. */
    public void sparkle(double x, double y, int n, int[] colors) {
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.x = x + (RANDOM.nextDouble() - 0.5) * 8;
            f.y = y + (RANDOM.nextDouble() - 0.5) * 8;
            double a = RANDOM.nextDouble() * Math.PI * 2;
            double sp = 40 + RANDOM.nextDouble() * 120;
            f.vx = Math.cos(a) * sp;
            f.vy = Math.sin(a) * sp - 30;
            f.life = 0.5 + RANDOM.nextDouble() * 0.6;
            f.size = 2 + RANDOM.nextInt(2);
            f.grav = -0.15;
            f.color = colors[RANDOM.nextInt(colors.length)];
            fx.add(f);
        }
    }

    /**
     * Splash of healing: every cut-off part is put back on its joint (with whatever hangs off it), the fire goes out
     * and the wounds close. Returns how many joints were restored.
     */
    private List<Part> component(Part start, Joint skip) {
        List<Part> comp = new ArrayList<>();
        boolean[] seen = new boolean[PART_COUNT];
        comp.add(start);
        seen[start.kind] = true;
        for (int i = 0; i < comp.size(); i++) {
            Part p = comp.get(i);
            for (Joint o : joints) {
                if (!o.alive || o == skip) {
                    continue;
                }
                Part other = o.a == p ? o.b : o.b == p ? o.a : null;
                if (other != null && !seen[other.kind]) {
                    seen[other.kind] = true;
                    comp.add(other);
                }
            }
        }
        return comp;
    }

    public int mend() {
        int n = 0;
        for (Joint j : joints) {
            if (j.alive) {
                continue;
            }
            List<Part> compB = component(j.b, j);
            boolean bHasChest = false;
            for (Part p : compB) {
                bHasChest |= p == parts[CHEST];
            }
            boolean aHasChest = false;
            List<Part> compA = component(j.a, j);
            for (Part p : compA) {
                aHasChest |= p == parts[CHEST];
            }
            // move the side that does not contain the chest; the chest never gets dragged around
            boolean moveB = !bHasChest;
            if (aHasChest == bHasChest && compA.size() < compB.size()) {
                moveB = false;
            }
            List<Part> comp = moveB ? compB : compA;
            Part mover = moveB ? j.b : j.a, fixed = moveB ? j.a : j.b;
            double mx = moveB ? j.bx : j.ax, my = moveB ? j.by : j.ay;
            double fx = moveB ? j.ax : j.bx, fy = moveB ? j.ay : j.by;
            boolean connected = false;
            for (Part p : comp) {
                connected |= p == fixed;
            }
            if (!connected) {
                double[] pm = mover.point(mx, my);
                double dphi = fixed.angle() - mover.angle();
                for (Part p : comp) {
                    p.rotateAbout(pm[0], pm[1], dphi);
                }
                pm = mover.point(mx, my);
                double[] pf = fixed.point(fx, fy);
                double dx = pf[0] - pm[0], dy = pf[1] - pm[1];
                for (Part p : comp) {
                    for (P c : p.c) {
                        c.x += dx;
                        c.y += dy;
                    }
                }
            }
            j.alive = true;
            n++;
            double[] at = j.world();
            sparkle(at[0], at[1], 10, new int[] {0xFFFF5A8A, 0xFFFF8FB0, 0xFFFFD0DC, 0xFFFFFFFF});
        }
        for (Part p : parts) {
            for (P c : p.c) {
                c.px = c.x;
                c.py = c.y;
            }
        }
        wounds.clear();
        burn = 0;
        settle = 45;
        return n;
    }

    /** A burst of straw (stuffed dummy) or, with blood on, red droplets. */
    public void puff(double x, double y, int n, double speed) {
        int[] straw = {0xFFD9C27A, 0xFFC8B068, 0xFFEFE3B0, 0xFFB89F58};
        int[] red = {0xFFB01414, 0xFF8E0F0F, 0xFFCC2222, 0xFF7A0C0C};
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.x = x;
            f.y = y;
            double a = RANDOM.nextDouble() * Math.PI * 2;
            double s = speed * (0.2 + RANDOM.nextDouble() * 0.8);
            f.vx = Math.cos(a) * s;
            f.vy = Math.sin(a) * s - speed * 0.3;
            f.life = 0.7 + RANDOM.nextDouble() * 0.9;
            f.size = 2 + RANDOM.nextInt(2);
            f.blood = blood;
            f.grav = blood ? 1.0 : 0.5;
            f.color = blood ? red[RANDOM.nextInt(red.length)] : straw[RANDOM.nextInt(straw.length)];
            fx.add(f);
        }
    }

    /** Droplets thrown mostly along (dx, dy); only with blood on. */
    public void splatter(double x, double y, double dx, double dy, int n) {
        if (!blood) {
            return;
        }
        double len = Math.max(1e-6, Math.hypot(dx, dy));
        int[] red = {0xFFB01414, 0xFF8E0F0F, 0xFFCC2222, 0xFF7A0C0C};
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.x = x;
            f.y = y;
            double s = 120 + RANDOM.nextDouble() * 320;
            f.vx = dx / len * s + (RANDOM.nextDouble() - 0.5) * 160;
            f.vy = dy / len * s + (RANDOM.nextDouble() - 0.5) * 160 - 60;
            f.life = 1.2 + RANDOM.nextDouble();
            f.size = 2 + RANDOM.nextInt(2);
            f.blood = true;
            f.grav = 1.0;
            f.color = red[RANDOM.nextInt(red.length)];
            fx.add(f);
        }
    }

    private void fire(double x, double y, int n) {
        int[] colors = {0xFFFFA020, 0xFFFF6A10, 0xFFFFD040, 0xFFE04010};
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.x = x;
            f.y = y;
            f.vx = (RANDOM.nextDouble() - 0.5) * 50;
            f.vy = -40 - RANDOM.nextDouble() * 80;
            f.life = 0.35 + RANDOM.nextDouble() * 0.4;
            f.size = 2 + RANDOM.nextInt(2);
            f.grav = -0.6;
            f.color = colors[RANDOM.nextInt(colors.length)];
            fx.add(f);
        }
    }

    private void smoke(double x, double y, int n, double speed) {
        int[] gray = {0xFF555555, 0xFF333333, 0xFF777777, 0xFFFF8A20};
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.x = x;
            f.y = y;
            double a = RANDOM.nextDouble() * Math.PI * 2;
            double s = speed * (0.2 + RANDOM.nextDouble() * 0.8);
            f.vx = Math.cos(a) * s;
            f.vy = Math.sin(a) * s;
            f.life = 0.5 + RANDOM.nextDouble() * 0.9;
            f.size = 3 + RANDOM.nextInt(3);
            f.grav = -0.2;
            f.color = gray[RANDOM.nextInt(gray.length)];
            fx.add(f);
        }
    }

    /** Sets the dummy on fire for a few seconds. */
    public void ignite(double seconds) {
        burn = Math.max(burn, seconds);
    }

    public void extinguish() {
        burn = 0;
    }

    public boolean burning() {
        return burn > 0;
    }

    /** Whole seconds of burning since the last call (one damage tick each). */
    public int takeFireTicks() {
        int n = fireTicks;
        fireTicks = 0;
        return n;
    }

    public double[] partVelocity(Part p) {
        double vx = 0, vy = 0;
        for (P c : p.c) {
            vx += (c.x - c.px) / DT;
            vy += (c.y - c.py) / DT;
        }
        return new double[] {vx / 4, vy / 4};
    }

    /**
     * An explosion of the given power (vanilla: end crystal 6, TNT 4). Pushes and spins parts, tears off parts that are
     * very close, and returns the vanilla-style damage the dummy takes.
     */
    public double explode(double x, double y, double power) {
        double pxPerM = 17.78 * k;
        double radius = 2 * power;
        double nearest = Double.MAX_VALUE;
        for (Part p : parts) {
            double d = Math.max(0, Math.hypot(p.cx() - x, p.cy() - y) - Math.min(p.w, p.h) / 2) / pxPerM;
            nearest = Math.min(nearest, d);
            double impact = 1 - d / radius;
            if (impact <= 0) {
                continue;
            }
            double dx = p.cx() - x, dy = p.cy() - y - 20;
            double len = Math.max(1e-6, Math.hypot(dx, dy));
            double speed = Math.min(2600, impact * power * 320);
            double ox = p.cx() + (RANDOM.nextDouble() - 0.5) * p.w, oy = p.cy() + (RANDOM.nextDouble() - 0.5) * p.h;
            kick(p, ox, oy, dx / len * speed, dy / len * speed);
        }
        for (Joint j : new ArrayList<>(joints)) {
            if (!j.alive) {
                continue;
            }
            double[] w = j.world();
            double d = Math.hypot(w[0] - x, w[1] - y) / pxPerM;
            if (1 - d / radius > 0.6) {
                double dx = w[0] - x, dy = w[1] - y - 20, len = Math.max(1e-6, Math.hypot(dx, dy));
                sever(j, dx / len * 700, dy / len * 700);
            }
        }
        for (int i = 0; i < 28; i++) {
            fire(x, y, 1);
        }
        smoke(x, y, 34, 520);
        knock();
        double impact = Math.max(0, 1 - nearest / radius);
        return impact <= 0 ? 0 : (impact * impact + impact) / 2 * 7 * radius + 1;
    }

    public void grab(Part part, double wx, double wy) {
        double[] l = part.local(wx, wy);
        grabPart = part;
        grabAx = Math.max(0, Math.min(1, l[0]));
        grabAy = Math.max(0, Math.min(1, l[1]));
        grabX = wx;
        grabY = wy;
        knock();
    }

    public void dragTo(double wx, double wy) {
        grabX = wx;
        grabY = wy;
    }

    public void release() {
        grabPart = null;
    }

    public boolean grabbing() {
        return grabPart != null;
    }

    public double[] grabPoint() {
        return grabPart == null ? null : grabPart.point(grabAx, grabAy);
    }

    // ---- projectiles ----

    public Arrow shoot(double x, double y, double tx, double ty, double speed, double damage, boolean crossbow) {
        Arrow a = new Arrow();
        double dx = tx - x, dy = ty - y, d = Math.max(1e-6, Math.hypot(dx, dy));
        a.x = x;
        a.y = y;
        a.vx = dx / d * speed;
        a.vy = dy / d * speed;
        a.damage = damage;
        a.crossbow = crossbow;
        arrows.add(a);
        return a;
    }

    /** Moves flying arrows; returns arrows that just hit a part (they are stuck to it afterwards). */
    public List<Arrow> flyArrows(double dt) {
        List<Arrow> hits = new ArrayList<>();
        for (Arrow a : arrows) {
            if (a.stuck) {
                continue;
            }
            int steps = 6;
            for (int s = 0; s < steps && !a.stuck; s++) {
                a.x += a.vx * dt / steps;
                a.y += a.vy * dt / steps;
                Part p = hit(a.x, a.y, 1);
                if (p != null) {
                    a.stuck = true;
                    a.part = p;
                    double[] l = p.local(a.x, a.y);
                    a.la = l[0];
                    a.lb = l[1];
                    a.relAngle = Math.atan2(a.vy, a.vx) - p.angle();
                    hits.add(a);
                } else if (a.x < left || a.x > right || a.y > floorY || a.y < top) {
                    a.stuck = true;
                    a.part = null;
                }
            }
        }
        return hits;
    }

    public double[] arrowPos(Arrow a) {
        if (a.part != null) {
            return a.part.point(a.la, a.lb);
        }
        return new double[] {a.x, a.y};
    }

    public double arrowAngle(Arrow a) {
        return a.part != null ? a.part.angle() + a.relAngle : Math.atan2(a.vy, a.vx);
    }
}
