/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

/**
 * Scoreboard Spoofer: rewrites the value part of the server's real sidebar rows at draw time.
 * The scoreboard data itself is never touched, so nothing is sent or changed on the server side.
 */
public final class ScoreboardFields {
    public static final String MODULE = "Scoreboard Spoofer";
    public static final String[][] DEFAULTS = {
        {"money", "1.8M"},
        {"shards", "1K"},
        {"kills", "1.6K"},
        {"deaths", "363"},
        {"keyall", "24m 31s"},
        {"playtime", "10d 15h"},
        {"team", "password"},
    };

    private static final Pattern LABEL =
            Pattern.compile("(?i)(?<![a-z])(money|shards?|kills?|deaths?|keyall|playtime|team)(?![a-z])");

    private ScoreboardFields() {}

    /** Called for every sidebar row (already formatted with team prefix/suffix). */
    public static MutableComponent row(MutableComponent original) {
        MutableComponent out = original;
        try {
            Module module = Gate.on(MODULE);
            if (module != null) {
                out = fields(module, original);
            }
        } catch (Throwable ignored) {
        }
        Component swapped = NameSwap.swap(out);
        return swapped instanceof MutableComponent m ? m : swapped.copy();
    }

    private static MutableComponent fields(Module module, MutableComponent original) {
        Flat flat = Flat.of(original);
        Matcher matcher = LABEL.matcher(flat.text);
        if (!matcher.find()) {
            return original;
        }
        String key = canonical(matcher.group(1));
        String value = module.stringSetting(key, "").trim();
        if (value.isEmpty()) {
            return original;
        }
        int start = matcher.end();
        while (start < flat.text.length()
                && (Character.isWhitespace(flat.text.charAt(start)) || flat.text.charAt(start) == ':')) {
            start++;
        }
        if (start >= flat.text.length()) {
            return original;
        }
        Style style = flat.styles.get(start);
        flat.replace(start, flat.text.length(), value, style);
        return flat.build();
    }

    private static String canonical(String label) {
        String l = label.toLowerCase(java.util.Locale.ROOT);
        if (l.startsWith("shard")) {
            return "shards";
        }
        if (l.startsWith("kill")) {
            return "kills";
        }
        if (l.startsWith("death")) {
            return "deaths";
        }
        return l;
    }
}
