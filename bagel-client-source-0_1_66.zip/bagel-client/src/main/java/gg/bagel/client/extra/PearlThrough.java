/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Anti-Trap: when you right-click with an ender pearl while an armor stand is under the crosshair, the click
 * would normally interact with the stand instead of throwing the pearl. This makes the click pass through it.
 */
public final class PearlThrough {
    private PearlThrough() {}

    public static void apply() {
        try {
            Module module = Gate.on("Anti-Trap");
            if (module == null || !module.booleanSetting("pearl_through_stands", true)) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            HitResult hit = mc.hitResult;
            if (player == null || !(hit instanceof EntityHitResult entityHit)) {
                return;
            }
            Entity target = entityHit.getEntity();
            if (!BuiltInRegistries.ENTITY_TYPE.getKey(target.getType()).getPath().equals("armor_stand")) {
                return;
            }
            if (!player.getMainHandItem().is(Items.ENDER_PEARL) && !player.getOffhandItem().is(Items.ENDER_PEARL)) {
                return;
            }
            mc.hitResult = BlockHitResult.miss(player.getEyePosition(), Direction.UP, player.blockPosition());
        } catch (Throwable ignored) {
        }
    }
}
