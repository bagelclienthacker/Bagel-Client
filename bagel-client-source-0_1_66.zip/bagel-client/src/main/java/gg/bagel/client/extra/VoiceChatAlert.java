/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.util.VanillaMode;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * A friendly heads-up: Simple Voice Chat does not work while Vanilla hides the client's mods from the server.
 * Shown once per game session when the Multiplayer screen opens.
 */
public final class VoiceChatAlert extends Screen {
    private static boolean shown;
    private final Screen parent;

    private VoiceChatAlert(Screen parent) {
        super(Component.literal("Voice chat and Vanilla"));
        this.parent = parent;
    }

    /** Called when the Multiplayer screen finishes opening. */
    public static void maybeShow(Screen multiplayer) {
        try {
            if (shown || !VanillaMode.active() || !FabricLoader.getInstance().isModLoaded("voicechat")) {
                return;
            }
            shown = true;
            Minecraft mc = Minecraft.getInstance();
            mc.execute(() -> {
                if (mc.gui.screen() == multiplayer) {
                    mc.setScreenAndShow(new VoiceChatAlert(multiplayer));
                }
            });
        } catch (Throwable ignored) {
            // an alert is never worth a crash
        }
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 + 26;
        this.addRenderableWidget(Button.builder(Component.literal("Got it"), b -> this.onClose())
                .bounds(cx - 105, y, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Switch to Modded"), b -> {
            VanillaMode.setActive(false, this.minecraft);
            this.onClose();
        }).bounds(cx + 5, y, 100, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int y = this.height / 2 - 44;
        String[] lines = {
            "Simple Voice Chat detected",
            "",
            "Voice chat doesn't work while you're on Vanilla,",
            "because Vanilla hides your mods from the server.",
            "Switch to Modded if you want to use voice chat."
        };
        for (int i = 0; i < lines.length; i++) {
            int color = i == 0 ? 0xFFFFFFFF : 0xFFB8B8B8;
            graphics.text(this.font, lines[i], cx - this.font.width(lines[i]) / 2, y + i * 12, color);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }
}
