/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;

/**
 * AuraKill: a joke "phonk edit" module. After you kill someone (normal hit or end crystal) it plays
 * a track from config/bagel/aurakill/ and fades the screen to black. Bagel ships no music.
 */
public final class AuraKill extends Module {
    public static final String NAME = "AuraKill";
    private static final int HIT_MEMORY_TICKS = 160;
    private static final int CRYSTAL_MEMORY_TICKS = 40;
    private static final double CRYSTAL_RADIUS_SQ = 12.0D * 12.0D;

    private static final Map<Integer, Long> HITS = new HashMap<>();
    private static final Map<Integer, Long> IGNORED = new HashMap<>();
    private static final List<double[]> CRYSTALS = new ArrayList<>();
    private static long ticks;
    private static volatile long startMs;
    private static volatile long endMs;
    private static boolean hudRegistered;
    private static boolean warnedNoTracks;

    public AuraKill() {
        super(NAME, "Plays your own phonk track and blacks out the screen after a kill", Category.MISC);
        setting("trigger", "both");
        setting("track", "random");
        setting("order", "random");
        setting("test", "click to test");
        setting("open_folder", "click to open");
        setting("volume", 100);
        setting("black_screen", Boolean.TRUE);
        setting("skull", Boolean.TRUE);
        setting("skull_size", 6);
        setting("overlay_opacity", 55);
        setting("overlay_gray", 45);
        setting("shake", Boolean.TRUE);
        setting("shake_intensity", 50);
        setting("screen_seconds", 6);
        setting("fade_in_ms", 150);
        setting("fade_out_ms", 700);
        setting("players_only", Boolean.TRUE);
    }

    /** Registers the black-screen HUD layer. Called once from BagelSetup. */
    public static void register() {
        if (hudRegistered) {
            return;
        }
        hudRegistered = true;
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("bagel", "aurakill"), AuraKill::renderHud);
        AuraKillAudio.ensureFolder();
    }

    private static AuraKill active() {
        Module m = BagelClient.MODULES.byName(NAME);
        return m instanceof AuraKill a && a.enabled() && !VanillaMode.active() ? a : null;
    }

    @Override
    protected void onEnable(Minecraft mc) {
        AuraKillAudio.ensureFolder();
        AuraKillAudio.preloadAsync();
        if (mc.player != null && AuraKillAudio.tracks().isEmpty()) {
            mc.gui.hud.setOverlayMessage(Component.literal("AuraKill: put .ogg/.wav files in config/bagel/aurakill").withColor(0xFFB347), false);
        }
    }

    @Override
    protected void onDisable(Minecraft mc) {
        endMs = 0;
        AuraKillAudio.stop();
        HITS.clear();
        CRYSTALS.clear();
        IGNORED.clear();
    }

    /** Called (via mixin) for every attack the local player makes. */
    public static void onAttack(Entity target) {
        AuraKill m = active();
        Minecraft mc = Minecraft.getInstance();
        if (m == null || target == null || mc.level == null || mc.player == null || target == mc.player) {
            return;
        }
        if (target instanceof EndCrystal) {
            CRYSTALS.add(new double[] {target.getX(), target.getY(), target.getZ(), ticks});
            for (Player p : mc.level.players()) {
                if (p.isDeadOrDying()) {
                    IGNORED.put(p.getId(), ticks + 100);
                }
            }
        } else if (target instanceof LivingEntity && (target instanceof Player || !m.booleanSetting("players_only", true))) {
            HITS.put(target.getId(), ticks);
        }
    }

    @Override
    public void tick(Minecraft mc) {
        ticks++;
        AuraKill m = active();
        ClientLevel level = mc.level;
        LocalPlayer self = mc.player;
        if (m == null || level == null || self == null) {
            return;
        }
        HITS.values().removeIf(t -> ticks - t > HIT_MEMORY_TICKS);
        IGNORED.values().removeIf(t -> t < ticks);
        CRYSTALS.removeIf(c -> ticks - (long) c[3] > CRYSTAL_MEMORY_TICKS);
        if (System.currentTimeMillis() < endMs) {
            return;
        }
        String trigger = m.stringSetting("trigger", "both").toLowerCase(Locale.ROOT);
        boolean normal = !trigger.equals("crystal");
        boolean crystal = !trigger.equals("normal");
        boolean killed = false;
        if (normal) {
            Iterator<Map.Entry<Integer, Long>> it = HITS.entrySet().iterator();
            while (it.hasNext()) {
                int id = it.next().getKey();
                Entity e = level.getEntity(id);
                if (e instanceof LivingEntity le && le.isDeadOrDying() && !IGNORED.containsKey(id)) {
                    IGNORED.put(id, ticks + 100);
                    it.remove();
                    killed = true;
                    break;
                }
            }
        }
        if (!killed && crystal && !CRYSTALS.isEmpty()) {
            for (Player p : level.players()) {
                if (p == self || !p.isDeadOrDying() || IGNORED.containsKey(p.getId())) {
                    continue;
                }
                for (double[] c : CRYSTALS) {
                    double dx = p.getX() - c[0];
                    double dy = p.getY() - c[1];
                    double dz = p.getZ() - c[2];
                    if (dx * dx + dy * dy + dz * dz <= CRYSTAL_RADIUS_SQ) {
                        IGNORED.put(p.getId(), ticks + 100);
                        killed = true;
                        break;
                    }
                }
                if (killed) {
                    break;
                }
            }
        }
        if (killed) {
            m.trigger(mc);
        }
    }

    /** Runs the effect once (the "test" row in the module settings). */
    public static void test() {
        Module m = BagelClient.MODULES.byName(NAME);
        if (m instanceof AuraKill a) {
            a.trigger(Minecraft.getInstance());
        }
    }

    public static void openFolder() {
        AuraKillAudio.ensureFolder();
        try {
            net.minecraft.util.Util.getPlatform().openPath(AuraKillAudio.folder());
        } catch (Throwable t) {
            BagelClient.LOGGER.warn("AuraKill could not open its folder", t);
        }
    }

    /** Fires the effect right now (also handy for testing). */
    private void trigger(Minecraft mc) {
        long now = System.currentTimeMillis();
        int seconds = intSetting("screen_seconds", 6);
        startMs = now;
        endMs = now + (seconds > 0 ? seconds * 1000L : 30000L);
        Path track = AuraKillAudio.choose(stringSetting("track", "random"), stringSetting("order", "random").equalsIgnoreCase("in order"));
        if (track == null) {
            if (!warnedNoTracks) {
                warnedNoTracks = true;
                mc.gui.hud.setOverlayMessage(Component.literal("AuraKill: no tracks found in config/bagel/aurakill").withColor(0xFFB347), false);
            }
            return;
        }
        float master = 1.0F;
        try {
            master = mc.options.getSoundSourceVolume(SoundSource.MASTER);
        } catch (Throwable ignored) {
            // keep full volume
        }
        float raw = Math.max(0, intSetting("volume", 100)) / 100.0F;
        float gain = raw * master;
        boolean matchAudio = seconds <= 0;
        long started = now;
        AuraKillAudio.playAsync(track, gain, raw, lengthMs -> {
            if (matchAudio && lengthMs > 0 && startMs == started) {
                endMs = System.currentTimeMillis() + lengthMs;
            }
        }, problem -> mc.execute(() -> {
            if (mc.gui != null) {
                mc.gui.hud.setOverlayMessage(Component.literal("AuraKill audio: " + problem).withColor(0xFF6B6B), false);
            }
        }));
    }

    /** Fade envelope 0..1 of the running effect (same curve as the black screen). */
    private static double envelope(AuraKill m, long now) {
        long end = endMs;
        long start = startMs;
        if (end == 0 || now >= end || now < start) {
            return 0.0D;
        }
        double in = Math.max(1, m.intSetting("fade_in_ms", 150));
        double out = Math.max(1, m.intSetting("fade_out_ms", 700));
        return Math.max(0.0D, Math.min(1.0D, Math.min((now - start) / in, (end - now) / out)));
    }

    private static double shakeAmount(boolean yaw) {
        if (endMs == 0) {
            return 0.0D;
        }
        Module module = BagelClient.MODULES.byName(NAME);
        if (!(module instanceof AuraKill m) || !m.booleanSetting("shake", true)) {
            return 0.0D;
        }
        long now = System.currentTimeMillis();
        double env = envelope(m, now);
        if (env <= 0.0D) {
            return 0.0D;
        }
        double t = now - startMs;
        double amp = 6.0D * Math.max(0, Math.min(100, m.intSetting("shake_intensity", 50))) / 100.0D * env;
        if (yaw) {
            return amp * (Math.sin(t * 0.0880D) * 0.6D + Math.sin(t * 0.1445D + 1.3D) * 0.4D);
        }
        return amp * 0.7D * (Math.sin(t * 0.1030D + 2.1D) * 0.6D + Math.sin(t * 0.1710D + 0.7D) * 0.4D);
    }

    /** Camera yaw offset in degrees (visual only; your real aim is untouched). */
    public static float shakeYaw() {
        return (float) shakeAmount(true);
    }

    /** Camera pitch offset in degrees. */
    public static float shakePitch() {
        return (float) shakeAmount(false);
    }

    /** 16x16 pixel-art skull (# = bone). */
    private static final String[] SKULL = {
        "....########....",
        "..############..",
        ".##############.",
        ".##############.",
        "################",
        "################",
        "###....##....###",
        "###....##....###",
        "###....##....###",
        "####..####..####",
        ".######..######.",
        ".######..######.",
        "..############..",
        "..##.##..##.##..",
        "..##.##..##.##..",
        "....########....",
    };

    private static void drawSkull(GuiGraphicsExtractor graphics, int centerX, int centerY, int cell, double alpha, double pulse) {
        int a = (int) Math.round(Math.max(0.0D, Math.min(1.0D, alpha)) * 255.0D);
        if (a <= 0) {
            return;
        }
        int size = Math.max(2, (int) Math.round(cell * pulse));
        int x0 = centerX - SKULL[0].length() * size / 2;
        int y0 = centerY - SKULL.length * size / 2;
        int shadow = ((a * 3 / 4) << 24);
        int bone = (a << 24) | 0xF2F2F2;
        for (int row = 0; row < SKULL.length; row++) {
            for (int col = 0; col < SKULL[row].length(); col++) {
                if (SKULL[row].charAt(col) == '#') {
                    int x = x0 + col * size, y = y0 + row * size;
                    graphics.fill(x - 1, y - 1, x + size + 1, y + size + 1, shadow);
                }
            }
        }
        for (int row = 0; row < SKULL.length; row++) {
            for (int col = 0; col < SKULL[row].length(); col++) {
                if (SKULL[row].charAt(col) == '#') {
                    int x = x0 + col * size, y = y0 + row * size;
                    graphics.fill(x, y, x + size, y + size, bone);
                }
            }
        }
    }

    private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker delta) {
        long end = endMs;
        long start = startMs;
        if (end == 0) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now >= end) {
            return;
        }
        Module module = BagelClient.MODULES.byName(NAME);
        if (!(module instanceof AuraKill m)) {
            return;
        }
        double in = Math.max(1, m.intSetting("fade_in_ms", 150));
        double out = Math.max(1, m.intSetting("fade_out_ms", 700));
        double a = Math.max(0.0D, Math.min(1.0D, Math.min((now - start) / in, (end - now) / out)));
        Minecraft mc = Minecraft.getInstance();
        int width = mc.getWindow().getGuiScaledWidth(), height = mc.getWindow().getGuiScaledHeight();
        if (m.booleanSetting("black_screen", true)) {
            double opacity = Math.max(0, Math.min(100, m.intSetting("overlay_opacity", 55))) / 100.0D;
            int alpha = (int) Math.round(a * opacity * 255.0D);
            if (alpha > 0) {
                int g = Math.round(Math.max(0, Math.min(100, m.intSetting("overlay_gray", 45))) / 100.0F * 255.0F);
                graphics.fill(0, 0, width, height, (alpha << 24) | (g << 16) | (g << 8) | g);
            }
        }
        if (m.booleanSetting("skull", true)) {
            int cell = Math.max(1, Math.min(20, m.intSetting("skull_size", 6)));
            double pulse = 1.0D + 0.06D * Math.sin((now - start) * 0.012D);
            drawSkull(graphics, width / 2, height / 2, cell, a, pulse);
        }
    }
}
