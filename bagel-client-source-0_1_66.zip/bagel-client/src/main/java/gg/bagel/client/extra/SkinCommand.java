/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** /bagelskin: opens the picker, or use|copy|model|reset directly. */
public final class SkinCommand {
    private static Screen pending;

    private SkinCommand() {}

    /** Opens a screen on the next tick, after the chat box has closed. */
    public static void openLater(Screen screen) {
        pending = screen;
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (pending != null && mc.gui.screen() == null) {
                Screen next = pending;
                pending = null;
                mc.setScreenAndShow(next);
            }
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) ->
                dispatcher.register(ClientCommands.literal("bagelskin")
                        .executes(c -> {
                            Minecraft mc = c.getSource().getClient();
                            openLater(new SkinPickerScreen(null));
                            return 1;
                        })
                        .then(ClientCommands.literal("copy")
                                .then(ClientCommands.argument("player", StringArgumentType.word())
                                        .suggests(SkinCommand::players)
                                        .executes(c -> {
                                            String name = StringArgumentType.getString(c, "player");
                                            SkinStore.copyPlayer(name);
                                            c.getSource().sendFeedback(Component.literal("Local skin: copying " + name));
                                            return 1;
                                        })))
                        .then(ClientCommands.literal("use")
                                .then(ClientCommands.argument("file", StringArgumentType.word())
                                        .suggests(SkinCommand::files)
                                        .executes(c -> {
                                            String file = StringArgumentType.getString(c, "file");
                                            SkinStore.useFile(file.toLowerCase(Locale.ROOT).endsWith(".png") ? file : file + ".png");
                                            c.getSource().sendFeedback(Component.literal("Local skin: " + file));
                                            return 1;
                                        })))
                        .then(ClientCommands.literal("model")
                                .then(ClientCommands.argument("type", StringArgumentType.word())
                                        .suggests((c, b) -> b.suggest("wide").suggest("slim").buildFuture())
                                        .executes(c -> {
                                            SkinStore.setSlim(StringArgumentType.getString(c, "type").equalsIgnoreCase("slim"));
                                            c.getSource().sendFeedback(Component.literal("Local skin model set"));
                                            return 1;
                                        })))
                        .then(ClientCommands.literal("reset")
                                .executes(c -> {
                                    SkinStore.reset();
                                    c.getSource().sendFeedback(Component.literal("Local skin reset"));
                                    return 1;
                                }))));
    }

    private static CompletableFuture<Suggestions> players(
            CommandContext<FabricClientCommandSource> context, SuggestionsBuilder builder) {
        String typed = builder.getRemainingLowerCase();
        for (String name : Names.online()) {
            if (name.toLowerCase(Locale.ROOT).startsWith(typed)) {
                builder.suggest(name);
            }
        }
        return builder.buildFuture();
    }

    private static CompletableFuture<Suggestions> files(
            CommandContext<FabricClientCommandSource> context, SuggestionsBuilder builder) {
        String typed = builder.getRemainingLowerCase();
        for (String name : SkinStore.files()) {
            if (name.toLowerCase(Locale.ROOT).startsWith(typed) && !name.contains(" ")) {
                builder.suggest(name);
            }
        }
        return builder.buildFuture();
    }
}
