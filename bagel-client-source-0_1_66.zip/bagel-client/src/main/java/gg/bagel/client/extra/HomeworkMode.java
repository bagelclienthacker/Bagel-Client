/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.blaze3d.platform.IconSet;
import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import javax.imageio.ImageIO;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;

/**
 * Homework Mode: makes the game window look like another app. The title bar text and the window/taskbar icon are
 * swapped for a Calculator or Wikipedia look, and a working calculator screen covers the game.
 *
 * <p>Logos: drop PNG files into {@code config/bagel/logos/} in the game folder. {@code wikipedia.png} and
 * {@code calculator.png} are picked up automatically for those looks, and the "logo" setting can name any other file
 * there. Without a file, a plain built-in icon is drawn (a calculator, or a generic open book). The Wikipedia and Calculator looks
 * use the logo files you put in the logos folder (Bagel does not ship them; they are other companies' trademarks), else a drawn built-in.
 *
 * <p>Turning the module off restores the normal title and icon.
 */
public final class HomeworkMode extends Module {
    public static final String NAME = "Homework Mode";

    private static volatile String title;
    private String applied = "";

    public HomeworkMode() {
        super(NAME, "Disguises the window as a calculator or Wikipedia", Category.MISC);
        setting("disguise", "Calculator");
        setting("title", "");
        setting("logo", "");
        setting("calculator_screen", Boolean.TRUE);
        setting("key_shape", "Circle");
        setting("theme", "Dark");
    }

    /** Title override used by the window title hook, or null when the mode is off. */
    public static String title() {
        return title;
    }

    public static Path logoDir() {
        return BagelClient.gameDirectory().resolve("config/bagel/logos");
    }

    @Override
    protected void onEnable(Minecraft mc) {
        try {
            Files.createDirectories(logoDir());
        } catch (IOException ignored) {
            // folder is a convenience only
        }
        applied = "";
        apply(mc);
        // open it even when the module was switched on from the click GUI (that screen is simply replaced)
        if (booleanSetting("calculator_screen", true)) {
            mc.setScreenAndShow(new CalculatorScreen());
        }
    }

    @Override
    protected void onDisable(Minecraft mc) {
        title = null;
        applied = "";
        try {
            mc.updateTitle();
            mc.getWindow().setIcon(mc.getVanillaPackResources(),
                    SharedConstants.getCurrentVersion().stable() ? IconSet.RELEASE : IconSet.SNAPSHOT);
        } catch (IOException | RuntimeException ignored) {
            // leave whatever icon is there
        }
        if (mc.gui.screen() instanceof CalculatorScreen) {
            mc.setScreenAndShow(null);
        }
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled()) {
            return;
        }
        // pick up setting changes while it is on
        String signature = stringSetting("disguise", "Calculator") + "|" + stringSetting("title", "") + "|" + stringSetting("logo", "");
        if (!signature.equals(applied)) {
            apply(mc);
        }
    }

    private void apply(Minecraft mc) {
        String mode = stringSetting("disguise", "Calculator").trim().toLowerCase(Locale.ROOT);
        String custom = stringSetting("title", "").trim();
        String fallbackTitle;
        String presetFile;
        switch (mode) {
            case "wikipedia":
                fallbackTitle = "Wikipedia, the free encyclopedia";
                presetFile = "wikipedia.png";
                break;
            case "custom":
                fallbackTitle = "Documents";
                presetFile = "custom.png";
                break;
            default:
                fallbackTitle = "Calculator";
                presetFile = "calculator.png";
                break;
        }
        title = custom.isEmpty() ? fallbackTitle : custom;
        applied = stringSetting("disguise", "Calculator") + "|" + stringSetting("title", "") + "|" + stringSetting("logo", "");
        try {
            mc.getWindow().setTitle(title);
            BufferedImage logo = loadLogo(stringSetting("logo", "").trim(), presetFile);
            if (logo == null && mode.equals("wikipedia")) {
                logo = bundled("/assets/bagel/homework/wikipedia.png");
            }
            if (logo == null && mode.equals("calculator")) {
                logo = bundled("/assets/bagel/homework/calculator.png");
            }
            if (logo == null) {
                logo = mode.equals("wikipedia") || mode.equals("custom") ? drawBook() : drawCalculator();
            }
            setWindowIcon(mc, logo);
        } catch (RuntimeException ignored) {
            // an unsupported platform just keeps its old icon
        }
    }

    private static BufferedImage bundled(String resource) {
        try (java.io.InputStream in = HomeworkMode.class.getResourceAsStream(resource)) {
            return in == null ? null : ImageIO.read(in);
        } catch (IOException e) {
            return null;
        }
    }

    private static BufferedImage loadLogo(String chosen, String presetFile) {
        Path dir = logoDir();
        for (String name : new String[] {chosen, presetFile}) {
            if (name.isEmpty() || name.contains("/") || name.contains("\\") || name.contains("..")) {
                continue;
            }
            Path file = dir.resolve(name);
            if (Files.isRegularFile(file)) {
                try {
                    BufferedImage image = ImageIO.read(file.toFile());
                    if (image != null) {
                        return image;
                    }
                } catch (IOException ignored) {
                    // try the next candidate
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ window icon

    /** Sets the window icon through LWJGL's GLFW (looked up by name, so nothing here needs LWJGL at compile time). */
    private static void setWindowIcon(Minecraft mc, BufferedImage source) {
        int[] sizes = {16, 32, 48, 64};
        Object images = null;
        try {
            Class<?> imageClass = Class.forName("org.lwjgl.glfw.GLFWImage");
            Class<?> bufferClass = Class.forName("org.lwjgl.glfw.GLFWImage$Buffer");
            Class<?> glfw = Class.forName("org.lwjgl.glfw.GLFW");
            images = imageClass.getMethod("malloc", int.class).invoke(null, sizes.length);
            java.lang.reflect.Method get = bufferClass.getMethod("get", int.class);
            java.lang.reflect.Method set = imageClass.getMethod("set", int.class, int.class, ByteBuffer.class);
            ByteBuffer[] keep = new ByteBuffer[sizes.length];
            for (int i = 0; i < sizes.length; i++) {
                int size = sizes[i];
                BufferedImage scaled = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = scaled.createGraphics();
                g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                double fit = Math.min((double) size / source.getWidth(), (double) size / source.getHeight());
                int dw = Math.max(1, (int) Math.round(source.getWidth() * fit));
                int dh = Math.max(1, (int) Math.round(source.getHeight() * fit));
                g.drawImage(source, (size - dw) / 2, (size - dh) / 2, dw, dh, null);
                g.dispose();
                ByteBuffer buffer = ByteBuffer.allocateDirect(size * size * 4).order(java.nio.ByteOrder.nativeOrder());
                for (int y = 0; y < size; y++) {
                    for (int x = 0; x < size; x++) {
                        int argb = scaled.getRGB(x, y);
                        buffer.put((byte) (argb >> 16)).put((byte) (argb >> 8)).put((byte) argb).put((byte) (argb >>> 24));
                    }
                }
                buffer.flip();
                keep[i] = buffer;
                set.invoke(get.invoke(images, i), size, size, buffer);
            }
            glfw.getMethod("glfwSetWindowIcon", long.class, bufferClass).invoke(null, mc.getWindow().handle(), images);
        } catch (ReflectiveOperationException | RuntimeException e) {
            // no icon change on this platform
        } finally {
            if (images != null) {
                try {
                    images.getClass().getMethod("free").invoke(images);
                } catch (ReflectiveOperationException | RuntimeException ignored) {
                    // nothing to free
                }
            }
        }
    }

    // ------------------------------------------------------------------ built-in plain icons

    private static Graphics2D canvas(BufferedImage image) {
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        return g;
    }

    /** A plain calculator: dark body, green display, a grid of keys. */
    static BufferedImage drawCalculator() {
        BufferedImage image = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = canvas(image);
        g.setColor(new Color(0x2B2F36));
        g.fillRoundRect(8, 3, 48, 58, 9, 9);
        g.setColor(new Color(0x9CD6A8));
        g.fillRoundRect(13, 8, 38, 13, 4, 4);
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                boolean accent = col == 3;
                g.setColor(accent ? new Color(0xF0A030) : new Color(0xD7DAE0));
                g.fillRoundRect(13 + col * 10, 26 + row * 8, 8, 6, 2, 2);
            }
        }
        g.dispose();
        return image;
    }

    /** A generic open book on a light tile, standing in for any encyclopedia look. */
    static BufferedImage drawBook() {
        BufferedImage image = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = canvas(image);
        g.setColor(new Color(0xF4F4F2));
        g.fillRoundRect(2, 2, 60, 60, 14, 14);
        g.setColor(new Color(0xB9BDC4));
        g.setStroke(new BasicStroke(2f));
        g.drawRoundRect(2, 2, 60, 60, 14, 14);
        g.setColor(new Color(0x3C4A63));
        g.fillPolygon(new int[] {10, 32, 32, 10}, new int[] {16, 20, 50, 46}, 4);
        g.fillPolygon(new int[] {54, 32, 32, 54}, new int[] {16, 20, 50, 46}, 4);
        g.setColor(new Color(0xE8ECF3));
        for (int i = 0; i < 4; i++) {
            g.drawLine(14, 24 + i * 6, 29, 26 + i * 6);
            g.drawLine(50, 24 + i * 6, 35, 26 + i * 6);
        }
        g.dispose();
        return image;
    }
}
