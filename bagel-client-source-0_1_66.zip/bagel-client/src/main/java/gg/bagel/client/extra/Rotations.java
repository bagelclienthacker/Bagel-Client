/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Silent rotations: the server is told where we aim, the camera never moves. */
final class Rotations {
    private Rotations() {}

    /** Closest point of the target's hitbox to our eyes. */
    static Vec3 aimPoint(LocalPlayer player, Entity target) {
        Vec3 eyes = player.getEyePosition();
        AABB box = target.getBoundingBox();
        return new Vec3(
                Mth.clamp(eyes.x, box.minX, box.maxX),
                Mth.clamp(eyes.y, box.minY, box.maxY),
                Mth.clamp(eyes.z, box.minZ, box.maxZ));
    }

    /**
     * The point we actually aim at. A ray through the middle of the hitbox is what servers expect, the
     * closest edge point (aimPoint) only barely touches the box and gets missed or flagged.
     */
    static Vec3 aimAt(LocalPlayer player, Entity target, String mode) {
        AABB box = target.getBoundingBox();
        double cx = (box.minX + box.maxX) / 2.0D;
        double cz = (box.minZ + box.maxZ) / 2.0D;
        double height = box.maxY - box.minY;
        switch (mode) {
            case "closest":
                return aimPoint(player, target);
            case "head":
                return new Vec3(cx, box.minY + height * 0.9D, cz);
            default:
                return new Vec3(cx, box.minY + height * 0.55D, cz);
        }
    }

    static float[] anglesTo(LocalPlayer player, Vec3 point) {
        Vec3 eyes = player.getEyePosition();
        double dx = point.x - eyes.x;
        double dy = point.y - eyes.y;
        double dz = point.z - eyes.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[] {Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90.0F, 90.0F)};
    }

    static void send(Minecraft mc, LocalPlayer player, float yaw, float pitch) {
        if (mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, player.onGround(), player.horizontalCollision));
        }
    }

    /** Tells the server to face {@code point}. Returns the previous real rotation so it can be restored. */
    static void face(Minecraft mc, LocalPlayer player, Vec3 point) {
        float[] angles = anglesTo(player, point);
        send(mc, player, angles[0], angles[1]);
    }

    /** Visible rotation: actually turns your camera / player to face the point. */
    static void snap(LocalPlayer player, Vec3 point) {
        float[] angles = anglesTo(player, point);
        player.setYRot(angles[0]);
        player.setXRot(angles[1]);
    }

    static void restore(Minecraft mc, LocalPlayer player) {
        send(mc, player, player.getYRot(), player.getXRot());
    }
}
