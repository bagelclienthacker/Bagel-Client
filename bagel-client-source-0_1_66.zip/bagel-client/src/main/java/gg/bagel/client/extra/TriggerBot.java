/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Trigger Bot: attacks whatever is under your crosshair at the right moment.
 *
 * <p>Rewritten: it never touches your aim and sends no extra packets. It waits for the weapon cooldown, then for a
 * human-like reaction delay (with jitter) after the target comes under the crosshair, and can optionally hit only
 * while falling (critical hits) or only when holding a real weapon.
 */
public final class TriggerBot extends Module {
    public static final String NAME = "Trigger Bot";

    private int lockedId = -1;
    private long fireAt;
    private long lastHit;

    public TriggerBot() {
        super(NAME, "Attacks what is under your crosshair when the weapon is ready", Category.COMBAT);
        setting("entities", "minecraft:player");
        setting("cooldown", 0.92D);
        setting("reaction_ms", 50);
        setting("reaction_jitter_ms", 40);
        setting("criticals", "Off");
        setting("weapon_only", Boolean.FALSE);
        setting("hurt_time", 10);
        setting("skip_blocking", Boolean.FALSE);
        setting("swing_on_miss", Boolean.FALSE);
    }

    @Override
    protected void onDisable(Minecraft mc) {
        lockedId = -1;
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (!CombatUtil.canRun(mc, player) || player.isUsingItem() || mc.gameMode.isDestroying()) {
            lockedId = -1;
            return;
        }
        if (!(mc.hitResult instanceof EntityHitResult hit) || hit.getType() != HitResult.Type.ENTITY) {
            lockedId = -1;
            return;
        }
        Entity entity = hit.getEntity();
        if (!(entity instanceof LivingEntity living) || !living.isAlive() || entity == player || !KillAura.matches(this, entity)
                || living.hurtTime > Math.max(0, intSetting("hurt_time", 10))) {
            lockedId = -1;
            return;
        }
        if (booleanSetting("skip_blocking", false) && living.isBlocking()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (lockedId != entity.getId()) {
            // first moment this target is under the crosshair: start the reaction timer
            lockedId = entity.getId();
            fireAt = now + CombatUtil.delayMs(intSetting("reaction_ms", 50), intSetting("reaction_jitter_ms", 40));
        }
        if (now < fireAt || now - lastHit < 90L) {
            return;
        }
        if (booleanSetting("weapon_only", false) && !isWeapon(player.getMainHandItem())) {
            return;
        }
        double threshold = Math.min(1.0D, Math.max(0.0D, doubleSetting("cooldown", 0.92D)));
        if (player.getAttackStrengthScale(0.5F) < threshold) {
            return;
        }
        String crit = stringSetting("criticals", "Off").trim().toLowerCase(Locale.ROOT);
        if (crit.startsWith("fall") && !(player.fallDistance > 0.0F && !player.onGround() && !player.isInWater()
                && !player.onClimbable() && !player.isPassenger())) {
            return;
        }
        mc.gameMode.attack(player, entity);
        player.swing(InteractionHand.MAIN_HAND);
        lastHit = now;
        fireAt = now + CombatUtil.delayMs(0, intSetting("reaction_jitter_ms", 40) / 2);
    }

    private static boolean isWeapon(ItemStack stack) {
        return Hotbar.isSword(stack) || Hotbar.isAxe(stack) || Hotbar.isMace(stack) || Hotbar.isSpear(stack)
                || Hotbar.path(stack).equals("trident");
    }
}
