/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.extra.chess.ChessScreen;
import gg.bagel.client.module.Module;

/** Modules in the RShift menu that open a screen when clicked instead of switching on and off. */
public final class Openers {
    private Openers() {}

    /** Called at the start of Module.toggle; true means the click was handled and nothing should toggle. */
    public static boolean click(Module module) {
        try {
            if (module == null) {
                return false;
            }
            String name = module.name();
            if (Chess.NAME.equals(name)) {
                ChessScreen.open();
                return true;
            }
            if (HitDummy.NAME.equals(name)) {
                DummyScreen.open();
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }
}
