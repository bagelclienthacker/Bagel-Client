/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import net.minecraft.client.sounds.JOrbisAudioStream;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

/**
 * Plays the user's own tracks for AuraKill. Bagel ships NO music: it only reads .ogg / .wav files
 * that the player drops into config/bagel/aurakill/.
 */
final class AuraKillAudio {
    private record Pcm(AudioFormat format, byte[] data) {}

    private static final Map<Path, Pcm> CACHE = new ConcurrentHashMap<>();
    private static final long MAX_BYTES = 120L * 1024 * 1024;
    private static volatile Clip current;
    private static volatile int alSource;
    private static volatile int alBuffer;

    private AuraKillAudio() {}

    static Path folder() {
        return BagelClient.gameDirectory().resolve("config/bagel/aurakill");
    }

    static void ensureFolder() {
        try {
            Path dir = folder();
            Files.createDirectories(dir);
            Path note = dir.resolve("README.txt");
            if (!Files.exists(note)) {
                Files.writeString(note, "Put your own .ogg or .wav tracks in this folder.\n"
                        + "AuraKill plays one of them after a kill (see the 'track' setting).\n"
                        + "Bagel does not ship any music - only use music you have the rights to use.\n");
            }
        } catch (Exception e) {
            BagelClient.LOGGER.warn("AuraKill could not create its folder", e);
        }
    }

    static List<Path> tracks() {
        List<Path> out = new ArrayList<>();
        try (Stream<Path> files = Files.list(folder())) {
            files.filter(Files::isRegularFile).forEach(p -> {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (n.endsWith(".ogg") || n.endsWith(".wav")) {
                    out.add(p);
                }
            });
        } catch (Exception ignored) {
            // folder missing: no tracks
        }
        out.sort(null);
        return out;
    }

    private static int nextIndex;

    /**
     * Picks the track. {@code wanted} may be empty / "random" (any file), or one or more file-name
     * fragments separated by commas ("phonk1, drift"); only matching files are used.
     * {@code ordered} plays the matching files one after another instead of randomly.
     */
    static Path choose(String wanted, boolean ordered) {
        List<Path> all = tracks();
        if (all.isEmpty()) {
            return null;
        }
        List<Path> pool = new ArrayList<>();
        String w = wanted == null ? "" : wanted.trim().toLowerCase(Locale.ROOT);
        if (!w.isEmpty() && !w.equals("random")) {
            for (String part : w.split(",")) {
                String f = part.trim();
                if (f.isEmpty()) {
                    continue;
                }
                for (Path p : all) {
                    if (!pool.contains(p) && p.getFileName().toString().toLowerCase(Locale.ROOT).contains(f)) {
                        pool.add(p);
                    }
                }
            }
        }
        if (pool.isEmpty()) {
            pool = all;
        }
        if (ordered) {
            return pool.get(Math.floorMod(nextIndex++, pool.size()));
        }
        return pool.get((int) (Math.random() * pool.size()));
    }

    /** Decodes the files ahead of time so the first kill does not stutter. */
    static void preloadAsync() {
        Thread t = new Thread(() -> {
            for (Path p : tracks()) {
                try {
                    decode(p);
                } catch (Throwable ignored) {
                    // reported when it is actually played
                }
            }
        }, "bagel-aurakill-preload");
        t.setDaemon(true);
        t.start();
    }

    private static synchronized void stopOpenAl() {
        int source = alSource, buffer = alBuffer;
        alSource = 0;
        alBuffer = 0;
        if (source != 0) {
            try {
                AL10.alSourceStop(source);
                AL10.alDeleteSources(source);
                AL10.alDeleteBuffers(buffer);
            } catch (Throwable ignored) {
                // the sound system is gone
            }
        }
    }

    /**
     * Plays through the game's own OpenAL sound system (the same one that plays Minecraft's sounds), so it works
     * wherever the game has sound. Returns the length in ms, or throws if OpenAL cannot be used.
     */
    private static long playOpenAl(Pcm pcm, float rawGain) throws Exception {
        AudioFormat f = pcm.format();
        int channels = f.getChannels();
        if (f.getSampleSizeInBits() != 16 || channels < 1 || channels > 2 || f.isBigEndian()) {
            throw new IllegalStateException("format not supported by OpenAL path: " + f);
        }
        int format = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
        java.nio.ByteBuffer direct = BufferUtils.createByteBuffer(pcm.data().length);
        direct.put(pcm.data());
        direct.flip();
        int source;
        synchronized (AuraKillAudio.class) {
            stopOpenAl();
            AL10.alGetError();
            int buffer = AL10.alGenBuffers();
            source = AL10.alGenSources();
            AL10.alBufferData(buffer, format, direct, (int) f.getSampleRate());
            int error = AL10.alGetError();
            if (error != AL10.AL_NO_ERROR) {
                AL10.alDeleteSources(source);
                AL10.alDeleteBuffers(buffer);
                throw new IllegalStateException("OpenAL error " + error);
            }
            AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
            AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            AL10.alSource3f(source, AL10.AL_POSITION, 0.0F, 0.0F, 0.0F);
            AL10.alSourcef(source, AL10.AL_MAX_GAIN, 4.0F);
            AL10.alSourcef(source, AL10.AL_GAIN, Math.max(0.0F, Math.min(4.0F, rawGain)));
            AL10.alSourcePlay(source);
            alSource = source;
            alBuffer = buffer;
        }
        Thread.sleep(120);
        if (AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE) != AL10.AL_PLAYING) {
            stopOpenAl();
            throw new IllegalStateException("OpenAL source did not start");
        }
        final int watched = source;
        Thread watcher = new Thread(() -> {
            try {
                while (alSource == watched && AL10.alGetSourcei(watched, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) {
                    Thread.sleep(250);
                }
            } catch (Throwable ignored) {
                // stopped or sound system closed
            }
            synchronized (AuraKillAudio.class) {
                if (alSource == watched) {
                    stopOpenAl();
                }
            }
        }, "bagel-aurakill-al");
        watcher.setDaemon(true);
        watcher.start();
        return (long) (pcm.data().length * 1000.0D / (f.getSampleRate() * channels * 2));
    }

    static void stop() {
        stopOpenAl();
        Clip c = current;
        current = null;
        if (c != null) {
            try {
                c.stop();
                c.close();
            } catch (Throwable ignored) {
                // already closed
            }
        }
    }

    /** Plays on a worker thread. lengthMs is reported to the callback once playback started; failures say why. */
    static void playAsync(Path file, float gain, float rawGain, java.util.function.LongConsumer started,
            java.util.function.Consumer<String> failed) {
        Thread t = new Thread(() -> {
            Pcm pcm;
            try {
                pcm = decode(file);
            } catch (Throwable e) {
                BagelClient.LOGGER.warn("AuraKill could not decode " + file.getFileName(), e);
                failed.accept(decodeProblem(file, e));
                return;
            }
            Throwable alProblem = null;
            try {
                started.accept(playOpenAl(pcm, rawGain));
                return;
            } catch (Throwable e) {
                alProblem = e;
                BagelClient.LOGGER.warn("AuraKill: OpenAL playback failed, trying Java Sound", e);
            }
            try {
                stop();
                Clip clip = AudioSystem.getClip();
                clip.open(pcm.format(), pcm.data(), 0, pcm.data().length);
                if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl control = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    float g = Math.max(0.0001F, Math.min(4.0F, gain));
                    float db = (float) (20.0D * Math.log10(g));
                    control.setValue(Math.max(control.getMinimum(), Math.min(control.getMaximum(), db)));
                }
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        clip.close();
                    }
                });
                current = clip;
                clip.start();
                started.accept(clip.getMicrosecondLength() / 1000L);
            } catch (Throwable e) {
                BagelClient.LOGGER.warn("AuraKill could not play " + file.getFileName(), e);
                failed.accept("no sound output worked (" + alProblem.getClass().getSimpleName() + ": " + alProblem.getMessage()
                        + " / " + e.getClass().getSimpleName() + ": " + e.getMessage() + ")");
            }
        }, "bagel-aurakill-audio");
        t.setDaemon(true);
        t.start();
    }

    /** A human-readable reason a file could not be decoded (Opus-in-Ogg is the usual surprise). */
    private static String decodeProblem(Path file, Throwable e) {
        try (InputStream in = Files.newInputStream(file)) {
            byte[] head = in.readNBytes(512);
            String text = new String(head, java.nio.charset.StandardCharsets.ISO_8859_1);
            if (text.contains("OpusHead")) {
                return file.getFileName() + " is an Opus .ogg; Bagel can only read Vorbis .ogg (re-encode: ffmpeg -i in.ogg -c:a libvorbis out.ogg) or .wav";
            }
            if (text.contains("fLaC") || text.contains("FLAC")) {
                return file.getFileName() + " is FLAC in an Ogg container; re-encode it as Vorbis .ogg or .wav";
            }
        } catch (Throwable ignored) {
            // fall through to the generic message
        }
        return "could not decode " + file.getFileName() + " (" + e.getClass().getSimpleName() + ": " + e.getMessage() + ")";
    }

    private static Pcm decode(Path file) throws Exception {
        Pcm cached = CACHE.get(file);
        if (cached != null) {
            return cached;
        }
        if (Files.size(file) > MAX_BYTES) {
            throw new IllegalStateException("file too large");
        }
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        Pcm pcm;
        if (name.endsWith(".ogg")) {
            try (InputStream in = Files.newInputStream(file); JOrbisAudioStream stream = new JOrbisAudioStream(in)) {
                AudioFormat format = stream.getFormat();
                ByteBuffer buffer = stream.readAll().duplicate();
                if (buffer.remaining() == 0 && buffer.position() > 0) {
                    buffer.flip();
                }
                byte[] data = new byte[buffer.remaining()];
                buffer.get(data);
                pcm = new Pcm(format, data);
            }
        } else {
            try (AudioInputStream raw = AudioSystem.getAudioInputStream(file.toFile())) {
                AudioFormat f = raw.getFormat();
                AudioInputStream use = raw;
                if (f.getEncoding() != AudioFormat.Encoding.PCM_SIGNED) {
                    AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, f.getSampleRate(), 16,
                            f.getChannels(), f.getChannels() * 2, f.getSampleRate(), false);
                    use = AudioSystem.getAudioInputStream(target, raw);
                }
                pcm = new Pcm(use.getFormat(), use.readAllBytes());
            }
        }
        CACHE.put(file, pcm);
        return pcm;
    }
}
