/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Aim Assist: gently pulls your real camera toward the best target inside a field of view. It never attacks and never
 * sends anything: it only nudges the same rotation your mouse moves, in steps that look like mouse counts.
 */
public final class AimAssist extends Module {
    public static final String NAME = "Aim Assist";

    private int lockedId = -1;

    public AimAssist() {
        super(NAME, "Pulls your camera toward targets", Category.COMBAT);
        setting("range", 4.5D);
        setting("fov", 90);
        setting("turn_speed", 20.0D);
        setting("smoothing", 0.3D);
        setting("aim_point", "Nearest");
        setting("vertical", Boolean.TRUE);
        setting("only_when_attacking", Boolean.FALSE);
        setting("stop_on_target", Boolean.TRUE);
        setting("visible_only", Boolean.TRUE);
        setting("sticky", Boolean.TRUE);
        setting("targeting", "FOV");
        setting("entities", "minecraft:player");
        setting("hurt_time", 10);
    }

    @Override
    protected void onDisable(Minecraft mc) {
        lockedId = -1;
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (!CombatUtil.canRun(mc, player) || player.isUsingItem() || SilentAim.blocked(player)) {
            lockedId = -1;
            return;
        }
        if (booleanSetting("only_when_attacking", false) && !mc.options.keyAttack.isDown()) {
            return;
        }
        double range = Math.max(1.0D, doubleSetting("range", 4.5D));
        LivingEntity target = choose(mc, player, range);
        if (target == null) {
            lockedId = -1;
            return;
        }
        lockedId = target.getId();
        Vec3 point = point(player, target);
        if (booleanSetting("stop_on_target", true) && crosshairOn(mc, target)) {
            return;
        }
        float[] want = KillAura.anglesTo(player.getEyePosition(), point);
        float dyaw = Mth.wrapDegrees(want[0] - player.getYRot());
        float dpitch = want[1] - player.getXRot();
        if (!booleanSetting("vertical", true)) {
            dpitch = 0.0F;
        }
        // LiquidBounce-style: cover a fraction of the remaining angle each tick, never faster than turn_speed,
        // no random wobble. Slows down by itself as it closes in, so it settles instead of snapping.
        double maxTurn = Math.min(60.0D, Math.max(1.0D, doubleSetting("turn_speed", 20.0D)));
        double smoothing = Math.min(1.0D, Math.max(0.02D, doubleSetting("smoothing", 0.3D)));
        float step = SilentAim.step(mc);
        float stepYaw = ease(dyaw, smoothing, maxTurn, step);
        float stepPitch = ease(dpitch, smoothing, maxTurn * 0.6D, step);
        if (stepYaw == 0.0F && stepPitch == 0.0F) {
            return;
        }
        // Only the current rotation moves; the previous one (yRotO) stays, so the game's frame interpolation
        // spreads the nudge over the whole tick instead of jumping 20 times a second.
        player.setYRot(player.getYRot() + stepYaw);
        player.setXRot(Mth.clamp(player.getXRot() + stepPitch, -90.0F, 90.0F));
    }

    /** One tick of easing toward {@code diff} degrees, quantised to mouse counts. */
    private static float ease(float diff, double smoothing, double max, float mouseStep) {
        float abs = Math.abs(diff);
        if (abs < 0.25F) {
            return 0.0F;
        }
        double move = Math.min(abs * smoothing, max);
        // at least one mouse count, otherwise a small remaining angle would never close
        move = Math.max(move, Math.min(abs, mouseStep));
        float counts = Math.max(1.0F, Math.round(move / mouseStep));
        float out = Math.min(counts * mouseStep, abs);
        return Math.copySign(out, diff);
    }

    private LivingEntity choose(Minecraft mc, LocalPlayer player, double range) {
        int fov = Math.max(5, Math.min(360, intSetting("fov", 90)));
        int maxHurt = Math.max(0, intSetting("hurt_time", 10));
        boolean visible = booleanSetting("visible_only", true);
        String mode = stringSetting("targeting", "FOV").trim().toLowerCase(Locale.ROOT);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!CombatUtil.validTarget(this, player, entity, range + 2.0D, maxHurt)) {
                continue;
            }
            LivingEntity living = (LivingEntity) entity;
            if (CombatUtil.reachTo(player, living) > range) {
                continue;
            }
            Vec3 point = point(player, living);
            double angle = CombatUtil.angleToLook(player, point);
            boolean locked = booleanSetting("sticky", true) && living.getId() == lockedId;
            if (angle > fov * 0.5D * (locked ? 1.4D : 1.0D)) {
                continue;
            }
            if (visible && !clear(mc, player, point)) {
                continue;
            }
            double score;
            switch (mode) {
                case "hp":
                    score = Explosions.health(living);
                    break;
                case "distance":
                    score = CombatUtil.reachTo(player, living);
                    break;
                default:
                    score = angle;
                    break;
            }
            if (locked) {
                score -= 1000.0D;
            }
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private Vec3 point(LocalPlayer player, LivingEntity entity) {
        String mode = stringSetting("aim_point", "Nearest").trim().toLowerCase(Locale.ROOT);
        AABB box = entity.getBoundingBox();
        switch (mode) {
            case "head":
                return Rotations.aimAt(player, entity, "head");
            case "closest":
                return Rotations.aimAt(player, entity, "closest");
            case "body":
                return new Vec3((box.minX + box.maxX) / 2.0D, box.minY + (box.maxY - box.minY) * 0.6D, (box.minZ + box.maxZ) / 2.0D);
            default:
                return nearest(player, box);
        }
    }

    /**
     * The point of the hitbox that needs the least turning: take the spot your crosshair ray passes at the target's
     * distance and pull it into the box (a little inside the edge). Aiming for the nearest edge means short, calm
     * movements, and no movement at all once the crosshair is already on the box.
     */
    private static Vec3 nearest(LocalPlayer player, AABB box) {
        Vec3 eyes = player.getEyePosition();
        Vec3 center = box.getCenter();
        double distance = eyes.distanceTo(center);
        Vec3 along = eyes.add(player.getLookAngle().scale(distance));
        double inset = 0.12D;
        double x = Mth.clamp(along.x, box.minX + inset, box.maxX - inset);
        double y = Mth.clamp(along.y, box.minY + inset, box.maxY - inset);
        double z = Mth.clamp(along.z, box.minZ + inset, box.maxZ - inset);
        return new Vec3(x, y, z);
    }

    private static boolean crosshairOn(Minecraft mc, LivingEntity target) {
        return mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit && hit.getEntity() == target;
    }

    private static boolean clear(Minecraft mc, LocalPlayer player, Vec3 point) {
        BlockHitResult hit = mc.level.clip(new ClipContext(player.getEyePosition(), point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.MISS || hit.getLocation().distanceToSqr(point) < 0.01D;
    }
}
