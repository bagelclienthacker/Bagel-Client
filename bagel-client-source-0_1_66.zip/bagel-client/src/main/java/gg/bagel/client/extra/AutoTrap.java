/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Player;

/** Auto Trap: boxes the nearest player in with blocks (feet ring, head ring, and a lid). */
public final class AutoTrap extends Module {
    public static final String NAME = "Auto Trap";
    private final Map<BlockPos, Integer> tried = new HashMap<>();
    private int tickCount;
    private int wait;

    public AutoTrap() {
        super(NAME, "Traps nearby players in blocks", Category.COMBAT);
        setting("range", 5);
        setting("place_range", 4.5D);
        setting("block", "obsidian");
        setting("blocks_per_tick", 2);
        setting("top", Boolean.TRUE);
        setting("delay_ticks", 1);
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (player == null || mc.gameMode == null || mc.level == null || !player.isAlive()) {
            return;
        }
        tickCount++;
        if (wait > 0) {
            wait--;
            return;
        }
        String block = stringSetting("block", "obsidian").trim().toLowerCase(Locale.ROOT);
        int slot = BlockPlacer.findSlot(player, s -> BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().equals(block));
        if (slot < 0) {
            return;
        }
        Player target = BlockPlacer.nearestPlayer(mc, Math.max(1, Math.min(12, intSetting("range", 5))));
        if (target == null) {
            return;
        }
        BlockPos feet = target.blockPosition();
        List<BlockPos> cells = new ArrayList<>();
        for (int level = 0; level <= 1; level++) {
            for (Direction d : Direction.Plane.HORIZONTAL) {
                cells.add(feet.above(level).relative(d));
            }
        }
        if (booleanSetting("top", true)) {
            cells.add(feet.above(2));
        }
        double reach = Math.max(2.0D, Math.min(6.0D, doubleSetting("place_range", 4.5D)));
        int perTick = Math.max(1, Math.min(4, intSetting("blocks_per_tick", 2)));
        int placed = 0;
        for (BlockPos cell : cells) {
            if (placed >= perTick) {
                break;
            }
            Integer last = tried.get(cell);
            if (last != null && tickCount - last < 8) {
                continue;
            }
            if (!BlockPlacer.replaceable(mc.level, cell)) {
                continue;
            }
            tried.put(cell, tickCount);
            if (BlockPlacer.place(mc, player, mc.level, cell, slot, reach)) {
                placed++;
            }
        }
        if (placed > 0) {
            wait = Math.max(0, Math.min(20, intSetting("delay_ticks", 1)));
        }
        if (tried.size() > 64) {
            tried.entrySet().removeIf(e -> tickCount - e.getValue() > 40);
        }
    }

    @Override
    protected void onDisable(Minecraft mc) {
        tried.clear();
    }
}
