/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.extra.chess.ChessScreen;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import net.minecraft.client.Minecraft;

/** Offline chess vs a basic bot. Click it in the RShift menu to open the board. */
public final class Chess extends Module {
    public static final String NAME = "Chess";

    public Chess() {
        super(NAME, "Click to play a basic offline chess bot", Category.MISC);
    }

    @Override
    protected void onEnable(Minecraft mc) {
        mc.execute(() -> {
            setEnabled(false, mc);
            ChessScreen.open();
        });
    }
}
