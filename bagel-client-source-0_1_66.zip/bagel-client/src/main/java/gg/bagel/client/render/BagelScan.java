/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.render;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import gg.bagel.client.render.BagelOverlay.BlockTarget;
import gg.bagel.client.util.VanillaMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;

/**
 * Block-based ESPs (Storage, Block, Spawner, Block Highlights) across the whole render distance.
 * Loaded chunks are scanned a few at a time and cached, so the cost per tick stays small.
 */
public final class BagelScan {
    private static final long BUDGET_NANOS = 3_000_000L;
    private static final int MAX_TARGETS = 12000;
    private static final int HIGHLIGHT_COLOR = -25049;

    private static final Map<Long, List<BlockTarget>> CACHE = new HashMap<>();
    private static List<Long> order = List.of();
    private static int orderX = Integer.MIN_VALUE;
    private static int orderZ = Integer.MIN_VALUE;
    private static int orderRadius = -1;
    private static int cursor;
    private static String signature = "";
    private static ClientLevel lastLevel;
    private static List<BlockTarget> merged = List.of();
    private static byte[] mergedKinds = new byte[0];
    private static final Map<Long, byte[]> KIND_CACHE = new HashMap<>();
    private static boolean warned;
    private static boolean exposedOnly;
    /** Block ESP colour: 0 = automatic (a colour per block type), otherwise one opaque ARGB colour. */
    private static int espColor;
    private static int highlightColor = HIGHLIGHT_COLOR;
    private static List<Byte> kindSink = new ArrayList<>();

    private BagelScan() {}

    /** 0 = storage, 1 = block esp, 2 = spawner, 3 = block highlight (index matches the scan result). */
    public static int kind(int index) {
        return index >= 0 && index < mergedKinds.length ? mergedKinds[index] : 1;
    }

    /** Entry point called from BagelOverlay.scanBlocks (every 8 ticks). */
    public static List<BlockTarget> scan(Minecraft mc) {
        try {
            return run(mc);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                BagelClient.LOGGER.warn("Bagel block ESP scan failed", t);
            }
            return merged;
        }
    }

    /** Replacement for BagelOverlay.moduleInt: ESP modules use the full render distance. */
    public static int moduleInt(String module, String key, int fallback) {
        if ("range".equals(key) && (module.equals("Entity ESP") || module.equals("Item ESP"))) {
            Minecraft mc = Minecraft.getInstance();
            return Math.max(32, mc.options.getEffectiveRenderDistance() * 16 + 16);
        }
        Module m = BagelClient.MODULES.byName(module);
        return m == null ? fallback : m.intSetting(key, fallback);
    }

    /** Replacement for BagelOverlay.containsId: "minecraft:shulker_box" also matches every dyed shulker box. */
    public static boolean containsId(String list, String id) {
        for (String entry : list.toLowerCase(Locale.ROOT).split(",")) {
            String t = entry.trim();
            if (t.equals(id)) {
                return true;
            }
            if (t.equals("minecraft:shulker_box") && id.endsWith("shulker_box")) {
                return true;
            }
        }
        return false;
    }

    private static boolean on(String name) {
        Module m = BagelClient.MODULES.byName(name);
        return m != null && m.enabled();
    }

    private static String list(String module, String key, String fallback) {
        Module m = BagelClient.MODULES.byName(module);
        return m == null ? fallback : m.stringSetting(key, fallback);
    }

    private static List<BlockTarget> run(Minecraft mc) {
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        boolean storage = on("Storage ESP");
        boolean blockEsp = on("Block ESP");
        boolean spawner = on("Spawner ESP");
        boolean highlights = on("Block Highlights");
        if (level == null || player == null || VanillaMode.active() || !(storage || blockEsp || spawner || highlights)) {
            CACHE.clear();
            KIND_CACHE.clear();
            merged = List.of();
            mergedKinds = new byte[0];
            signature = "";
            return merged;
        }

        int radius = Math.max(2, mc.options.getEffectiveRenderDistance());
        String storageList = storage ? list("Storage ESP", "blocks", "") : "";
        String blockList = blockEsp ? list("Block ESP", "blocks", "") : "";
        String highlightList = highlights ? list("Block Highlights", "blocks", "") : "";
        String spawnerFilter = spawner ? list("Spawner ESP", "filter", "*") : "";
        Module highlightModule = BagelClient.MODULES.byName("Block Highlights");
        exposedOnly = highlights && highlightModule != null && highlightModule.booleanSetting("only_exposed", false);
        String espText = blockEsp ? list("Block ESP", "color", "auto").trim() : "";
        espColor = espText.isEmpty() || espText.equalsIgnoreCase("auto") ? 0 : gg.bagel.client.extra.StorageColors.parse(espText, 0);
        String highlightText = highlights ? list("Block Highlights", "color", "#FF9E27") : "";
        highlightColor = gg.bagel.client.extra.StorageColors.parse(highlightText, HIGHLIGHT_COLOR);
        String sig = espText + "|" + highlightText + "|" + exposedOnly + "|" + storageList + "|" + blockList + "|" + highlightList + "|" + spawnerFilter + "|" + radius + "|" + (storage ? gg.bagel.client.extra.StorageColors.signature() : "");
        if (level != lastLevel || !sig.equals(signature)) {
            CACHE.clear();
            KIND_CACHE.clear();
            cursor = 0;
            lastLevel = level;
            signature = sig;
        }

        Set<Block> storageSet = storage ? resolve(storageList) : Set.of();
        Set<Block> blockSet = blockEsp ? resolve(blockList) : Set.of();
        Set<Block> highlightSet = highlights ? resolve(highlightList) : Set.of();
        Set<Block> union = new HashSet<>(storageSet);
        union.addAll(blockSet);
        union.addAll(highlightSet);

        int cx = player.blockPosition().getX() >> 4;
        int cz = player.blockPosition().getZ() >> 4;
        if (cx != orderX || cz != orderZ || radius != orderRadius) {
            rebuildOrder(cx, cz, radius);
        }

        long deadline = System.nanoTime() + BUDGET_NANOS;
        int done = 0;
        int total = order.size();
        while (done < total && System.nanoTime() < deadline) {
            long key = order.get(cursor % total);
            cursor++;
            done++;
            int x = (int) (key >> 32);
            int z = (int) key;
            kindSink = new ArrayList<>();
            CACHE.put(key, scanChunk(level, x, z, union, storageSet, blockSet, highlightSet, spawner, spawnerFilter));
            byte[] kinds = new byte[kindSink.size()];
            for (int k = 0; k < kinds.length; k++) {
                kinds[k] = kindSink.get(k);
            }
            KIND_CACHE.put(key, kinds);
        }
        if (cursor >= total) {
            cursor = 0;
        }

        List<BlockTarget> all = new ArrayList<>();
        List<Byte> allKinds = new ArrayList<>();
        for (long key : order) {
            List<BlockTarget> part = CACHE.get(key);
            byte[] kinds = KIND_CACHE.get(key);
            if (part != null && kinds != null && kinds.length == part.size()) {
                all.addAll(part);
                for (byte kind : kinds) {
                    allKinds.add(kind);
                }
                if (all.size() >= MAX_TARGETS) {
                    break;
                }
            }
        }
        byte[] flat = new byte[allKinds.size()];
        for (int k = 0; k < flat.length; k++) {
            flat[k] = allKinds.get(k);
        }
        merged = List.copyOf(all);
        mergedKinds = flat;
        return merged;
    }

    private static void rebuildOrder(int cx, int cz, int radius) {
        List<long[]> cells = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                cells.add(new long[] {(long) dx * dx + (long) dz * dz, pack(cx + dx, cz + dz)});
            }
        }
        cells.sort((a, b) -> Long.compare(a[0], b[0]));
        List<Long> next = new ArrayList<>(cells.size());
        Set<Long> keep = new HashSet<>();
        for (long[] cell : cells) {
            next.add(cell[1]);
            keep.add(cell[1]);
        }
        CACHE.keySet().retainAll(keep);
        KIND_CACHE.keySet().retainAll(keep);
        order = next;
        orderX = cx;
        orderZ = cz;
        orderRadius = radius;
        cursor = 0;
    }

    private static long pack(int x, int z) {
        return ((long) x << 32) | (z & 0xFFFFFFFFL);
    }

    private static List<BlockTarget> scanChunk(
            ClientLevel level,
            int cx,
            int cz,
            Set<Block> union,
            Set<Block> storageSet,
            Set<Block> blockSet,
            Set<Block> highlightSet,
            boolean spawner,
            String spawnerFilter) {
        LevelChunk chunk = level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (chunk == null) {
            return List.of();
        }
        List<BlockTarget> out = new ArrayList<>();

        if (!union.isEmpty()) {
            LevelChunkSection[] sections = chunk.getSections();
            int minSection = chunk.getMinSectionY();
            for (int i = 0; i < sections.length; i++) {
                LevelChunkSection section = sections[i];
                if (section == null || section.hasOnlyAir() || !section.maybeHas(s -> union.contains(s.getBlock()))) {
                    continue;
                }
                int baseY = (minSection + i) << 4;
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        for (int x = 0; x < 16; x++) {
                            BlockState state = section.getBlockState(x, y, z);
                            Block block = state.getBlock();
                            if (!union.contains(block)) {
                                continue;
                            }
                            BlockPos pos = new BlockPos((cx << 4) + x, baseY + y, (cz << 4) + z);
                            if (storageSet.contains(block)) {
                                Object[] d = gg.bagel.client.extra.StorageColors.describe(block);
                                out.add(new BlockTarget(pos, (Integer) d[0], (String) d[1]));
                                kindSink.add((byte) 0);
                            } else if (blockSet.contains(block)) {
                                String path = pathOf(block);
                                out.add(new BlockTarget(pos, espColor != 0 ? espColor : colorFor(path), path));
                                kindSink.add((byte) 1);
                            } else if (highlightSet.contains(block) && (!exposedOnly || exposed(level, pos))) {
                                out.add(new BlockTarget(pos, highlightColor, pathOf(block)));
                                kindSink.add((byte) 3);
                            }
                        }
                    }
                }
            }
        }

        if (spawner) {
            for (BlockEntity be : chunk.getBlockEntities().values()) {
                if (!(be instanceof SpawnerBlockEntity spawnerEntity)) {
                    continue;
                }
                BlockPos pos = be.getBlockPos();
                Entity display = spawnerEntity.getSpawner().getOrCreateDisplayEntity(level, pos);
                String mob = display == null ? "unknown" : BuiltInRegistries.ENTITY_TYPE.getKey(display.getType()).getPath();
                if (spawnerFilter.equals("*") || containsId(spawnerFilter, mob) || containsId(spawnerFilter, "minecraft:" + mob)) {
                    out.add(new BlockTarget(pos.immutable(), colorFor(mob), mob));
                    kindSink.add((byte) 2);
                }
            }
        }
        return out.isEmpty() ? List.of() : List.copyOf(out);
    }

    /** A block counts as exposed when at least one of its six neighbours is loaded air. */
    private static boolean exposed(ClientLevel level, BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockPos next = pos.relative(direction);
            if (level.hasChunkAt(next) && level.getBlockState(next).isAir()) {
                return true;
            }
        }
        return false;
    }

    private static String pathOf(Block block) {
        return BuiltInRegistries.BLOCK.getKey(block).getPath();
    }

    private static int colorFor(String id) {
        return 0xFF000000 | (id.hashCode() & 0xFFFFFF);
    }

    /**
     * Turns the comma separated id list into blocks. "minecraft:shulker_box" means every shulker box colour,
     * and an ore also covers its deepslate variant.
     */
    private static Set<Block> resolve(String list) {
        Set<Block> out = new HashSet<>();
        for (String raw : list.toLowerCase(Locale.ROOT).split(",")) {
            String id = raw.trim();
            if (id.isEmpty()) {
                continue;
            }
            if (!id.contains(":")) {
                id = "minecraft:" + id;
            }
            String namespace = id.substring(0, id.indexOf(':'));
            String path = id.substring(id.indexOf(':') + 1);
            Identifier identifier;
            try {
                identifier = Identifier.fromNamespaceAndPath(namespace, path);
            } catch (RuntimeException e) {
                continue;
            }
            Optional<Block> block = BuiltInRegistries.BLOCK.getOptional(identifier);
            block.ifPresent(out::add);
            if (id.equals("minecraft:shulker_box")) {
                for (Block candidate : BuiltInRegistries.BLOCK) {
                    if (pathOf(candidate).endsWith("shulker_box")) {
                        out.add(candidate);
                    }
                }
            }
            if (namespace.equals("minecraft") && path.endsWith("_ore") && !path.startsWith("deepslate_")) {
                BuiltInRegistries.BLOCK
                        .getOptional(Identifier.fromNamespaceAndPath(namespace, "deepslate_" + path))
                        .ifPresent(out::add);
            }
        }
        return out;
    }
}
