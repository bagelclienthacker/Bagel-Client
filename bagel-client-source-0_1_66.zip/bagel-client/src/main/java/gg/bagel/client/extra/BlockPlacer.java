/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/** Shared block placing for AutoWeb / AutoTrap: finds a face to click, aims silently, places, puts everything back. */
final class BlockPlacer {
    private BlockPlacer() {}

    static boolean replaceable(ClientLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.isAir() || state.canBeReplaced();
    }

    /** Nearest living other player within range (not spectating, not us). */
    static Player nearestPlayer(Minecraft mc, double range) {
        Player best = null;
        double bestDistance = range * range;
        for (Player other : mc.level.players()) {
            if (other == mc.player || !other.isAlive() || other.isSpectator()) {
                continue;
            }
            double d = other.distanceToSqr(mc.player);
            if (d < bestDistance) {
                bestDistance = d;
                best = other;
            }
        }
        return best;
    }

    static int findSlot(LocalPlayer player, Predicate<ItemStack> filter) {
        return Hotbar.find(player, filter);
    }

    /** Places the item in {@code slot} into {@code cell}. Returns true when a click was sent. */
    static boolean place(Minecraft mc, LocalPlayer player, ClientLevel level, BlockPos cell, int slot, double reach) {
        if (!replaceable(level, cell)) {
            return false;
        }
        Vec3 eyes = player.getEyePosition();
        for (Direction d : Direction.values()) {
            BlockPos support = cell.relative(d);
            if (replaceable(level, support) || level.getBlockState(support).getFluidState().isSource()) {
                continue;
            }
            Direction face = d.getOpposite();
            Vec3 hit = Vec3.atCenterOf(support).add(face.getStepX() * 0.5D, face.getStepY() * 0.5D, face.getStepZ() * 0.5D);
            if (eyes.distanceTo(hit) > reach) {
                continue;
            }
            int original = player.getInventory().getSelectedSlot();
            Hotbar.select(player, slot);
            Rotations.face(mc, player, hit);
            InteractionResult result = mc.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, support, false));
            player.swing(InteractionHand.MAIN_HAND);
            Rotations.restore(mc, player);
            Hotbar.selectAndSend(mc, player, original);
            return result.consumesAction();
        }
        return false;
    }
}
