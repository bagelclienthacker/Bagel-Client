/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * Color picker for the color settings (Block ESP, Block Highlights, Storage ESP): saturation/brightness square,
 * hue bar, hex box and preset swatches. Every change is written to the module setting straight away.
 */
public final class ColorPickerScreen extends Screen {
    private static final int PW = 240;
    private static final int PH = 196;
    private static final int SV = 104;
    private static final int[] PRESETS = {
        0xFF4040, 0xFF9020, 0xFFE040, 0x80FF40, 0x40D040, 0x40E0E0, 0x4070FF, 0xA050FF,
        0xFF80C0, 0xFF40FF, 0xFFFFFF, 0x8C8C8C, 0x101010, 0x9A6A3A, 0xFFC800, 0x00FFAA,
    };

    private final Screen parent;
    private final Module module;
    private final String key;
    private final String label;
    private final int fallback;
    private final boolean allowAuto;
    private final int original;
    private float hue;
    private float sat;
    private float val;
    private int drag;
    private boolean updatingHex;
    private EditBox hex;

    private ColorPickerScreen(Screen parent, Module module, String key, String label, int fallback, boolean allowAuto) {
        super(Component.literal(label));
        this.parent = parent;
        this.module = module;
        this.key = key;
        this.label = label;
        this.fallback = fallback & 0xFFFFFF;
        this.allowAuto = allowAuto;
        String current = module.stringSetting(key, "");
        this.original = StorageColors.parse(current, 0xFF000000 | this.fallback) & 0xFFFFFF;
        setRgb(original);
    }

    /** Opens the picker for a module setting. {@code allowAuto} adds an Auto button that stores the text "auto". */
    public static void open(Module module, String key, String label, int fallbackRgb, boolean allowAuto) {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreenAndShow(new ColorPickerScreen(mc.gui.screen(), module, key, label, fallbackRgb, allowAuto));
    }

    /** True when the click on this setting should open the picker instead of text editing. */
    public static boolean handle(Module module, String key) {
        if (module == null || key == null) {
            return false;
        }
        String name = module.name();
        if (name.equals("Block ESP") && key.equals("color")) {
            open(module, key, "Block ESP color", 0x40E0E0, true);
            return true;
        }
        if (name.equals("Block Highlights") && key.equals("color")) {
            open(module, key, "Block Highlights color", 0xFF9E27, false);
            return true;
        }
        if (name.equals(StorageColors.MODULE) && key.endsWith("_color")) {
            int fb = 0x8C8C8C;
            for (String[] d : StorageColors.DEFAULTS) {
                if (d[0].equals(key)) {
                    fb = StorageColors.parse(d[1], 0xFF8C8C8C) & 0xFFFFFF;
                }
            }
            open(module, key, pretty(key) + " color", fb, false);
            return true;
        }
        return false;
    }

    private static String pretty(String key) {
        String base = key.endsWith("_color") ? key.substring(0, key.length() - 6) : key;
        StringBuilder out = new StringBuilder();
        for (String part : base.split("_")) {
            if (part.isEmpty()) {
                continue;
            }
            if (out.length() > 0) {
                out.append(' ');
            }
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }

    // ---------------------------------------------------------------- colour maths

    private void setRgb(int rgb) {
        float r = ((rgb >> 16) & 255) / 255.0F;
        float g = ((rgb >> 8) & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h;
        if (d == 0.0F) {
            h = hue; // grey: keep the hue the bar already shows
        } else if (max == r) {
            h = (((g - b) / d) % 6.0F) / 6.0F;
        } else if (max == g) {
            h = (((b - r) / d) + 2.0F) / 6.0F;
        } else {
            h = (((r - g) / d) + 4.0F) / 6.0F;
        }
        if (h < 0.0F) {
            h += 1.0F;
        }
        hue = h;
        sat = max == 0.0F ? 0.0F : d / max;
        val = max;
    }

    private static int hsv(float h, float s, float v) {
        float hh = (h - (float) Math.floor(h)) * 6.0F;
        int i = (int) Math.floor(hh);
        float f = hh - i;
        float p = v * (1.0F - s);
        float q = v * (1.0F - s * f);
        float t = v * (1.0F - s * (1.0F - f));
        float r;
        float g;
        float b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        int ri = Math.round(r * 255.0F);
        int gi = Math.round(g * 255.0F);
        int bi = Math.round(b * 255.0F);
        return (ri << 16) | (gi << 8) | bi;
    }

    private int rgb() {
        return hsv(hue, sat, val);
    }

    private static String hexOf(int rgb) {
        return String.format(Locale.ROOT, "#%06X", rgb & 0xFFFFFF);
    }

    private void apply() {
        int rgb = rgb();
        module.setSetting(key, hexOf(rgb));
        syncHex(rgb);
    }

    private void syncHex(int rgb) {
        if (hex != null) {
            updatingHex = true;
            hex.setValue(hexOf(rgb));
            updatingHex = false;
        }
    }

    // ---------------------------------------------------------------- layout

    private int px() {
        return (this.width - PW) / 2;
    }

    private int py() {
        return (this.height - PH) / 2;
    }

    private int svX() {
        return px() + 12;
    }

    private int svY() {
        return py() + 30;
    }

    private int hueX() {
        return svX() + SV + 8;
    }

    private int rightX() {
        return hueX() + 14 + 10;
    }

    @Override
    protected void init() {
        int rx = rightX();
        int rw = px() + PW - 12 - rx;
        hex = new EditBox(this.font, rx, svY() + 40, rw, 18, Component.literal("Hex"));
        hex.setMaxLength(9);
        hex.setValue(hexOf(rgb()));
        hex.setResponder(text -> {
            if (updatingHex) {
                return;
            }
            String t = text.trim();
            if (t.startsWith("#")) {
                t = t.substring(1);
            }
            if (t.length() == 6) {
                int parsed = StorageColors.parse("#" + t, -1);
                if (parsed != -1) {
                    setRgb(parsed & 0xFFFFFF);
                    module.setSetting(key, hexOf(parsed & 0xFFFFFF));
                }
            }
        });
        this.addRenderableWidget(hex);

        int by = py() + PH - 26;
        int bx = px() + 12;
        int buttons = allowAuto ? 3 : 2;
        int gap = 6;
        int bw = (PW - 24 - gap * (buttons - 1)) / buttons;
        if (allowAuto) {
            this.addRenderableWidget(Button.builder(Component.literal("Auto"), b -> {
                module.setSetting(key, "auto");
                this.onClose();
            }).bounds(bx, by, bw, 20).build());
            bx += bw + gap;
        }
        this.addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
            setRgb(fallback);
            apply();
        }).bounds(bx, by, bw, 20).build());
        bx += bw + gap;
        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(bx, by, bw, 20).build());
    }

    // ---------------------------------------------------------------- drawing

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractBackground(g, mouseX, mouseY, delta);
        int px = px();
        int py = py();
        g.fill(px - 1, py - 1, px + PW + 1, py + PH + 1, 0xFFFF9E27);
        g.fill(px, py, px + PW, py + PH, 0xFF15151A);
        g.text(this.font, label, px + 12, py + 11, 0xFFFFFFFF);

        // saturation / brightness square for the current hue
        int sx = svX();
        int sy = svY();
        for (int cx = 0; cx < SV; cx += 2) {
            float s = cx / (float) (SV - 1);
            g.fillGradient(sx + cx, sy, sx + cx + 2, sy + SV, 0xFF000000 | hsv(hue, s, 1.0F), 0xFF000000);
        }
        g.outline(sx - 1, sy - 1, SV + 2, SV + 2, 0xFF555560);
        int cx = sx + Math.round(sat * (SV - 1));
        int cy = sy + Math.round((1.0F - val) * (SV - 1));
        g.outline(cx - 3, cy - 3, 7, 7, 0xFF000000);
        g.outline(cx - 2, cy - 2, 5, 5, 0xFFFFFFFF);

        // hue bar
        int hx = hueX();
        int seg = SV / 6;
        for (int i = 0; i < 6; i++) {
            int y0 = sy + i * seg;
            int y1 = i == 5 ? sy + SV : y0 + seg;
            g.fillGradient(hx, y0, hx + 14, y1, 0xFF000000 | hsv(i / 6.0F, 1.0F, 1.0F), 0xFF000000 | hsv((i + 1) / 6.0F, 1.0F, 1.0F));
        }
        g.outline(hx - 1, sy - 1, 16, SV + 2, 0xFF555560);
        int hy = sy + Math.round(hue * (SV - 1));
        g.fill(hx - 2, hy - 1, hx + 16, hy + 2, 0xFF000000);
        g.fill(hx - 1, hy, hx + 15, hy + 1, 0xFFFFFFFF);

        // preview: new on the left, what it was on the right
        int rx = rightX();
        int rw = px + PW - 12 - rx;
        g.fill(rx, sy, rx + rw / 2, sy + 30, 0xFF000000 | rgb());
        g.fill(rx + rw / 2, sy, rx + rw, sy + 30, 0xFF000000 | original);
        g.outline(rx - 1, sy - 1, rw + 2, 32, 0xFF555560);
        g.text(this.font, "new", rx + 3, sy + 34 - 24, textOn(rgb()));
        g.text(this.font, "old", rx + rw / 2 + 3, sy + 34 - 24, textOn(original));

        int r = (rgb() >> 16) & 255;
        int gr = (rgb() >> 8) & 255;
        int b = rgb() & 255;
        g.text(this.font, "R " + r + "  G " + gr + "  B " + b, rx, svY() + 64, 0xFFAAAAAA);

        // presets
        int perRow = 8;
        int cell = (PW - 24 + 4) / perRow;
        int top = sy + SV + 10;
        for (int i = 0; i < PRESETS.length; i++) {
            int x = px + 12 + (i % perRow) * cell;
            int y = top + (i / perRow) * 17;
            g.fill(x, y, x + cell - 4, y + 13, 0xFF000000 | PRESETS[i]);
            g.outline(x - 1, y - 1, cell - 2, 15, (rgb() == PRESETS[i]) ? 0xFFFFFFFF : 0xFF3A3A44);
        }
    }

    private static int textOn(int rgb) {
        int lum = (((rgb >> 16) & 255) * 30 + ((rgb >> 8) & 255) * 59 + (rgb & 255) * 11) / 100;
        return lum > 140 ? 0xFF000000 : 0xFFFFFFFF;
    }

    // ---------------------------------------------------------------- input

    private boolean inSv(double mx, double my) {
        return mx >= svX() && mx < svX() + SV && my >= svY() && my < svY() + SV;
    }

    private boolean inHue(double mx, double my) {
        return mx >= hueX() && mx < hueX() + 14 && my >= svY() && my < svY() + SV;
    }

    private void drag(double mx, double my) {
        if (drag == 1) {
            sat = (float) Math.max(0.0D, Math.min(1.0D, (mx - svX()) / (SV - 1)));
            val = 1.0F - (float) Math.max(0.0D, Math.min(1.0D, (my - svY()) / (SV - 1)));
            apply();
        } else if (drag == 2) {
            hue = (float) Math.max(0.0D, Math.min(0.9999D, (my - svY()) / (SV - 1)));
            apply();
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        double mx = event.x();
        double my = event.y();
        if (event.button() == 0) {
            if (inSv(mx, my)) {
                drag = 1;
                drag(mx, my);
                return true;
            }
            if (inHue(mx, my)) {
                drag = 2;
                drag(mx, my);
                return true;
            }
            int perRow = 8;
            int cell = (PW - 24 + 4) / perRow;
            int top = svY() + SV + 10;
            for (int i = 0; i < PRESETS.length; i++) {
                int x = px() + 12 + (i % perRow) * cell;
                int y = top + (i / perRow) * 17;
                if (mx >= x && mx < x + cell - 4 && my >= y && my < y + 13) {
                    setRgb(PRESETS[i]);
                    apply();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (drag != 0 && event.button() == 0) {
            drag(event.x(), event.y());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (drag != 0) {
            drag = 0;
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }
}
