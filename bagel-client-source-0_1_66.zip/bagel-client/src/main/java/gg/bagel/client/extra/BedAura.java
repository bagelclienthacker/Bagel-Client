/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Bed Aura (Nether and End only, where beds explode).
 *
 * <p>Rewritten on the same base as Crystal Aura: target by the "targeting" setting, blast damage from the shared
 * calculator (centered on the head of the bed, where it really explodes), silent aim in the normal movement packet and
 * hotbar swaps that go back after a short idle time. Placing a bed needs the server to know which way you face, so the
 * rotation is always sent first and the bed is only placed once the server has it.
 *
 * <p>Steps: place a bed next to the target, put a protective block between you and it when the blast would hurt you
 * too much, then detonate it.
 */
public final class BedAura extends Module {
    public static final String NAME = "Bed Aura";
    private static final Direction[] HORIZONTAL = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    private final SwapState swap = new SwapState();
    private BlockPos foot;
    private BlockPos head;
    private int shields;
    private int age;
    private int wait;

    public BedAura() {
        super(NAME, "Places a bed by a player, shields you, then blows it up", Category.COMBAT);
        setting("target_range", 6.0D);
        setting("place_range", 4.5D);
        setting("targeting", "Distance");
        setting("hurt_time", 10);
        setting("min_target_damage", 6.0D);
        setting("max_self_damage", 8.0D);
        setting("shield", Boolean.TRUE);
        setting("terrain", Boolean.TRUE);
        setting("step_delay", 2);
        setting("switch_back_delay", 10);
        setting("rotation", "silent");
        setting("entities", "minecraft:player");
    }

    @Override
    protected void onDisable(Minecraft mc) {
        swap.restore(mc, mc.player);
        reset();
        SilentAim.release();
    }

    private void reset() {
        foot = null;
        head = null;
        shields = 0;
        age = 0;
    }

    private boolean silent() {
        return !stringSetting("rotation", "silent").equalsIgnoreCase("none");
    }

    private boolean terrain() {
        return booleanSetting("terrain", true);
    }

    private double reach(LocalPlayer player) {
        double cap = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE) + 0.5D;
        return Math.min(Math.max(2.0D, doubleSetting("place_range", 4.5D)), cap);
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (!CombatUtil.canRun(mc, player)) {
            return;
        }
        String dimension = CombatUtil.dimension(mc);
        if (!dimension.equals("the_nether") && !dimension.equals("the_end")) {
            return;
        }
        boolean acted = false;
        if (wait > 0) {
            wait--;
        } else if (!player.isUsingItem() && !player.isShiftKeyDown() && !mc.gameMode.isDestroying() && !SilentAim.blocked(player)) {
            int delay = Math.max(0, Math.min(20, intSetting("step_delay", 2)));
            acted = foot != null ? followUp(mc, player, delay) : start(mc, player, delay);
        }
        swap.tick(mc, player, acted || foot != null, intSetting("switch_back_delay", 10));
    }

    // ------------------------------------------------------------------ place the bed

    private boolean start(Minecraft mc, LocalPlayer player, int delay) {
        InteractionHand hand = InteractionHand.MAIN_HAND;
        int slot = -1;
        if (isBed(player.getOffhandItem())) {
            hand = InteractionHand.OFF_HAND;
        } else {
            slot = Hotbar.find(player, BedAura::isBed);
            if (slot < 0) {
                return false;
            }
        }
        LivingEntity target = CombatUtil.pickTarget(this, mc, player, Math.max(2.0D, doubleSetting("target_range", 6.0D)), Math.max(0, intSetting("hurt_time", 10)));
        if (target == null) {
            return false;
        }
        Plan plan = bestPlan(mc, player, target);
        if (plan == null) {
            return false;
        }
        BlockPos support = plan.foot.below();
        if (silent()) {
            SilentAim.aim(mc, player, plan.facing.toYRot(), 35.0F);
            if (!SilentAim.ready(player, SilentAim.wantedYaw(), SilentAim.wantedPitch(), 2.0F)) {
                return true; // the server has to know which way we face before the bed goes down
            }
        }
        if (slot >= 0) {
            swap.take(player, slot);
        }
        Vec3 click = new Vec3(support.getX() + 0.5D, support.getY() + 1.0D, support.getZ() + 0.5D);
        InteractionResult result = mc.gameMode.useItemOn(player, hand, new BlockHitResult(click, Direction.UP, support, false));
        if (!result.consumesAction()) {
            return false;
        }
        player.swing(hand);
        foot = plan.foot;
        head = plan.foot.relative(plan.facing);
        shields = 0;
        age = 0;
        wait = delay;
        return true;
    }

    private static boolean isBed(ItemStack stack) {
        return !stack.isEmpty() && Hotbar.path(stack).endsWith("_bed");
    }

    // ------------------------------------------------------------------ shield and detonate

    /** The bed is down: shield if needed, then detonate. */
    private boolean followUp(Minecraft mc, LocalPlayer player, int delay) {
        age++;
        ClientLevel level = mc.level;
        BlockState state = level.getBlockState(head);
        if (!(state.getBlock() instanceof BedBlock) && !(level.getBlockState(foot).getBlock() instanceof BedBlock)) {
            if (age > 15) {
                reset();
            }
            return false;
        }
        Vec3 center = Vec3.atCenterOf(head);
        double maxSelf = Math.max(0.0D, doubleSetting("max_self_damage", 8.0D));
        float self = Explosions.damage(level, center, Explosions.BED, player, terrain(), foot, head);
        if (self > maxSelf || self >= Explosions.health(player) - 1.0F) {
            if (booleanSetting("shield", true) && shields < 3) {
                shields++;
                if (placeShield(mc, player)) {
                    wait = delay;
                    return true;
                }
            }
            if (age > 30) {
                reset();
            }
            return false;
        }
        if (!worthIt(mc, player, center) && age < 20) {
            return false;
        }
        if (player.getEyePosition().distanceTo(center) > reach(player)) {
            if (age > 30) {
                reset();
            }
            return false;
        }
        Direction face = Direction.getApproximateNearest(
                player.getEyePosition().x - center.x, player.getEyePosition().y - center.y, player.getEyePosition().z - center.z);
        Vec3 click = center.add(face.getStepX() * 0.5D, face.getStepY() * 0.5D, face.getStepZ() * 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            return true;
        }
        mc.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, new BlockHitResult(click, face, head, false));
        player.swing(InteractionHand.MAIN_HAND);
        reset();
        wait = delay;
        return true;
    }

    /** Is any valid target still close enough to be hurt by the bed? */
    private boolean worthIt(Minecraft mc, LocalPlayer player, Vec3 center) {
        double min = Math.max(0.0D, doubleSetting("min_target_damage", 6.0D)) * 0.5D;
        double range = Math.max(2.0D, doubleSetting("target_range", 6.0D)) + 3.0D;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (CombatUtil.validTarget(this, player, entity, range, 10)
                    && Explosions.damage(mc.level, center, Explosions.BED, (LivingEntity) entity, terrain(), foot, head) >= min) {
                return true;
            }
        }
        return false;
    }

    private boolean placeShield(Minecraft mc, LocalPlayer player) {
        int slot = Hotbar.find(player, s -> s.is(Items.OBSIDIAN));
        if (slot < 0) {
            slot = Hotbar.find(player, BedAura::protectiveBlock);
        }
        if (slot < 0) {
            return false;
        }
        double reach = reach(player);
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        for (BlockPos part : new BlockPos[] {foot, head}) {
            for (Direction direction : HORIZONTAL) {
                BlockPos cell = part.relative(direction);
                if (cell.equals(foot) || cell.equals(head) || !replaceable(mc.level, cell) || !sturdyTop(mc.level, cell.below())) {
                    continue;
                }
                if (intersectsEntity(mc.level, cell, null)) {
                    continue;
                }
                Vec3 face = Vec3.atCenterOf(cell.below()).add(0.0D, 0.5D, 0.0D);
                double distance = player.getEyePosition().distanceTo(face);
                double toPlayer = Vec3.atCenterOf(cell).distanceToSqr(player.position());
                if (distance <= reach && toPlayer < bestDistance) {
                    bestDistance = toPlayer;
                    best = cell;
                }
            }
        }
        if (best == null) {
            return false;
        }
        BlockPos support = best.below();
        Vec3 click = new Vec3(support.getX() + 0.5D, support.getY() + 1.0D, support.getZ() + 0.5D);
        if (!CombatUtil.aimed(mc, player, stringSetting("rotation", "silent"), click)) {
            shields--; // still turning: this attempt does not count
            return true;
        }
        swap.take(player, slot);
        InteractionResult result = mc.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, new BlockHitResult(click, Direction.UP, support, false));
        player.swing(InteractionHand.MAIN_HAND);
        return result.consumesAction();
    }

    private static boolean protectiveBlock(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem item)) {
            return false;
        }
        if (item.getBlock() instanceof FallingBlock || item.getBlock() instanceof BedBlock) {
            return false;
        }
        String path = Hotbar.path(stack);
        return path.equals("crying_obsidian") || path.equals("netherrack") || path.equals("cobblestone")
                || path.equals("stone") || path.equals("end_stone") || path.equals("blackstone")
                || path.equals("cobbled_deepslate") || path.equals("dirt");
    }

    // ------------------------------------------------------------------ planning

    private record Plan(BlockPos foot, Direction facing, double score) {}

    private Plan bestPlan(Minecraft mc, LocalPlayer player, LivingEntity target) {
        ClientLevel level = mc.level;
        double reach = reach(player);
        double minTarget = Math.max(0.0D, doubleSetting("min_target_damage", 6.0D));
        double maxSelf = Math.max(0.0D, doubleSetting("max_self_damage", 8.0D));
        boolean shield = booleanSetting("shield", true);
        boolean freeFacing = silent();
        BlockPos base = target.blockPosition();
        List<Plan> candidates = new ArrayList<>();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    BlockPos f = base.offset(dx, dy, dz);
                    if (!replaceable(level, f) || !sturdyTop(level, f.below())) {
                        continue;
                    }
                    Vec3 face = Vec3.atCenterOf(f.below()).add(0.0D, 0.5D, 0.0D);
                    if (player.getEyePosition().distanceTo(face) > reach) {
                        continue;
                    }
                    for (Direction d : HORIZONTAL) {
                        if (!freeFacing && d != player.getDirection()) {
                            continue;
                        }
                        BlockPos h = f.relative(d);
                        if (!replaceable(level, h) || !sturdyTop(level, h.below())) {
                            continue;
                        }
                        if (intersectsEntity(level, f, h)) {
                            continue;
                        }
                        candidates.add(new Plan(f, d, Vec3.atCenterOf(h).distanceToSqr(target.position())));
                        break;
                    }
                }
            }
        }
        candidates.sort(Comparator.comparingDouble(Plan::score));
        Plan best = null;
        double bestScore = -Double.MAX_VALUE;
        int checked = 0;
        for (Plan candidate : candidates) {
            if (checked++ >= 10) {
                break;
            }
            BlockPos h = candidate.foot.relative(candidate.facing);
            Vec3 center = Vec3.atCenterOf(h);
            float targetDamage = Explosions.damage(level, center, Explosions.BED, target, terrain(), candidate.foot, h);
            if (targetDamage < minTarget && targetDamage < Explosions.health(target)) {
                continue;
            }
            float selfDamage = Explosions.damage(level, center, Explosions.BED, player, terrain(), candidate.foot, h);
            if ((selfDamage > maxSelf || selfDamage >= Explosions.health(player) - 1.0F) && !shield) {
                continue;
            }
            double score = targetDamage - Math.min(selfDamage, maxSelf) * 0.6D;
            if (score > bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        return best;
    }

    private static boolean replaceable(ClientLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.isAir() || state.canBeReplaced();
    }

    private static boolean sturdyTop(ClientLevel level, BlockPos pos) {
        return level.getBlockState(pos).isFaceSturdy(level, pos, Direction.UP);
    }

    private static boolean intersectsEntity(ClientLevel level, BlockPos a, BlockPos b) {
        AABB box = new AABB(a);
        if (b != null) {
            box = box.minmax(new AABB(b));
        }
        return !level.getEntities((Entity) null, box, e -> e.isAlive() && !e.isSpectator()).isEmpty();
    }
}
