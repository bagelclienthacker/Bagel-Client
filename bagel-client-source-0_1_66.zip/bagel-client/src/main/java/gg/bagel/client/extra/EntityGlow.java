/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import gg.bagel.client.render.BagelEsp;
import gg.bagel.client.render.BagelScan;
import gg.bagel.client.util.VanillaMode;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/** Entity ESP "highlight" style: the vanilla glow outline (shows through walls), no box and no text. */
public final class EntityGlow {
    private static final int PLAYER_COLOR = 0xFF5555;
    private static final int MOB_COLOR = 0xFFAA00;

    private EntityGlow() {}

    public static boolean highlightStyle() {
        Module m = BagelClient.MODULES.byName("Entity ESP");
        return m != null && m.enabled() && !"box".equalsIgnoreCase(m.stringSetting("style", "highlight").trim());
    }

    public static boolean wants(Entity entity) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null || entity == mc.player || !(entity instanceof LivingEntity)) {
                return false;
            }
            if (VanillaMode.active() || !highlightStyle()) {
                return false;
            }
            int range = BagelScan.moduleInt("Entity ESP", "range", 48);
            if (entity.distanceToSqr(mc.player) > (double) range * range) {
                return false;
            }
            return BagelEsp.entityPasses(entity);
        } catch (Throwable t) {
            return false;
        }
    }

    public static int color(Entity entity) {
        return entity instanceof Player ? PLAYER_COLOR : MOB_COLOR;
    }
}
