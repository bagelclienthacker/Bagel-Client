/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import gg.bagel.client.util.WaypointStore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

/** Called from ModuleRegistry.tick (patched) for module binds and the Waypoints save key. */
public final class WaypointHooks {
    private WaypointHooks() {}

    /** A module bind was pressed. Binds do nothing while a screen (chat, inventory, menus) is open. */
    public static void bind(Module module, Minecraft mc) {
        if (mc.gui.screen() != null) {
            return;
        }
        if (module.name().equals("Waypoints")) {
            if (mc.player != null) {
                saveKey(mc.player);
            }
            return;
        }
        module.toggle(mc);
    }

    /** The Waypoints "save key" was pressed. */
    public static void saveKey(LocalPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui.screen() != null || mc.level == null) {
            return;
        }
        WaypointStore.save(player);
        java.util.List<WaypointStore.Waypoint> all = WaypointStore.all();
        WaypointStore.Waypoint w = all.get(all.size() - 1);
        mc.gui.hud.setOverlayMessage(Component.literal("Saved " + w.name() + "  " + Math.round(w.x()) + " " + Math.round(w.y()) + " " + Math.round(w.z())).withColor(0xFFB347), false);
    }
}
