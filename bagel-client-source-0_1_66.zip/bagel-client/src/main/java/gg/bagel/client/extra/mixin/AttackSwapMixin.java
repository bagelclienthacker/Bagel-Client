/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.extra.AttributeSwap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Attribute Swap hooks around every attack. */
@Mixin(MultiPlayerGameMode.class)
public abstract class AttackSwapMixin {
    @Inject(method = "attack", at = @At("HEAD"), require = 0)
    private void bagel$swapBefore(Player player, Entity target, CallbackInfo ci) {
        AttributeSwap.before(Minecraft.getInstance(), player);
    }

    @Inject(method = "attack", at = @At("RETURN"), require = 0)
    private void bagel$swapAfter(Player player, Entity target, CallbackInfo ci) {
        AttributeSwap.after(Minecraft.getInstance());
    }
}
