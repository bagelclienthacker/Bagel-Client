/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.CameraRig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Freecam: what you hit / place / interact with is picked from your real player's view by default
 * (Freecam setting click_from = player), or from the flying camera (click_from = camera).
 */
@Mixin(Minecraft.class)
public abstract class FreecamPickMixin {
    @Redirect(method = "pick",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;getCameraEntity()Lnet/minecraft/world/entity/Entity;", ordinal = 0),
            require = 0)
    private Entity bagel$pickFrom(Minecraft self) {
        if (CameraRig.mode() == CameraRig.Mode.FREECAM && self.player != null) {
            Module freecam = BagelClient.MODULES.byName("Freecam");
            if (freecam == null || !"camera".equalsIgnoreCase(freecam.stringSetting("click_from", "player").trim())) {
                return self.player;
            }
        }
        return self.getCameraEntity();
    }
}
