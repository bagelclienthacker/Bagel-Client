/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.extra.AntiHunger;
import net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Anti Hunger packet hooks. */
@Mixin(ClientCommonPacketListenerImpl.class)
public abstract class AntiHungerMixin {
    @Inject(method = "send", at = @At("HEAD"), cancellable = true, require = 0)
    private void bagel$antiHunger(Packet<?> packet, CallbackInfo ci) {
        if (AntiHunger.drop(packet)) {
            ci.cancel();
            return;
        }
        Packet<?> replacement = AntiHunger.rewrite(packet);
        if (replacement != null) {
            ((ClientCommonPacketListenerImpl) (Object) this).send(replacement);
            ci.cancel();
        }
    }
}
