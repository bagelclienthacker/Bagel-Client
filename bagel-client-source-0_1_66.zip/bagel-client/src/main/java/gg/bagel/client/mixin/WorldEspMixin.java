/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.mixin;

import gg.bagel.client.render.WorldEsp;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Submits the see-through ESP boxes after the level's features were submitted. */
@Mixin(LevelRenderer.class)
public abstract class WorldEspMixin {
    @Inject(method = "submitFeatures", at = @At("TAIL"))
    private void bagel$submitEspOutlines(LevelRenderState state, SubmitNodeCollector collector, boolean flag, CallbackInfo ci) {
        WorldEsp.submit(state, collector);
    }
}
