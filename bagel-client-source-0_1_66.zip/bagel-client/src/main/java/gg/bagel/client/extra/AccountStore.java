/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Saved accounts (config/bagel/accounts.tsv). Microsoft entries keep only a refresh token, never a password. */
public final class AccountStore {
    public record Account(String type, String name, String uuid, String secret) {
        public boolean microsoft() {
            return type.equals("microsoft");
        }
    }

    private static final List<Account> ACCOUNTS = new ArrayList<>();
    private static boolean loaded;

    private AccountStore() {}

    private static Path file() {
        return BagelClient.gameDirectory().resolve("config/bagel/accounts.tsv");
    }

    public static synchronized List<Account> all() {
        load();
        return List.copyOf(ACCOUNTS);
    }

    private static void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        try {
            if (Files.isRegularFile(file())) {
                for (String line : Files.readAllLines(file(), StandardCharsets.UTF_8)) {
                    String[] p = line.split("\t", -1);
                    if (p.length >= 3 && !p[1].isBlank()) {
                        ACCOUNTS.add(new Account(p[0], p[1], p[2], p.length > 3 ? p[3] : ""));
                    }
                }
            }
        } catch (IOException e) {
            BagelClient.LOGGER.warn("Could not read Bagel accounts", e);
        }
    }

    private static void save() {
        try {
            Files.createDirectories(file().getParent());
            List<String> lines = new ArrayList<>();
            for (Account a : ACCOUNTS) {
                lines.add(a.type() + "\t" + a.name() + "\t" + a.uuid() + "\t" + a.secret());
            }
            Files.write(file(), lines, StandardCharsets.UTF_8);
            try {
                Files.setPosixFilePermissions(file(), PosixFilePermissions.fromString("rw-------"));
            } catch (Exception ignored) {
            }
        } catch (IOException e) {
            BagelClient.LOGGER.warn("Could not save Bagel accounts", e);
        }
    }

    public static synchronized void add(Account account) {
        load();
        ACCOUNTS.removeIf(a -> a.type().equals(account.type()) && a.name().equalsIgnoreCase(account.name()));
        ACCOUNTS.add(account);
        save();
    }

    public static synchronized void remove(Account account) {
        load();
        ACCOUNTS.remove(account);
        save();
    }

    public static Account offline(String name) {
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        return new Account("offline", name, uuid.toString(), "");
    }

    /** Application (client) ID for Microsoft sign-in. Read from config/bagel/microsoft_client_id.txt. */
    public static String clientId() {
        try {
            Path p = BagelClient.gameDirectory().resolve("config/bagel/microsoft_client_id.txt");
            if (Files.isRegularFile(p)) {
                return Files.readString(p, StandardCharsets.UTF_8).trim();
            }
        } catch (IOException ignored) {
        }
        return "";
    }

    public static Path clientIdFile() {
        return BagelClient.gameDirectory().resolve("config/bagel/microsoft_client_id.txt");
    }
}
