/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Attribute swap: when you hit something while holding a spear, the server briefly sees another weapon
 * in your hand (selected before the hit, restored right after, all in the same tick).
 */
public final class AttributeSwap extends Module {
    public static final String NAME = "Attribute Swap";
    /** Set while another module is doing its own swapping so we do not nest. */
    static boolean busy;
    private static int saved = -1;

    public AttributeSwap() {
        super(NAME, "Swap to a weapon for the hit while holding a spear", Category.COMBAT);
        setting("weapon", "auto");
        setting("any_item", Boolean.FALSE);
    }

    /** Called from the attack mixin before the attack packet is sent. */
    public static void before(Minecraft mc, Player attacker) {
        saved = -1;
        if (busy || !(attacker instanceof LocalPlayer player) || player != mc.player) {
            return;
        }
        Module module = BagelClient.MODULES.byName(NAME);
        if (module == null || !module.enabled() || VanillaMode.active()) {
            return;
        }
        ItemStack held = player.getMainHandItem();
        if (!module.booleanSetting("any_item", false) && !Hotbar.isSpear(held)) {
            return;
        }
        int current = player.getInventory().getSelectedSlot();
        int slot = pick(player, module.stringSetting("weapon", "auto").trim().toLowerCase(Locale.ROOT), current);
        if (slot < 0 || slot == current) {
            return;
        }
        saved = current;
        Hotbar.select(player, slot);
    }

    /** Called from the attack mixin once the attack has been sent. */
    public static void after(Minecraft mc) {
        if (saved < 0 || mc.player == null) {
            saved = -1;
            return;
        }
        Hotbar.selectAndSend(mc, mc.player, saved);
        saved = -1;
    }

    private static int pick(LocalPlayer player, String weapon, int current) {
        int mace = Hotbar.find(player, Hotbar::isMace);
        int axe = Hotbar.find(player, Hotbar::isAxe);
        int sword = Hotbar.find(player, Hotbar::isSword);
        int slot = switch (weapon) {
            case "mace" -> mace;
            case "axe" -> axe;
            case "sword" -> sword;
            default -> mace >= 0 ? mace : axe >= 0 ? axe : sword;
        };
        return slot == current ? -1 : slot;
    }
}
