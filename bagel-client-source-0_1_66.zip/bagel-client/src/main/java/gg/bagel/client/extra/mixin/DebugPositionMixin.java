/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.extra.FakeCoords;
import net.minecraft.client.gui.components.debug.DebugEntryPosition;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Fake Coordinates on the F3 "XYZ", "Block" and "Chunk" lines. */
@Mixin(DebugEntryPosition.class)
public abstract class DebugPositionMixin {
    @Redirect(method = "display", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getX()D"), require = 0)
    private double bagel$x(Entity entity) {
        return FakeCoords.x(entity);
    }

    @Redirect(method = "display", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getZ()D"), require = 0)
    private double bagel$z(Entity entity) {
        return FakeCoords.z(entity);
    }

    @Redirect(method = "display", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;blockPosition()Lnet/minecraft/core/BlockPos;"), require = 0)
    private BlockPos bagel$blockPos(Entity entity) {
        return FakeCoords.blockPos(entity);
    }
}
