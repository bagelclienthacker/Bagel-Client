/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Mace Aura: smashes a target with the mace while you fall onto it.
 *
 * <p>Rewritten like the other combat modules: the target is picked by the "targeting" setting, the aim goes into the
 * normal movement packet (no extra packets, camera untouched), the hit only happens once the server has seen that
 * rotation, and the mace is swapped in and out with plain hotbar packets. Stun slam hits a blocking target with an axe
 * first so the shield is down for the smash.
 */
public final class MaceAura extends Module {
    public static final String NAME = "Mace Aura";
    private static final float AIM_TOLERANCE = 4.0F;
    private static final double MIN_SMASH_FALL = 1.5D;

    private final SwapState swap = new SwapState();
    private int cooldown;
    private int aimTicks;
    private boolean armed;

    public MaceAura() {
        super(NAME, "Auto mace smash after falling", Category.COMBAT);
        setting("range", 3.5D);
        setting("min_fall", 3.0D);
        setting("stun_slam", Boolean.FALSE);
        setting("rotation", "silent");
        setting("targeting", "Distance");
        setting("entities", "minecraft:player");
        setting("hurt_time", 10);
        setting("require_visible", Boolean.TRUE);
        setting("ignore_cooldown", Boolean.TRUE);
        setting("attack_delay_ticks", 10);
    }

    @Override
    protected void onDisable(Minecraft mc) {
        aimTicks = 0;
        armed = false;
        swap.restore(mc, mc.player);
        SilentAim.release();
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (!CombatUtil.canRun(mc, player)) {
            return;
        }
        swap.tick(mc, player, armed, 15);
        armed = false;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (SilentAim.blocked(player) || player.isUsingItem() || mc.gameMode.isDestroying()) {
            return;
        }
        double minFall = Math.max(MIN_SMASH_FALL, doubleSetting("min_fall", 3.0D));
        if (player.onGround() || player.isFallFlying() || player.isInWater() || player.fallDistance < minFall) {
            aimTicks = 0;
            return;
        }
        int mace = Hotbar.find(player, Hotbar::isMace);
        if (mace < 0) {
            return;
        }
        double reach = Math.min(Math.max(1.0D, doubleSetting("range", 3.5D)), player.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE) + 1.0D);
        LivingEntity target = pickTarget(mc, player, reach);
        if (target == null) {
            aimTicks = 0;
            return;
        }
        boolean ignoreCooldown = booleanSetting("ignore_cooldown", true);
        if (!ignoreCooldown) {
            // wait for the full weapon cooldown: hold the mace while falling so the cooldown can charge
            armed = true;
            if (player.getInventory().getSelectedSlot() != mace) {
                swap.take(player, mace);
                Hotbar.selectAndSend(mc, player, mace);
                return;
            }
            if (player.getAttackStrengthScale(0.5F) < 0.95F) {
                return;
            }
        }
        Vec3 point = Rotations.aimAt(player, target, "body");
        boolean silent = !stringSetting("rotation", "silent").equalsIgnoreCase("none");
        if (silent) {
            float[] want = KillAura.anglesTo(player.getEyePosition(), point);
            SilentAim.aim(mc, player, want[0], want[1]);
            // the packet with this rotation goes out next tick; give up waiting after a few ticks and swing anyway
            if (!SilentAim.ready(player, SilentAim.wantedYaw(), SilentAim.wantedPitch(), AIM_TOLERANCE) && aimTicks++ < 4) {
                return;
            }
        }
        smash(mc, player, target, mace, ignoreCooldown);
        aimTicks = 0;
        cooldown = Math.max(1, Math.min(40, intSetting("attack_delay_ticks", 10)));
    }

    private void smash(Minecraft mc, LocalPlayer player, LivingEntity target, int mace, boolean swapBack) {
        int original = player.getInventory().getSelectedSlot();
        AttributeSwap.busy = true;
        try {
            int axe = Hotbar.find(player, Hotbar::isAxe);
            if (swapBack && booleanSetting("stun_slam", false) && axe >= 0 && target.isBlocking()) {
                Hotbar.select(player, axe);
                mc.gameMode.attack(player, target);
                player.swing(InteractionHand.MAIN_HAND);
            }
            Hotbar.select(player, mace);
            mc.gameMode.attack(player, target);
            player.swing(InteractionHand.MAIN_HAND);
            if (swapBack) {
                Hotbar.selectAndSend(mc, player, original);
            }
        } finally {
            AttributeSwap.busy = false;
        }
    }

    private LivingEntity pickTarget(Minecraft mc, LocalPlayer player, double reach) {
        String mode = stringSetting("targeting", "Distance").trim().toLowerCase(Locale.ROOT);
        int maxHurt = Math.max(0, intSetting("hurt_time", 10));
        boolean visible = booleanSetting("require_visible", true);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (net.minecraft.world.entity.Entity entity : mc.level.entitiesForRendering()) {
            if (!CombatUtil.validTarget(this, player, entity, reach + 3.0D, maxHurt)) {
                continue;
            }
            LivingEntity living = (LivingEntity) entity;
            Vec3 point = Rotations.aimAt(player, living, "closest");
            if (CombatUtil.reachTo(player, living) > reach) {
                continue;
            }
            if (visible && !clear(mc, player, point)) {
                continue;
            }
            double score;
            switch (mode) {
                case "hp":
                    score = Explosions.health(living);
                    break;
                case "fov":
                    score = CombatUtil.angleToLook(player, living.getBoundingBox().getCenter());
                    break;
                default:
                    score = CombatUtil.reachTo(player, living);
                    break;
            }
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private static boolean clear(Minecraft mc, LocalPlayer player, Vec3 point) {
        BlockHitResult hit = mc.level.clip(new ClipContext(player.getEyePosition(), point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.MISS || hit.getLocation().distanceToSqr(point) < 0.01D;
    }
}
