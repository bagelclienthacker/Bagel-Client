/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Module search that looks through every category instead of just the one you are in. */
public final class SearchFix {
    private SearchFix() {}

    public static List<Module> visible(String search, Category current) {
        String q = search == null ? "" : search.toLowerCase(Locale.ROOT).trim();
        List<Module> out = new ArrayList<>();
        for (Module module : BagelClient.MODULES.all()) {
            if (q.isEmpty()) {
                if (module.category() == current) {
                    out.add(module);
                }
                continue;
            }
            if (module.name().toLowerCase(Locale.ROOT).contains(q)
                    || module.description().toLowerCase(Locale.ROOT).contains(q)
                    || module.category().name().toLowerCase(Locale.ROOT).contains(q)) {
                out.add(module);
            }
        }
        return out;
    }
}
