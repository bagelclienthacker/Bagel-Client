/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import net.minecraft.client.Minecraft;

/** Click it in the RShift menu to open the training dummy. */
public final class HitDummy extends Module {
    public static final String NAME = "Hit the Dummy";

    public HitDummy() {
        super(NAME, "Click to open: hit a dummy wearing any player's skin with swords, maces, bows and more", Category.MISC);
    }

    @Override
    protected void onEnable(Minecraft mc) {
        mc.execute(() -> {
            setEnabled(false, mc);
            DummyScreen.open();
        });
    }
}
