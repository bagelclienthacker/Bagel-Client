/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import com.mojang.blaze3d.platform.NativeImage;
import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Properties;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

/** Local Skin: skins from config/bagel/skins/*.png, or copied from another player who is online. */
public final class SkinStore {
    public static final String MODULE = "Local Skin";
    private static final Map<String, Identifier> TEXTURES = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();
    private static PlayerSkin copied;
    private static String copiedFor = "";
    private static long nextLookup;
    private static long nextLegacyCheck;
    private static boolean legacyPresent;
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10)).build();
    /** Shown in the picker; revision changes when the file list changes in the background. */
    public static volatile String status = "";
    public static volatile int revision;

    private SkinStore() {}

    private static Path folderCache;

    public static Path folder() {
        if (folderCache != null) {
            return folderCache;
        }
        Path dir = BagelClient.gameDirectory().resolve("config/bagel/skins");
        try {
            Files.createDirectories(dir);
            Path legacy = BagelClient.gameDirectory().resolve("config/bagel/skin.png");
            Path moved = dir.resolve("skin.png");
            if (Files.isRegularFile(legacy) && !Files.exists(moved)) {
                Files.copy(legacy, moved, StandardCopyOption.COPY_ATTRIBUTES);
            }
        } catch (Exception ignored) {
        }
        folderCache = dir;
        return dir;
    }

    /** Puts the default Steve skin into the saved skins folder (once). */
    public static void ensureSteve() {
        try {
            Path target = folder().resolve("Steve.png");
            if (Files.exists(target)) {
                return;
            }
            Identifier id = Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png");
            java.util.Optional<net.minecraft.server.packs.resources.Resource> resource =
                    Minecraft.getInstance().getResourceManager().getResource(id);
            if (resource.isEmpty()) {
                return;
            }
            try (InputStream in = resource.get().open()) {
                Files.copy(in, target);
            }
            Properties p = models();
            p.setProperty("Steve.png", "wide");
            saveModels(p);
        } catch (Throwable ignored) {
        }
    }

    public static List<String> files() {
        ensureSteve();
        try (Stream<Path> stream = Files.list(folder())) {
            return stream.map(p -> p.getFileName().toString())
                    .filter(n -> n.toLowerCase(Locale.ROOT).endsWith(".png"))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
        } catch (Exception e) {
            return List.of();
        }
    }

    private static Module module() {
        return BagelClient.MODULES.byName(MODULE);
    }

    public static String source() {
        Module m = module();
        return m == null ? "" : m.stringSetting("source", "");
    }

    private static boolean settingSlim() {
        Module m = module();
        return m != null && m.stringSetting("model", "wide").equalsIgnoreCase("slim");
    }

    private static Path modelsFile() {
        return folder().resolve("models.properties");
    }

    private static Properties modelCache;

    private static Properties models() {
        if (modelCache != null) {
            return modelCache;
        }
        Properties p = new Properties();
        try {
            if (Files.isRegularFile(modelsFile())) {
                try (InputStream in = Files.newInputStream(modelsFile())) {
                    p.load(in);
                }
            }
        } catch (Exception ignored) {
        }
        modelCache = p;
        return p;
    }

    private static void saveModels(Properties p) {
        modelCache = p;
        try (java.io.OutputStream out = Files.newOutputStream(modelsFile())) {
            p.store(out, "Arm model per skin file (wide or slim)");
        } catch (Exception ignored) {
        }
    }

    private static String currentFile() {
        String source = source();
        return source.startsWith("file:") ? source.substring("file:".length()) : null;
    }

    /** Arm model of the skin in use: remembered per file, otherwise the module setting. */
    public static boolean slim() {
        String file = currentFile();
        if (file != null) {
            String saved = models().getProperty(file);
            if (saved != null) {
                return saved.equalsIgnoreCase("slim");
            }
        }
        return settingSlim();
    }

    private static void store(String key, String value) {
        Module m = module();
        if (m == null) {
            return;
        }
        m.setSetting(key, value);
        if (!m.enabled()) {
            m.setEnabled(true, Minecraft.getInstance());
        }
        BagelClient.MODULES.saveConfig();
    }

    public static void useFile(String name) {
        store("source", "file:" + name);
    }

    /** Saves the player's skin as a PNG in the skins folder and starts using it. */
    public static void copyPlayer(String name) {
        PlayerInfo info = Names.info(name);
        if (info == null) {
            status = name + " is not online";
            revision++;
            return;
        }
        PlayerSkin skin = info.getSkin();
        boolean slim = skin.model() == PlayerModelType.SLIM;
        if (skin.body() instanceof ClientAsset.DownloadedTexture downloaded) {
            status = "Downloading " + name + "'s skin...";
            revision++;
            String url = downloaded.url();
            String file = name.replaceAll("[^A-Za-z0-9_.-]", "_") + ".png";
            Thread t = new Thread(() -> download(url, file, slim), "Bagel-Skin-Download");
            t.setDaemon(true);
            t.start();
        } else {
            copied = null;
            copiedFor = "";
            nextLookup = 0;
            store("source", "player:" + name);
            status = name + " uses a built-in skin, copied live (nothing to save)";
            revision++;
        }
    }

    private static void download(String url, String file, boolean slim) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(20)).GET().build();
            byte[] bytes = HTTP.send(request, HttpResponse.BodyHandlers.ofByteArray()).body();
            if (bytes.length < 64 || bytes.length > 200_000) {
                throw new IllegalStateException("unexpected skin size");
            }
            NativeImage image = NativeImage.read(bytes);
            NativeImage ready = toModern(image);
            Path target = folder().resolve(file);
            ready.writeToFile(target);
            ready.close();
            Minecraft.getInstance().execute(() -> {
                Properties p = models();
                p.setProperty(file, slim ? "slim" : "wide");
                saveModels(p);
                TEXTURES.keySet().removeIf(k -> k.startsWith(file + "@"));
                store("source", "file:" + file);
                store("model", slim ? "slim" : "wide");
                status = "Saved " + file + " and using it";
                revision++;
            });
        } catch (Throwable e) {
            BagelClient.LOGGER.warn("Bagel could not download that skin", e);
            status = "Could not download the skin";
            revision++;
        }
    }

    /** Old 64x32 skins are expanded to 64x64 the way the game does it. */
    static NativeImage toModern(NativeImage image) {
        if (image.getWidth() == 64 && image.getHeight() == 64) {
            return image;
        }
        if (image.getWidth() != 64 || image.getHeight() != 32) {
            image.close();
            throw new IllegalStateException("unsupported skin size");
        }
        NativeImage out = new NativeImage(64, 64, true);
        out.copyFrom(image);
        image.close();
        out.fillRect(0, 32, 64, 32, 0);
        out.copyRect(4, 16, 16, 32, 4, 4, true, false);
        out.copyRect(8, 16, 16, 32, 4, 4, true, false);
        out.copyRect(0, 20, 24, 32, 4, 12, true, false);
        out.copyRect(4, 20, 16, 32, 4, 12, true, false);
        out.copyRect(8, 20, 8, 32, 4, 12, true, false);
        out.copyRect(12, 20, 16, 32, 4, 12, true, false);
        out.copyRect(44, 16, -8, 32, 4, 4, true, false);
        out.copyRect(48, 16, -8, 32, 4, 4, true, false);
        out.copyRect(40, 20, 0, 32, 4, 12, true, false);
        out.copyRect(44, 20, -8, 32, 4, 12, true, false);
        out.copyRect(48, 20, -16, 32, 4, 12, true, false);
        out.copyRect(52, 20, -8, 32, 4, 12, true, false);
        return out;
    }

    public static void setSlim(boolean slim) {
        String file = currentFile();
        if (file != null) {
            Properties p = models();
            p.setProperty(file, slim ? "slim" : "wide");
            saveModels(p);
        }
        store("model", slim ? "slim" : "wide");
    }

    /** Deletes a saved skin file. If it was in use, the real skin comes back. */
    public static void delete(String file) {
        try {
            Path path = folder().resolve(file).normalize();
            if (path.startsWith(folder())) {
                Files.deleteIfExists(path);
            }
            Properties p = models();
            p.remove(file);
            saveModels(p);
            TEXTURES.keySet().removeIf(k -> k.startsWith(file + "@"));
            if (("file:" + file).equals(source())) {
                reset();
            }
            status = "Deleted " + file;
        } catch (Exception e) {
            status = "Could not delete " + file;
        }
        revision++;
    }

    public static void reset() {
        Module m = module();
        if (m != null) {
            m.setSetting("source", "");
            BagelClient.MODULES.saveConfig();
        }
        copied = null;
        copiedFor = "";
    }

    /** The skin to show for the local player, or null to keep the real one. */
    static PlayerSkin resolve(PlayerSkin base) {
        String source = source();
        if (source.isEmpty()) {
            long now = System.currentTimeMillis();
            if (now >= nextLegacyCheck) {
                nextLegacyCheck = now + 2000;
                legacyPresent = Files.isRegularFile(folder().resolve("skin.png"));
            }
            if (legacyPresent) {
                source = "file:skin.png";
            }
        }
        if (source.startsWith("player:")) {
            String name = source.substring("player:".length());
            if (copied == null || !copiedFor.equalsIgnoreCase(name)) {
                long now = System.currentTimeMillis();
                if (now >= nextLookup) {
                    nextLookup = now + 1000;
                    PlayerInfo info = Names.info(name);
                    if (info != null) {
                        copied = info.getSkin();
                        copiedFor = name;
                    }
                }
            }
            return copied;
        }
        if (source.startsWith("file:")) {
            Identifier id = texture(source.substring("file:".length()));
            if (id != null && base != null) {
                PlayerModelType model = slim() ? PlayerModelType.SLIM : PlayerModelType.WIDE;
                return PlayerSkin.insecure(new ClientAsset.ResourceTexture(id), base.cape(), base.elytra(), model);
            }
        }
        return null;
    }

    /** Texture of a saved skin file, or null. */
    public static Identifier textureOf(String file) {
        return texture(file);
    }

    /** Whether a saved skin file uses slim arms. */
    public static boolean slimOf(String file) {
        String saved = models().getProperty(file);
        return saved != null && saved.equalsIgnoreCase("slim");
    }

    private static Identifier texture(String file) {
        try {
            Path path = folder().resolve(file).normalize();
            if (!path.startsWith(folder()) || !Files.isRegularFile(path)) {
                return null;
            }
            String key = file + "@" + Files.getLastModifiedTime(path).toMillis();
            Identifier cached = TEXTURES.get(key);
            if (cached != null) {
                return cached;
            }
            if (FAILED.contains(key)) {
                return null;
            }
            try (InputStream in = Files.newInputStream(path)) {
                NativeImage image = NativeImage.read(in);
                if (image.getWidth() != 64 || image.getHeight() != 64) {
                    image.close();
                    FAILED.add(key);
                    BagelClient.LOGGER.warn("Bagel skin {} must be 64x64 pixels", file);
                    return null;
                }
                Identifier id = Identifier.fromNamespaceAndPath(
                        "bagel", "skins/" + key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]", "_"));
                Minecraft.getInstance().getTextureManager().register(id, new DynamicTexture(() -> "Bagel skin " + file, image));
                TEXTURES.put(key, id);
                return id;
            }
        } catch (Throwable t) {
            BagelClient.LOGGER.warn("Could not load Bagel skin", t);
            return null;
        }
    }
}
