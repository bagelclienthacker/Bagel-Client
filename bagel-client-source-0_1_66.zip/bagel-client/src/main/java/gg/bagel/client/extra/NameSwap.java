/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Local Username: shows the configured fake name wherever the player's real name appears in text. */
public final class NameSwap {
    private NameSwap() {}

    public static Component swap(Component component) {
        if (component == null) {
            return null;
        }
        try {
            Module module = Gate.on("Local Username");
            if (module == null) {
                return component;
            }
            String real = Minecraft.getInstance().getUser().getName();
            String fake = module.stringSetting("name", "Bagel").trim();
            if (real == null || real.isEmpty() || fake.isEmpty() || fake.equals(real)) {
                return component;
            }
            String realLower = real.toLowerCase(Locale.ROOT);
            if (!component.getString().toLowerCase(Locale.ROOT).contains(realLower)) {
                return component;
            }
            Flat flat = Flat.of(component);
            String lower = flat.text.toString().toLowerCase(Locale.ROOT);
            List<Integer> hits = new ArrayList<>();
            int from = 0;
            while (true) {
                int at = lower.indexOf(realLower, from);
                if (at < 0) {
                    break;
                }
                int end = at + realLower.length();
                boolean leftOk = at == 0 || !isNameChar(lower.charAt(at - 1));
                boolean rightOk = end >= lower.length() || !isNameChar(lower.charAt(end));
                if (leftOk && rightOk) {
                    hits.add(at);
                }
                from = end;
            }
            if (hits.isEmpty()) {
                return component;
            }
            for (int k = hits.size() - 1; k >= 0; k--) {
                int at = hits.get(k);
                flat.replace(at, at + realLower.length(), fake, flat.styles.get(at));
            }
            return flat.build();
        } catch (Throwable t) {
            return component;
        }
    }

    private static boolean isNameChar(char c) {
        return c == '_' || c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z';
    }
}
