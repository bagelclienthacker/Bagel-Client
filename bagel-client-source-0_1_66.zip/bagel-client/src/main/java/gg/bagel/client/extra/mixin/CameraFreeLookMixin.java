/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.mixin;

import gg.bagel.client.extra.AuraKill;
import gg.bagel.client.util.CameraRig;
import net.minecraft.client.Camera;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Free Look: the camera uses its own angles while the player keeps its heading. Also AuraKill screen shake. */
@Mixin(Camera.class)
public abstract class CameraFreeLookMixin {
    @Redirect(
            method = "alignWithEntity",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewYRot(F)F"),
            require = 0)
    private float bagel$yaw(Entity entity, float partial) {
        float yaw = CameraRig.freeLookActive() && entity instanceof LocalPlayer ? CameraRig.lookYaw() : entity.getViewYRot(partial);
        return entity instanceof LocalPlayer ? yaw + AuraKill.shakeYaw() : yaw;
    }

    @Redirect(
            method = "alignWithEntity",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewXRot(F)F"),
            require = 0)
    private float bagel$pitch(Entity entity, float partial) {
        float pitch = CameraRig.freeLookActive() && entity instanceof LocalPlayer ? CameraRig.lookPitch() : entity.getViewXRot(partial);
        return entity instanceof LocalPlayer ? pitch + AuraKill.shakePitch() : pitch;
    }
}
