/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import java.util.Map;

/** Settings that cycle through a fixed list of values when clicked in the module settings. */
public final class Cycle {
    private static final Map<String, String[]> OPTIONS = Map.ofEntries(
            Map.entry("Auto Totem|mode", new String[] {"smart", "switch", "pickup"}),
            Map.entry("AuraKill|trigger", new String[] {"both", "crystal", "normal"}),
            Map.entry("AuraKill|order", new String[] {"random", "in order"}),
            Map.entry("Kill Aura|attack_mode", new String[] {"Real Input", "Packet"}),
            Map.entry("Kill Aura|targeting", new String[] {"FOV", "Type", "HP", "Distance", "Hurt Time", "Age"}),
            Map.entry("Homework Mode|key_shape", new String[] {"Circle", "Rounded"}),
            Map.entry("Homework Mode|theme", new String[] {"Dark", "Light"}),
            Map.entry("Homework Mode|disguise", new String[] {"Calculator", "Wikipedia", "Custom"}),
            Map.entry("Mace Aura|rotation", new String[] {"silent", "none"}),
            Map.entry("Mace Aura|targeting", new String[] {"Distance", "HP", "FOV"}),
            Map.entry("Bed Aura|rotation", new String[] {"silent", "none"}),
            Map.entry("Bed Aura|targeting", new String[] {"Distance", "HP", "FOV"}),
            Map.entry("Crystal Aura|rotation", new String[] {"silent", "fast", "none"}),
            Map.entry("Crystal Aura|targeting", new String[] {"Distance", "HP", "FOV"}),
            Map.entry("Anchor Aura|rotation", new String[] {"silent", "fast", "none"}),
            Map.entry("Anchor Aura|targeting", new String[] {"Distance", "HP", "FOV"}),
            Map.entry("Aim Assist|targeting", new String[] {"FOV", "Distance", "HP"}),
            Map.entry("Aim Assist|aim_point", new String[] {"Nearest", "Body", "Head", "Closest"}),
            Map.entry("Trigger Bot|criticals", new String[] {"Off", "Falling Only"}),
            Map.entry("Attribute Swap|weapon", new String[] {"auto", "mace", "axe", "sword"}),
            Map.entry("Freecam|click_from", new String[] {"player", "camera"}),
            Map.entry("Entity ESP|style", new String[] {"highlight", "box"}),
            Map.entry("Entity ESP|tracer_target", new String[] {"feet", "body", "head"}));

    private Cycle() {}

    /** Returns true when the setting was a cycle setting and has been advanced. */
    public static boolean handle(Module module, String key) {
        if (module == null || key == null) {
            return false;
        }
        if (ColorPickerScreen.handle(module, key)) {
            return true;
        }
        if (module.name().equals("Waypoints") && key.equals("list")) {
            WaypointListScreen.open();
            return true;
        }
        if (module.name().equals("AuraKill") && key.equals("test")) {
            AuraKill.test();
            return true;
        }
        if (module.name().equals("AuraKill") && key.equals("open_folder")) {
            AuraKill.openFolder();
            return true;
        }
        String[] options = OPTIONS.get(module.name() + "|" + key);
        if (options == null) {
            return false;
        }
        String current = String.valueOf(module.settings().getOrDefault(key, options[0])).trim();
        int index = 0;
        for (int i = 0; i < options.length; i++) {
            if (options[i].equalsIgnoreCase(current)) {
                index = i;
            }
        }
        module.setSetting(key, options[(index + 1) % options.length]);
        return true;
    }
}
