/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Fake Coordinates: shows your real position shifted by a random per-session offset, so the numbers
 * change exactly as much as you move, but never match where you really are.
 */
public final class FakeCoords {
    private static final Map<String, int[]> OFFSETS = new HashMap<>();
    private static Object lastConnection;

    private FakeCoords() {}

    public static boolean active() {
        return Gate.on("Fake Coordinates") != null;
    }

    private static String dimension(Minecraft mc) {
        return mc.level.dimension().identifier().getPath();
    }

    /** Random offset, new for every server connection and dimension. */
    private static int[] offset(Minecraft mc) {
        Object connection = mc.getConnection();
        if (connection != lastConnection) {
            OFFSETS.clear();
            lastConnection = connection;
        }
        String dim = dimension(mc);
        int[] existing = OFFSETS.get(dim);
        if (existing != null) {
            return existing;
        }
        double lo = 700;
        double hi = "the_nether".equals(dim) ? 3700 : 29000;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int targetX = target(r, lo, hi);
        int targetZ = target(r, lo, hi);
        int[] created = {
            targetX - (int) Math.floor(mc.player.getX()),
            targetZ - (int) Math.floor(mc.player.getZ())
        };
        OFFSETS.put(dim, created);
        return created;
    }

    /** Log-uniform magnitude with a random sign, so values are spread like real base locations. */
    private static int target(ThreadLocalRandom r, double lo, double hi) {
        double magnitude = Math.exp(Math.log(lo) + r.nextDouble() * (Math.log(hi) - Math.log(lo)));
        return (int) Math.round(r.nextBoolean() ? magnitude : -magnitude);
    }

    /** Position shown on the Bagel HUD (x and z are faked, y stays real). */
    public static Vec3 hud(String ignoredDimension) {
        Minecraft mc = Minecraft.getInstance();
        int[] o = offset(mc);
        return new Vec3(mc.player.getX() + o[0], mc.player.getY(), mc.player.getZ() + o[1]);
    }

    public static double x(Entity entity) {
        double real = entity.getX();
        if (!active()) {
            return real;
        }
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null || mc.player == null ? real : real + offset(mc)[0];
    }

    public static double z(Entity entity) {
        double real = entity.getZ();
        if (!active()) {
            return real;
        }
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null || mc.player == null ? real : real + offset(mc)[1];
    }

    public static BlockPos blockPos(Entity entity) {
        BlockPos real = entity.blockPosition();
        if (!active()) {
            return real;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            return real;
        }
        int[] o = offset(mc);
        return new BlockPos(real.getX() + o[0], real.getY(), real.getZ() + o[1]);
    }
}
