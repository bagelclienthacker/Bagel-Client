/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra.chess;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Hand-drawn pixel-art chess pieces (12x12), drawn with plain fills so no textures are needed. */
public final class ChessSprites {
    public static final int SIZE = 12;
    // # outline, o body, h highlight, x shade, . empty
    private static final String[][] ART = {
        null,
        { // pawn
            "............",
            "....####....",
            "...#hoox#...",
            "...#oooo#...",
            "...#oooo#...",
            "....#oo#....",
            "...#hoox#...",
            "....#oo#....",
            "...#hoox#...",
            "..#hoooox#..",
            ".#hoooooox#.",
            ".##########."},
        { // knight
            "............",
            "....##.#....",
            "...#hoo#o#..",
            "..#hoooooo#.",
            ".#hoooooooo#",
            "##hoo#oooxx#",
            "#o##.#ooxxx#",
            "##...#oooxx#",
            ".....#oooxx#",
            "....#hoooxx#",
            "...#hooooxx#",
            "..##########"},
        { // bishop
            "............",
            ".....##.....",
            "....#hx#....",
            "...#hoox#...",
            "...#o##o#...",
            "...#oooo#...",
            "....#oo#....",
            "...#hoox#...",
            "....#oo#....",
            "..#hoooox#..",
            ".#hoooooox#.",
            ".##########."},
        { // rook
            "............",
            ".##.####.##.",
            ".#ho#oo#ox#.",
            ".#hoooooox#.",
            "..#hoooox#..",
            "..#hoooox#..",
            "..#hoooox#..",
            "..#hoooox#..",
            ".#hoooooox#.",
            ".#hoooooox#.",
            ".##########.",
            "............"},
        { // queen
            "............",
            ".#..#..#..#.",
            ".##.####.##.",
            "..#hoooox#..",
            "..#hoooox#..",
            "...#oooo#...",
            "....#oo#....",
            "....#oo#....",
            "...#hoox#...",
            "..#hoooox#..",
            ".#hoooooox#.",
            ".##########."},
        { // king
            "............",
            ".....##.....",
            "...######...",
            ".....##.....",
            "...#hoox#...",
            "..#hoooox#..",
            "..#hoooox#..",
            "...#oooo#...",
            "....#oo#....",
            "...#hoox#...",
            ".#hoooooox#.",
            ".##########."},
    };

    /** Horizontal runs per piece kind: {x, y, length, tone} with tone 0 outline, 1 body, 2 highlight, 3 shade. */
    private static final List<int[]>[] RUNS = build();

    private ChessSprites() {}

    @SuppressWarnings("unchecked")
    private static List<int[]>[] build() {
        List<int[]>[] out = new List[ART.length];
        for (int kind = 1; kind < ART.length; kind++) {
            List<int[]> runs = new ArrayList<>();
            for (int y = 0; y < SIZE; y++) {
                String row = ART[kind][y];
                int x = 0;
                while (x < SIZE) {
                    int tone = tone(row.charAt(x));
                    if (tone < 0) {
                        x++;
                        continue;
                    }
                    int start = x;
                    while (x < SIZE && tone(row.charAt(x)) == tone) {
                        x++;
                    }
                    runs.add(new int[] {start, y, x - start, tone});
                }
            }
            out[kind] = runs;
        }
        return out;
    }

    private static int tone(char c) {
        return switch (c) {
            case '#' -> 0;
            case 'o' -> 1;
            case 'h' -> 2;
            case 'x' -> 3;
            default -> -1;
        };
    }

    private static final int[] WHITE = {0xFF3B2A1A, 0xFFF3EBDD, 0xFFFFFFFF, 0xFFC4B497};
    private static final int[] BLACK = {0xFF050505, 0xFF3C3C46, 0xFF6C6C7C, 0xFF22222A};

    /** Pixel size that fits a sprite into a square cell. */
    public static int scale(int cell) {
        return Math.max(1, (cell - 4) / SIZE);
    }

    /** Draws a piece (kind 1..6, see ChessEngine) centred in a cell. */
    public static void draw(GuiGraphicsExtractor g, int kind, boolean white, int cellX, int cellY, int cell) {
        if (kind < 1 || kind >= RUNS.length) {
            return;
        }
        int ps = scale(cell);
        int ox = cellX + (cell - SIZE * ps) / 2;
        int oy = cellY + (cell - SIZE * ps) / 2;
        int[] palette = white ? WHITE : BLACK;
        for (int[] run : RUNS[kind]) {
            int x = ox + run[0] * ps;
            int y = oy + run[1] * ps;
            g.fill(x, y, x + run[2] * ps, y + ps, palette[run[3]]);
        }
    }

    /** Test hook: rows of a sprite. */
    public static String[] rows(int kind) {
        return ART[kind];
    }
}
