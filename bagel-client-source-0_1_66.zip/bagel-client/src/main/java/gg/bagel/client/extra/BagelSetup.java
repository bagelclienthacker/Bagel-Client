/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;

/** Runs once at startup, before the saved config is loaded, so new settings pick up saved values. */
public final class BagelSetup {
    private BagelSetup() {}

    /** Bumped when the saved module config should be thrown away once, so everyone starts from the defaults. */
    private static final String DEFAULTS_MARKER = ".defaults-0.1.66";

    /**
     * One-time reset: moves config/bagel/modules.properties to modules.properties.bak, so every module starts from its
     * default (off, except HUD; no key binds; default settings). Waypoints, accounts and skins are not touched.
     */
    private static void resetConfigOnce() {
        try {
            Path dir = BagelClient.gameDirectory().resolve("config/bagel");
            Path marker = dir.resolve(DEFAULTS_MARKER);
            if (Files.exists(marker)) {
                return;
            }
            Files.createDirectories(dir);
            Path config = dir.resolve("modules.properties");
            if (Files.exists(config)) {
                Files.move(config, dir.resolve("modules.properties.bak"), StandardCopyOption.REPLACE_EXISTING);
            }
            Files.writeString(marker, "Bagel reset the module config to defaults once. Delete this file to do it again.\n");
        } catch (IOException | RuntimeException e) {
            BagelClient.LOGGER.warn("Bagel could not reset the module config", e);
        }
    }

    public static void init() {
        resetConfigOnce();
        try {
            Module spoofer = BagelClient.MODULES.byName(ScoreboardFields.MODULE);
            if (spoofer != null) {
                Map<String, Object> settings = spoofer.settings();
                settings.remove("title");
                settings.remove("lines");
                for (String[] field : ScoreboardFields.DEFAULTS) {
                    settings.putIfAbsent(field[0], field[1]);
                }
            }
            for (String esp : new String[] {"Storage ESP", "Block ESP", "Spawner ESP", "Block Highlights", "Entity ESP", "Item ESP"}) {
                Module module = BagelClient.MODULES.byName(esp);
                if (module != null) {
                    module.settings().remove("range");
                }
            }
            Module antiTrap = BagelClient.MODULES.byName("Anti-Trap");
            if (antiTrap != null) {
                antiTrap.settings().remove("armor_stand_trap");
                antiTrap.settings().putIfAbsent("pearl_through_stands", Boolean.TRUE);
            }
            Module skin = BagelClient.MODULES.byName(SkinStore.MODULE);
            if (skin != null) {
                skin.settings().putIfAbsent("source", "");
                skin.settings().putIfAbsent("model", "wide");
                skin.settings().putIfAbsent("picker", "/bagelskin");
            }
            Module storage = BagelClient.MODULES.byName(StorageColors.MODULE);
            if (storage != null) {
                for (String[] color : StorageColors.DEFAULTS) {
                    storage.settings().putIfAbsent(color[0], color[1]);
                }
            }
            for (String esp : new String[] {"Storage ESP", "Block ESP", "Spawner ESP", "Block Highlights", "Entity ESP", "Item ESP"}) {
                Module module = BagelClient.MODULES.byName(esp);
                if (module != null) {
                    module.settings().putIfAbsent("tracers", Boolean.FALSE);
                }
            }
            for (String esp : new String[] {"Storage ESP", "Block ESP", "Spawner ESP", "Block Highlights", "Entity ESP", "Item ESP"}) {
                Module module = BagelClient.MODULES.byName(esp);
                if (module != null) {
                    module.settings().putIfAbsent("tracer_width", 1);
                }
            }
            Module entityEsp = BagelClient.MODULES.byName("Entity ESP");
            if (entityEsp != null) {
                entityEsp.settings().putIfAbsent("tracer_target", "feet");
                entityEsp.settings().putIfAbsent("style", "highlight");
            }
            Module totem = BagelClient.MODULES.byName("Auto Totem");
            if (totem != null) {
                totem.settings().putIfAbsent("mode", "smart");
                totem.settings().putIfAbsent("delay_ticks", 2);
                totem.settings().putIfAbsent("switch_back", Boolean.TRUE);
                totem.settings().putIfAbsent("switch_back_delay", 400);
            }
            Module freecamModule = BagelClient.MODULES.byName("Freecam");
            if (freecamModule != null) {
                freecamModule.settings().putIfAbsent("hold_key", Boolean.FALSE);
                freecamModule.settings().putIfAbsent("click_from", "player");
            }
            Module killAura = BagelClient.MODULES.byName("Kill Aura");
            if (killAura != null) {
                // settings of the AUTISM-style Kill Aura; the old range / rotation / aim / priority / delay ones are gone
                for (String old : new String[] {"rotation", "aim", "priority", "range", "cooldown_check", "attack_delay_ticks"}) {
                    killAura.settings().remove(old);
                }
                killAura.settings().putIfAbsent("attack_mode", "Real Input");
                killAura.settings().putIfAbsent("targeting", "FOV");
                killAura.settings().putIfAbsent("fov", 180);
                killAura.settings().putIfAbsent("turn_speed", 35.0D);
                killAura.settings().putIfAbsent("smoothing", 0.45D);
                killAura.settings().putIfAbsent("predict", Boolean.TRUE);
                killAura.settings().putIfAbsent("miss_injection", Boolean.FALSE);
                killAura.settings().putIfAbsent("miss_chance", 6);
                killAura.settings().putIfAbsent("criticals", Boolean.FALSE);
                killAura.settings().putIfAbsent("auto_sword", Boolean.TRUE);
                killAura.settings().putIfAbsent("shield_break", Boolean.TRUE);
                killAura.settings().putIfAbsent("switch_back", Boolean.TRUE);
                killAura.settings().putIfAbsent("hitsound", Boolean.TRUE);
            }
            // rewritten combat modules take over the built-in ones of the same name
            for (Module rewritten : new Module[] {new TriggerBot(), new AimAssist(), new CrystalAura(), new AnchorAura()}) {
                replaceBuiltIn(rewritten);
            }
            for (Module extra : new Module[] {new MaceAura(), new AttributeSwap(), new Velocity(), new BedAura(), new AutoArmor(), new HomeworkMode(), new AuraKill(), new AutoWeb(), new AutoTrap(), new AntiHunger(), new Chess(), new HitDummy()}) {
                if (BagelClient.MODULES.byName(extra.name()) == null) {
                    BagelClient.MODULES.registerAddonModule(extra.name(), extra);
                }
            }
            for (String esp : new String[] {"Storage ESP", "Block ESP", "Spawner ESP", "Block Highlights", "Entity ESP", "Item ESP"}) {
                Module module = BagelClient.MODULES.byName(esp);
                if (module != null) {
                    module.settings().putIfAbsent("fill", Boolean.TRUE);
                    module.settings().putIfAbsent("fill_opacity", 22);
                    module.settings().putIfAbsent("line_width", 2);
                }
            }
            Module aura = BagelClient.MODULES.byName("AuraKill");
            if (aura != null) {
                aura.settings().putIfAbsent("order", "random");
                aura.settings().putIfAbsent("overlay_opacity", 55);
                aura.settings().putIfAbsent("overlay_gray", 45);
                aura.settings().putIfAbsent("shake", Boolean.TRUE);
                aura.settings().putIfAbsent("shake_intensity", 50);
                aura.settings().putIfAbsent("skull", Boolean.TRUE);
                aura.settings().putIfAbsent("skull_size", 6);
                aura.settings().putIfAbsent("test", "click to test");
                aura.settings().putIfAbsent("open_folder", "click to open");
            }
            Module highlightsModule = BagelClient.MODULES.byName("Block Highlights");
            if (highlightsModule != null) {
                highlightsModule.settings().putIfAbsent("only_exposed", Boolean.FALSE);
                highlightsModule.settings().putIfAbsent("color", "#FF9E27");
            }
            Module blockEspModule = BagelClient.MODULES.byName("Block ESP");
            if (blockEspModule != null) {
                blockEspModule.settings().putIfAbsent("color", "auto");
            }
            Module waypoints = BagelClient.MODULES.byName("Waypoints");
            if (waypoints != null) {
                waypoints.settings().putIfAbsent("list", "click to open");
            }
            Module username = BagelClient.MODULES.byName("Local Username");
            if (username != null) {
                username.settings().putIfAbsent("name", "Bagel");
            }
        } catch (Throwable t) {
            BagelClient.LOGGER.warn("Bagel could not register the new module settings", t);
        }
        try {
            SkinCommand.register();
        } catch (Throwable t) {
            BagelClient.LOGGER.warn("Bagel could not register /bagelskin", t);
        }
        try {
            AuraKill.register();
        } catch (Throwable t) {
            BagelClient.LOGGER.warn("Bagel could not register AuraKill", t);
        }
        try {
            TestPay.register();
        } catch (Throwable t) {
            BagelClient.LOGGER.warn("Bagel could not register /testpay", t);
        }
    }

    /** Swaps a built-in module for a rewritten one with the same name (same registry key, same position in the list). */
    @SuppressWarnings("unchecked")
    private static void replaceBuiltIn(Module replacement) {
        try {
            java.lang.reflect.Field field = gg.bagel.client.module.ModuleRegistry.class.getDeclaredField("modules");
            field.setAccessible(true);
            Map<String, Module> modules = (Map<String, Module>) field.get(BagelClient.MODULES);
            String key = replacement.name().toLowerCase(java.util.Locale.ROOT).replace(' ', '-');
            Module current = modules.get(key);
            if (current != null && current.getClass() != replacement.getClass()) {
                modules.put(key, replacement);
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            // keep the old module if the registry layout is not what we expect
        }
    }
}
