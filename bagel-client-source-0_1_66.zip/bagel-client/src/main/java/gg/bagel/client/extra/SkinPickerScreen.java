/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Pick a skin file, copy an online player's skin, or switch the arm model. */
public final class SkinPickerScreen extends Screen {
    private static final int PER_PAGE = 7;
    private final Screen parent;
    private int filePage;
    private int playerPage;
    private List<String> files = List.of();
    private List<String> players = List.of();
    private int seenRevision = SkinStore.revision;

    public SkinPickerScreen(Screen parent) {
        super(Component.literal("Local Skin"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        files = SkinStore.files();
        players = new ArrayList<>(Names.online());
        int left = this.width / 2 - 160;
        int right = this.width / 2 + 10;
        int top = 48;
        String source = SkinStore.source();

        for (int i = 0; i < PER_PAGE; i++) {
            int index = filePage * PER_PAGE + i;
            if (index >= files.size()) {
                break;
            }
            String file = files.get(index);
            boolean active = source.equals("file:" + file);
            this.addRenderableWidget(Button.builder(Component.literal((active ? "> " : "") + clip(file, 16)), b -> {
                SkinStore.useFile(file);
                this.rebuildWidgets();
            }).bounds(left, top + i * 22, 125, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("X"), b -> SkinStore.delete(file))
                    .bounds(left + 128, top + i * 22, 22, 20).build());
        }
        for (int i = 0; i < PER_PAGE; i++) {
            int index = playerPage * PER_PAGE + i;
            if (index >= players.size()) {
                break;
            }
            String name = players.get(index);
            boolean active = source.equalsIgnoreCase("player:" + name);
            this.addRenderableWidget(Button.builder(Component.literal((active ? "> " : "") + clip(name, 20)), b -> {
                SkinStore.copyPlayer(name);
                this.rebuildWidgets();
            }).bounds(right, top + i * 22, 150, 20).build());
        }
        int paging = top + PER_PAGE * 22;
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            filePage = Math.max(0, filePage - 1);
            this.rebuildWidgets();
        }).bounds(left, paging, 40, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            if ((filePage + 1) * PER_PAGE < files.size()) {
                filePage++;
            }
            this.rebuildWidgets();
        }).bounds(left + 110, paging, 40, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            playerPage = Math.max(0, playerPage - 1);
            this.rebuildWidgets();
        }).bounds(right, paging, 40, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            if ((playerPage + 1) * PER_PAGE < players.size()) {
                playerPage++;
            }
            this.rebuildWidgets();
        }).bounds(right + 110, paging, 40, 20).build());

        int bottom = paging + 28;
        this.addRenderableWidget(Button.builder(
                Component.literal("Model: " + (SkinStore.slim() ? "Slim" : "Wide")), b -> {
                    SkinStore.setSlim(!SkinStore.slim());
                    this.rebuildWidgets();
                }).bounds(left, bottom, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
            SkinStore.reset();
            this.rebuildWidgets();
        }).bounds(left + 105, bottom, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(left + 210, bottom, 110, 20).build());
    }

    private static String clip(String text, int max) {
        return text.length() <= max ? text : text.substring(0, max - 1) + "~";
    }

    @Override
    public void tick() {
        super.tick();
        if (seenRevision != SkinStore.revision) {
            seenRevision = SkinStore.revision;
            this.rebuildWidgets();
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        int left = this.width / 2 - 160;
        int right = this.width / 2 + 10;
        graphics.text(this.font, "Local Skin", this.width / 2 - this.font.width("Local Skin") / 2, 14, -1);
        graphics.text(this.font, "Your skins (" + files.size() + ")", left, 36, -1);
        graphics.text(this.font, "Copy a player (saves a PNG) (" + players.size() + ")", right, 36, -1);
        String status = SkinStore.status;
        if (!status.isEmpty()) {
            graphics.text(this.font, status, this.width / 2 - this.font.width(status) / 2, this.height - 32, 0xFFFFB347);
        }
        String hint = "Drop a 64x64 PNG on this window to add it";
        graphics.text(this.font, hint, this.width / 2 - this.font.width(hint) / 2, this.height - 20, 0xFFAAAAAA);
    }

    @Override
    public void onFilesDrop(List<Path> dropped) {
        for (Path path : dropped) {
            String name = path.getFileName().toString();
            if (name.toLowerCase(Locale.ROOT).endsWith(".png")) {
                try {
                    Files.copy(path, SkinStore.folder().resolve(name), StandardCopyOption.REPLACE_EXISTING);
                } catch (Exception ignored) {
                }
            }
        }
        this.rebuildWidgets();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }
}
