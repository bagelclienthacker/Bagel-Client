/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;

/** Small helper: returns a module only when it exists, is enabled and Vanilla Mode is off. */
final class Gate {
    private Gate() {}

    static Module on(String name) {
        try {
            if (VanillaMode.active()) {
                return null;
            }
            Module m = BagelClient.MODULES.byName(name);
            return m != null && m.enabled() ? m : null;
        } catch (Throwable t) {
            return null;
        }
    }
}
