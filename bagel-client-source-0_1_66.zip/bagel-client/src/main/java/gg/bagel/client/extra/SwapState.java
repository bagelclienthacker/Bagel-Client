/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * Remembers which hotbar slot a module took you off of, and puts you back after the module has been idle for a while.
 * The slot change itself is only local; the next use/attack call sends the matching packet, so there is no extra spam.
 */
final class SwapState {
    private int previous = -1;
    private int switched = -1;
    private int idle;

    /** Makes {@code slot} the selected slot (locally). Returns true if the selection changed. */
    boolean take(LocalPlayer player, int slot) {
        int current = player.getInventory().getSelectedSlot();
        idle = 0;
        if (current == slot) {
            return false;
        }
        if (switched < 0 || current != switched) {
            previous = current;
        }
        Hotbar.select(player, slot);
        switched = slot;
        return true;
    }

    /** Call once per tick. {@code active} means the module did something this tick. */
    void tick(Minecraft mc, LocalPlayer player, boolean active, int delayTicks) {
        if (switched < 0) {
            return;
        }
        if (player.getInventory().getSelectedSlot() != switched) {
            // you changed slot yourself: forget it
            clear();
            return;
        }
        if (active) {
            idle = 0;
            return;
        }
        if (++idle >= Math.max(1, delayTicks)) {
            if (previous >= 0) {
                Hotbar.selectAndSend(mc, player, previous);
            }
            clear();
        }
    }

    void clear() {
        previous = -1;
        switched = -1;
        idle = 0;
    }

    /** Immediately returns to the old slot (module turned off). */
    void restore(Minecraft mc, LocalPlayer player) {
        if (switched >= 0 && previous >= 0 && player != null && player.getInventory().getSelectedSlot() == switched) {
            Hotbar.selectAndSend(mc, player, previous);
        }
        clear();
    }
}
