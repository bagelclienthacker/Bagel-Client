/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.ui;

import gg.bagel.client.module.Module;
import java.lang.reflect.Field;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Scroll bar for the click GUI settings list (the mouse wheel scrolling itself is handled by BagelClickScreen).
 * Drawn from BagelClickScreen.drawSettings; reads the screen's private layout fields by reflection.
 */
public final class ScrollBar {
    private static boolean failed;
    private static Field selected;
    private static Field scroll;
    private static Field settingsX;
    private static Field settingsW;
    private static Field panelY;
    private static Field panelH;

    private ScrollBar() {}

    private static Field field(Class<?> type, String name) throws NoSuchFieldException {
        Field f = type.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    public static void draw(Object screen, GuiGraphicsExtractor g) {
        if (failed) {
            return;
        }
        try {
            if (selected == null) {
                Class<?> type = screen.getClass();
                selected = field(type, "selected");
                scroll = field(type, "settingsScroll");
                settingsX = field(type, "settingsX");
                settingsW = field(type, "settingsW");
                panelY = field(type, "panelY");
                panelH = field(type, "panelH");
            }
            Module module = (Module) selected.get(screen);
            if (module == null) {
                return;
            }
            int total = module.settings().size();
            int top = panelY.getInt(screen) + (module.name().equals("Waypoints") ? 178 : 162);
            int bottom = panelY.getInt(screen) + panelH.getInt(screen) - 24;
            int visible = Math.max(1, (bottom - top) / 32);
            if (total <= visible) {
                return;
            }
            int offset = Math.max(0, Math.min(total - visible, scroll.getInt(screen)));
            int x = settingsX.getInt(screen) + settingsW.getInt(screen) + 6;
            int track = bottom - top;
            int thumb = Math.max(18, track * visible / total);
            int thumbY = top + (track - thumb) * offset / (total - visible);
            g.fill(x, top, x + 4, bottom, 0xFF2A2420);
            g.fill(x, thumbY, x + 4, thumbY + thumb, 0xFFB8803A);
        } catch (Throwable t) {
            failed = true;
        }
    }
}
