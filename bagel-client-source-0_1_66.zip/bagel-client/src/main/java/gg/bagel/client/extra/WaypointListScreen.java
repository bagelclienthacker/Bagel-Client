/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.BagelClient;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.WaypointStore;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** List of saved waypoints: add here, rename, copy coordinates, delete, and a "show in world" switch. */
public final class WaypointListScreen extends Screen {
    private static final int PER_PAGE = 7;
    private final Screen parent;
    private EditBox nameField;
    private int page;
    private String keepName = "";

    public WaypointListScreen(Screen parent) {
        super(Component.literal("Waypoints"));
        this.parent = parent;
    }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreenAndShow(new WaypointListScreen(mc.gui.screen()));
    }

    private static boolean showInWorld() {
        Module m = BagelClient.MODULES.byName("Waypoints");
        return m != null && m.booleanSetting("show_waypoints", false);
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 170;
        nameField = new EditBox(this.font, left, 36, 200, 20, Component.literal("Name"));
        nameField.setMaxLength(32);
        nameField.setHint(Component.literal("Name (for Add here / Rename)"));
        nameField.setValue(keepName);
        this.addRenderableWidget(nameField);
        this.addRenderableWidget(Button.builder(Component.literal("Add here"), b -> {
            if (this.minecraft.player != null && this.minecraft.level != null) {
                WaypointStore.saveNamed(this.minecraft.player, nameField.getValue());
                keepName = "";
                page = Math.max(0, (WaypointStore.all().size() - 1) / PER_PAGE);
                this.rebuildWidgets();
            }
        }).bounds(left + 205, 36, 135, 20).build());

        List<WaypointStore.Waypoint> all = WaypointStore.all();
        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            if (index >= all.size()) {
                break;
            }
            int y = 66 + i * 24;
            this.addRenderableWidget(Button.builder(Component.literal("Rename"), b -> {
                WaypointStore.rename(index, nameField.getValue());
                keepName = "";
                this.rebuildWidgets();
            }).bounds(left + 190, y, 56, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("Copy"), b -> {
                WaypointStore.Waypoint w = WaypointStore.all().get(index);
                this.minecraft.keyboardHandler.setClipboard(Math.round(w.x()) + " " + Math.round(w.y()) + " " + Math.round(w.z()));
            }).bounds(left + 250, y, 48, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                WaypointStore.remove(index);
                if (page > 0 && page * PER_PAGE >= WaypointStore.all().size()) {
                    page--;
                }
                keepName = nameField.getValue();
                this.rebuildWidgets();
            }).bounds(left + 302, y, 38, 20).build());
        }
        int bottom = 66 + PER_PAGE * 24 + 4;
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page = Math.max(0, page - 1);
            keepName = nameField.getValue();
            this.rebuildWidgets();
        }).bounds(left, bottom, 30, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            if ((page + 1) * PER_PAGE < WaypointStore.all().size()) {
                page++;
            }
            keepName = nameField.getValue();
            this.rebuildWidgets();
        }).bounds(left + 34, bottom, 30, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("In world: " + (showInWorld() ? "ON" : "OFF")), b -> {
            Module m = BagelClient.MODULES.byName("Waypoints");
            if (m != null) {
                m.setSetting("show_waypoints", !showInWorld());
                BagelClient.MODULES.saveConfig();
            }
            keepName = nameField.getValue();
            this.rebuildWidgets();
        }).bounds(left + 70, bottom, 140, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(left + 240, bottom, 100, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int left = cx - 170;
        graphics.text(this.font, "Waypoints", cx - this.font.width("Waypoints") / 2, 14, -1);
        List<WaypointStore.Waypoint> all = WaypointStore.all();
        String dim = this.minecraft.level == null ? "" : this.minecraft.level.dimension().identifier().toString();
        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            if (index >= all.size()) {
                break;
            }
            WaypointStore.Waypoint w = all.get(index);
            int y = 66 + i * 24;
            String name = clip(w.name(), 150);
            graphics.text(this.font, name, left, y + 2, -1);
            String where = Math.round(w.x()) + " " + Math.round(w.y()) + " " + Math.round(w.z());
            String d = w.dimension().contains(":") ? w.dimension().substring(w.dimension().indexOf(':') + 1) : w.dimension();
            String info = where + "  " + d;
            if (this.minecraft.player != null && w.dimension().equals(dim)) {
                double dx = w.x() - this.minecraft.player.getX();
                double dz = w.z() - this.minecraft.player.getZ();
                info += "  " + Math.round(Math.sqrt(dx * dx + dz * dz)) + "m";
            }
            graphics.text(this.font, clip(info, 185), left, y + 12, 0xFFAAAAAA);
        }
        if (all.isEmpty()) {
            String none = "No waypoints yet - press Add here, or set a save key on the Waypoints module";
            graphics.text(this.font, none, cx - this.font.width(none) / 2, 90, 0xFFAAAAAA);
        }
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        String footer = all.size() + " saved  -  page " + (page + 1) + "/" + pages;
        graphics.text(this.font, footer, cx - this.font.width(footer) / 2, this.height - 18, 0xFFAAAAAA);
    }

    private String clip(String text, int maxWidth) {
        if (this.font.width(text) <= maxWidth) {
            return text;
        }
        String t = text;
        while (t.length() > 1 && this.font.width(t + "...") > maxWidth) {
            t = t.substring(0, t.length() - 1);
        }
        return t + "...";
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }
}
