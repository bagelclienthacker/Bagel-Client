/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

/** Auto Web: drops a cobweb on the feet (and head) of the nearest player. */
public final class AutoWeb extends Module {
    public static final String NAME = "Auto Web";
    private final Map<BlockPos, Integer> tried = new HashMap<>();
    private int tickCount;
    private int wait;

    public AutoWeb() {
        super(NAME, "Places cobwebs on nearby players", Category.COMBAT);
        setting("range", 5);
        setting("place_range", 4.5D);
        setting("head", Boolean.TRUE);
        setting("delay_ticks", 1);
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (player == null || mc.gameMode == null || mc.level == null || !player.isAlive()) {
            return;
        }
        tickCount++;
        if (wait > 0) {
            wait--;
            return;
        }
        int slot = BlockPlacer.findSlot(player, s -> s.is(Items.COBWEB));
        if (slot < 0) {
            return;
        }
        Player target = BlockPlacer.nearestPlayer(mc, Math.max(1, Math.min(12, intSetting("range", 5))));
        if (target == null) {
            return;
        }
        double reach = Math.max(2.0D, Math.min(6.0D, doubleSetting("place_range", 4.5D)));
        BlockPos feet = target.blockPosition();
        BlockPos[] cells = booleanSetting("head", true) ? new BlockPos[] {feet, feet.above()} : new BlockPos[] {feet};
        for (BlockPos cell : cells) {
            Integer last = tried.get(cell);
            if (last != null && tickCount - last < 10) {
                continue;
            }
            if (!BlockPlacer.replaceable(mc.level, cell)) {
                continue;
            }
            tried.put(cell, tickCount);
            if (BlockPlacer.place(mc, player, mc.level, cell, slot, reach)) {
                wait = Math.max(0, Math.min(20, intSetting("delay_ticks", 1)));
                break;
            }
        }
        if (tried.size() > 64) {
            tried.entrySet().removeIf(e -> tickCount - e.getValue() > 40);
        }
    }

    @Override
    protected void onDisable(Minecraft mc) {
        tried.clear();
    }
}
