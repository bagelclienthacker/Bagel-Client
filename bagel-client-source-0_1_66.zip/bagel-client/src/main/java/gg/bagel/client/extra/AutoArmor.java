/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Category;
import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.equipment.Equippable;

/** Auto Armor: keeps the best armor you carry equipped. */
public final class AutoArmor extends Module {
    public static final String NAME = "Auto Armor";
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private int wait;

    public AutoArmor() {
        super(NAME, "Equips the best armor in your inventory", Category.COMBAT);
        setting("delay_ticks", 3);
        setting("keep_elytra", Boolean.TRUE);
    }

    @Override
    public void tick(Minecraft mc) {
        if (!enabled() || VanillaMode.active()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (player == null || mc.gameMode == null || mc.level == null || !player.isAlive()) {
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }
        if (!player.inventoryMenu.getCarried().isEmpty()) {
            return;
        }
        boolean keepElytra = booleanSetting("keep_elytra", true);
        for (int i = 0; i < SLOTS.length; i++) {
            EquipmentSlot slot = SLOTS[i];
            ItemStack worn = player.getItemBySlot(slot);
            if (keepElytra && slot == EquipmentSlot.CHEST && worn.is(Items.ELYTRA)) {
                continue;
            }
            if (!worn.isEmpty() && hasBinding(worn)) {
                continue;
            }
            double wornScore = worn.isEmpty() ? -0.5D : score(worn, slot);
            int best = -1;
            double bestScore = wornScore;
            for (int inv = 0; inv < 36; inv++) {
                ItemStack stack = player.getInventory().getItem(inv);
                if (stack.isEmpty() || hasBinding(stack)) {
                    continue;
                }
                double s = score(stack, slot);
                if (s > bestScore + 0.01D) {
                    bestScore = s;
                    best = inv;
                }
            }
            if (best < 0) {
                continue;
            }
            equip(mc, player, best, 5 + i, !worn.isEmpty());
            wait = Math.max(0, Math.min(20, intSetting("delay_ticks", 3)));
            return;
        }
    }

    private static void equip(Minecraft mc, LocalPlayer player, int inventorySlot, int armorMenuSlot, boolean replacing) {
        int menuSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
        int id = player.inventoryMenu.containerId;
        if (!replacing) {
            mc.gameMode.handleContainerInput(id, menuSlot, 0, ContainerInput.QUICK_MOVE, player);
            return;
        }
        mc.gameMode.handleContainerInput(id, menuSlot, 0, ContainerInput.PICKUP, player);
        mc.gameMode.handleContainerInput(id, armorMenuSlot, 0, ContainerInput.PICKUP, player);
        if (!player.inventoryMenu.getCarried().isEmpty()) {
            mc.gameMode.handleContainerInput(id, menuSlot, 0, ContainerInput.PICKUP, player);
        }
    }

    /** Armor value, toughness, protection enchants and a little for remaining durability. -1 if it does not fit the slot. */
    static double score(ItemStack stack, EquipmentSlot slot) {
        Equippable equippable = stack.get(DataComponents.EQUIPPABLE);
        if (equippable == null || equippable.slot() != slot) {
            return -1.0D;
        }
        double[] total = new double[3];
        stack.forEachModifier(slot, (attribute, modifier) -> {
            if (attribute.value() == Attributes.ARMOR.value()) {
                total[0] += modifier.amount();
            } else if (attribute.value() == Attributes.ARMOR_TOUGHNESS.value()) {
                total[1] += modifier.amount();
            } else if (attribute.value() == Attributes.KNOCKBACK_RESISTANCE.value()) {
                total[2] += modifier.amount();
            }
        });
        double score = total[0] + total[1] * 0.8D + total[2] * 3.0D;
        ItemEnchantments enchants = stack.getEnchantments();
        for (Holder<Enchantment> holder : enchants.keySet()) {
            String path = holder.unwrapKey().map(k -> k.identifier().getPath()).orElse("");
            int level = enchants.getLevel(holder);
            switch (path) {
                case "protection" -> score += level;
                case "blast_protection", "projectile_protection", "fire_protection" -> score += level * 0.6D;
                case "feather_falling", "thorns" -> score += level * 0.25D;
                case "unbreaking", "mending", "respiration", "aqua_affinity", "depth_strider" -> score += level * 0.1D;
                default -> { }
            }
        }
        if (stack.getMaxDamage() > 0) {
            score += (1.0D - (double) stack.getDamageValue() / stack.getMaxDamage()) * 0.5D;
        }
        return score;
    }

    private static boolean hasBinding(ItemStack stack) {
        ItemEnchantments enchants = stack.getEnchantments();
        for (Holder<Enchantment> holder : enchants.keySet()) {
            if (holder.unwrapKey().map(k -> k.identifier().getPath()).orElse("").equals("binding_curse")) {
                return true;
            }
        }
        return false;
    }
}
