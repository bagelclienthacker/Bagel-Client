/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Small hotbar helpers shared by the combat modules. */
final class Hotbar {
    private Hotbar() {}

    static int find(LocalPlayer player, Predicate<ItemStack> filter) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!stack.isEmpty() && filter.test(stack)) {
                return i;
            }
        }
        return -1;
    }

    static String path(ItemStack stack) {
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
    }

    static boolean isSpear(ItemStack stack) {
        return path(stack).endsWith("_spear");
    }

    static boolean isAxe(ItemStack stack) {
        return path(stack).endsWith("_axe");
    }

    static boolean isSword(ItemStack stack) {
        return path(stack).endsWith("_sword");
    }

    static boolean isMace(ItemStack stack) {
        return stack.is(Items.MACE);
    }

    /** Selects a hotbar slot locally; the next attack/use call sends the matching packet. */
    static void select(LocalPlayer player, int slot) {
        if (slot >= 0 && slot < 9) {
            player.getInventory().setSelectedSlot(slot);
        }
    }

    /** Selects the slot locally and tells the server right away. */
    static void selectAndSend(Minecraft mc, LocalPlayer player, int slot) {
        select(player, slot);
        if (mc.getConnection() != null && slot >= 0 && slot < 9) {
            mc.getConnection().send(new ServerboundSetCarriedItemPacket(slot));
        }
    }
}
