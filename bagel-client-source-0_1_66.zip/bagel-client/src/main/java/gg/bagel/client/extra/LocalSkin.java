/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package gg.bagel.client.extra;

import gg.bagel.client.module.Module;
import gg.bagel.client.util.VanillaMode;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Called from AbstractClientPlayerMixin.getSkin: swaps the local player's skin when Local Skin is enabled. */
public final class LocalSkin {
    private LocalSkin() {}

    public static void apply(Object self, CallbackInfoReturnable<PlayerSkin> cir) {
        try {
            if (VanillaMode.active() || self != Minecraft.getInstance().player) {
                return;
            }
            Module module = Gate.on(SkinStore.MODULE);
            if (module == null) {
                return;
            }
            PlayerSkin custom = SkinStore.resolve(cir.getReturnValue());
            if (custom != null) {
                cir.setReturnValue(custom);
            }
        } catch (Throwable ignored) {
        }
    }
}
