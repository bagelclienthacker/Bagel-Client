/*
 * Bagel Client - a client-side Fabric hack client for Minecraft.
 * Copyright (C) 2026 The Bagel Client contributors
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 3 as published by the Free Software Foundation. It is distributed WITHOUT ANY WARRANTY, without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file.
 *
 * SPDX-License-Identifier: GPL-3.0-only

 * Parts of this file are modelled on, or derived from, AUTISM Client by Melonik (GPL-3.0), see NOTICE.md.
 */
package net.minecraft.client.renderer.rendertype;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import java.util.Optional;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/**
 * Render types for the ESPs that ignore the depth buffer, so boxes show through walls
 * (same recipe AUTISM uses for its see-through storage ESP). Lives in a Minecraft package
 * because RenderType.create is package-private.
 */
public final class BagelRenderTypes {
    private static RenderType lines;
    private static RenderType fill;

    private BagelRenderTypes() {}

    public static synchronized RenderType linesSeeThrough() {
        if (lines == null) {
            RenderPipeline pipeline = copyLayouts(RenderPipeline.builder(), RenderPipelines.LINES)
                    .withLocation(Identifier.fromNamespaceAndPath("bagel", "pipeline/esp_lines_see_through"))
                    .withVertexShader("core/rendertype_lines")
                    .withFragmentShader("core/rendertype_lines")
                    .withColorTargetState(new ColorTargetState(BlendFunction.TRANSLUCENT))
                    .withCull(false)
                    .withVertexBinding(0, DefaultVertexFormat.POSITION_COLOR_NORMAL_LINE_WIDTH)
                    .withPrimitiveTopology(PrimitiveTopology.LINES)
                    .withDepthStencilState(Optional.empty())
                    .build();
            lines = RenderType.create("bagel_esp_lines_see_through", RenderSetup.builder(pipeline).createRenderSetup());
        }
        return lines;
    }

    public static synchronized RenderType fillSeeThrough() {
        if (fill == null) {
            RenderPipeline pipeline = copyLayouts(RenderPipeline.builder(), RenderPipelines.DEBUG_FILLED_BOX)
                    .withLocation(Identifier.fromNamespaceAndPath("bagel", "pipeline/esp_fill_see_through"))
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withColorTargetState(new ColorTargetState(BlendFunction.TRANSLUCENT))
                    .withCull(false)
                    .withVertexBinding(0, DefaultVertexFormat.POSITION_COLOR)
                    .withPrimitiveTopology(PrimitiveTopology.QUADS)
                    .withDepthStencilState(Optional.empty())
                    .build();
            fill = RenderType.create("bagel_esp_fill_see_through", RenderSetup.builder(pipeline).createRenderSetup());
        }
        return fill;
    }

    private static RenderPipeline.Builder copyLayouts(RenderPipeline.Builder builder, RenderPipeline source) {
        for (BindGroupLayout layout : source.getBindGroupLayouts()) {
            builder.withBindGroupLayout(layout);
        }
        return builder;
    }
}
